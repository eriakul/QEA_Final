(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.PlayButtonHover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFA74E").s().p("A2zD3Qkdgxidg/QiihAAAhHQAAhGCihBQCdg+EdgwQJdhnNWABQNXgBJdBnQEdAwCdA+QCiBBAABGQAABHiiBAQidA/kdAxQpdBltXAAQtWAApdhlg");
	this.shape.setTransform(0,-21.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFBF51").s().p("A2zErQkdgtidg6Qiig9AAhCIAAnOMBAfAAAIAAHOQAABCiiA9QidA6kdAtQpdBftXAAQtWAApdhfg");
	this.shape_1.setTransform(0,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.PlayButtonHover, new cjs.Rectangle(-206.4,-56.4,412.9,112.9), null);


(lib.learn2draw = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E3E3E3").s().p("AhQARQghgHAAgKQAAgJAhgIQAhgGAvgBQAwABAhAGQAhAIAAAJQAAAKghAHQgiAHgvABQgugBgigHg");
	this.shape.setTransform(-0.3,-23.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhQAnQghgHAAgLIAAhCIDjAAIAABCQAAALghAHQgiAHgvAAQgvAAghgHg");
	this.shape_1.setTransform(-0.3,-18.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E3E3E3").s().p("AiRAoQg8gRAAgXQAAgWA8gQQA9gRBUAAQBVAAA9ARQA8AQAAAWQAAAXg8ARQg9AQhVAAQhVAAg8gQg");
	this.shape_2.setTransform(0,-16);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AiRA7Qg7gRAAgXIAAhcIGZAAIAABcQAAAXg7ARQg9APhVAAQhUAAg9gPg");
	this.shape_3.setTransform(0,-8.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E3E3E3").s().p("Ai6A4QhNgXAAghQAAggBNgXQBNgXBtAAQBtAABOAXQBNAXAAAgQAAAhhNAXQhOAXhtAAQhtAAhNgXg");
	this.shape_4.setTransform(0,-5.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ai6BEQhNgVAAggIAAhnIIPAAIAABnQAAAfhNAWQhOAVhtAAQhtAAhNgVg");
	this.shape_5.setTransform(0,3.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E3E3E3").s().p("AiRA6Qg7gQAAgXIAAhdIGZAAIAABdQAAAXg7AQQg9ARhVAAQhUAAg9gRg");
	this.shape_6.setTransform(0,13.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#BDBDBD").s().p("AhQAnQghgHAAgKIAAhDIDjAAIAABDQAAAKghAHQgiAHgvAAQguAAgigHg");
	this.shape_7.setTransform(-0.3,20.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.learn2draw, new cjs.Rectangle(-26.4,-25.5,52.9,51.1), null);


(lib.learndraw = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#68E34C").s().p("AhQARQghgHAAgKQAAgKAhgGQAhgIAvABQAwgBAhAIQAhAGAAAKQAAAKghAHQgiAIgvgBQguABgigIg");
	this.shape.setTransform(-0.3,-23.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#63FF7E").s().p("AhQAnQghgHAAgLIAAhCIDjAAIAABCQAAALghAHQgiAHgvAAQgvAAghgHg");
	this.shape_1.setTransform(-0.3,-18.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#68E34C").s().p("AiRAnQg8gQAAgXQAAgWA8gQQA9gQBUAAQBVAAA9AQQA8AQAAAWQAAAXg8AQQg9AQhVAAQhVAAg8gQg");
	this.shape_2.setTransform(0,-16);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#63FF7E").s().p("AiQA7Qg9gRAAgXIAAhdIGbAAIAABdQgBAXg7ARQg8APhWABQhVgBg7gPg");
	this.shape_3.setTransform(0,-8.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#68E34C").s().p("Ai6A4QhNgXAAghQAAggBNgXQBNgXBtAAQBtAABOAXQBNAXAAAgQAAAhhNAXQhOAXhtAAQhtAAhNgXg");
	this.shape_4.setTransform(0,-5.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#63FF7E").s().p("Ai6BEQhNgVAAggIAAhoIIPAAIAABoQAAAfhNAWQhOAWhtgBQhtABhNgWg");
	this.shape_5.setTransform(0,3.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#68E34C").s().p("AiQA6Qg9gQAAgXIAAhcIGbAAIAABcQgBAXg7AQQg9AQhVAAQhUAAg8gQg");
	this.shape_6.setTransform(0,13.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#65BD4F").s().p("AhQAnQghgHAAgKIAAhDIDjAAIAABDQAAAKghAHQgiAHgvAAQguAAgigHg");
	this.shape_7.setTransform(-0.3,20.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.learndraw, new cjs.Rectangle(-26.4,-25.5,52.9,51.1), null);


(lib.lab2draw = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DD0A00").s().p("AjhAxQhegVAAgcQAAgcBegUQBdgUCEAAQCFAABdAUQBeAUAAAcQAAAcheAVQheAUiEAAQiEAAhdgUg");
	this.shape.setTransform(-0.8,-64.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF3B3B").s().p("AjhBuQhegVAAgcIAAi+IJ/AAIAAC+QAAAcheAVQheAUiEAAQiEAAhdgUg");
	this.shape_1.setTransform(-0.8,-51.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DD0A00").s().p("AmXBuQipgtAAhBQAAg/CpguQCpguDuAAQDvAACpAuQCpAuAAA/QAABBipAtQipAujvAAQjuAAipgug");
	this.shape_2.setTransform(0.1,-44.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF3B3B").s().p("AmXCjQipguAAhBIAAkEISBAAIAAECIgBAAIABACQAABCipAtQipAujvAAQjuAAipgug");
	this.shape_3.setTransform(0,-24.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DD0A00").s().p("AoLCdQjZhBAAhcQAAhbDZhBQDZhBEyAAQEzAADZBBQDZBBAABbQAABcjZBBQjaBBkyAAQkyAAjZhBg");
	this.shape_4.setTransform(0,-15.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF3B3B").s().p("AoLC/QjZg9AAhWIAAknIXJAAIAAEnQAABWjZA9QjaA8kyAAQkyAAjZg8g");
	this.shape_5.setTransform(0,9.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DD0A00").s().p("AmXCjQipgtAAhBIAAkFISBAAIAAEDIgBAAIABACQAABBipAtQipAujvAAQjuAAipgug");
	this.shape_6.setTransform(0,37.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CC0000").s().p("AjhBtQhegTAAgdIAAi9IJ/AAIAAC9QAAAdheATQhdAViFgBQiEABhdgVg");
	this.shape_7.setTransform(-0.8,58.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.lab2draw, new cjs.Rectangle(-74,-71.6,148.1,143.4), null);


(lib.lab1draw = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00E3A3").s().p("AiCAcQg3gMAAgQQAAgQA3gLQA2gMBMAAQBNAAA2AMQA3ALAAAQQAAAQg3AMQg2AMhNAAQhMAAg2gMg");
	this.shape.setTransform(-0.4,-37.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00FFD5").s().p("AiCBAQg3gMAAgRIAAhtIFzAAIAABtQAAARg3AMQg2ALhNAAQhMAAg2gLg");
	this.shape_1.setTransform(-0.4,-30);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00E3A3").s().p("AjrBAQhigbAAglQAAgkBigbQBhgbCKABQCKgBBiAbQBiAbAAAkQAAAlhiAbQhiAaiKABQiKgBhhgag");
	this.shape_2.setTransform(0,-26);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00FFD5").s().p("AjrBfQhigbAAglIAAiXIKbAAIAACXQAAAlhiAbQhiAaiKAAQiJAAhigag");
	this.shape_3.setTransform(0,-14.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00E3A3").s().p("AkvBbQh9glAAg2QAAg0B9gmQB+gmCxAAQCxAAB+AmQB+AmAAA0QAAA1h+AmQh9AmiyAAQixAAh+gmg");
	this.shape_4.setTransform(0,-8.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00FFD5").s().p("AkvBuQh9gjAAgxIAAiqINZAAIAACqQAAAxh+AjQh9AkiygBQixABh+gkg");
	this.shape_5.setTransform(0,5.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00E3A3").s().p("AjrBfQhigbAAglIAAiXIKbAAIAACXQAAAlhiAbQhiAaiKAAQiKAAhhgag");
	this.shape_6.setTransform(0,21.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00BDA6").s().p("AiCBAQg3gMAAgQIAAhuIFzAAIAABuQAAAQg3AMQg2ALhNAAQhMAAg2gLg");
	this.shape_7.setTransform(-0.4,34.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.lab1draw, new cjs.Rectangle(-42.9,-41.5,85.9,83.1), null);


(lib.IntroText = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.IntroText, null, null);


(lib.intodraw = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FCCF19").s().p("AhQARQghgHAAgKQAAgJAhgIQAhgGAvAAQAwAAAhAGQAhAIAAAJQAAAKghAHQgiAIgvgBQguABgigIg");
	this.shape.setTransform(-0.3,-23.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F7F24B").s().p("AhQAnQghgHAAgLIAAhCIDjAAIAABCQAAALghAHQgiAHgvAAQgvAAghgHg");
	this.shape_1.setTransform(-0.3,-18.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FCCF19").s().p("AiRAnQg8gQAAgXQAAgWA8gQQA9gQBUgBQBVABA9AQQA8AQAAAWQAAAXg8AQQg9AQhVABQhVgBg8gQg");
	this.shape_2.setTransform(0,-16);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F7F24B").s().p("AiRA6Qg7gQAAgXIAAhcIGZAAIAABcQAAAXg7AQQg9ARhVgBQhUABg9gRg");
	this.shape_3.setTransform(0,-8.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FCCF19").s().p("Ai6A4QhNgXAAghQAAggBNgXQBNgXBtAAQBtAABOAXQBNAXAAAgQAAAhhNAXQhOAXhtAAQhtAAhNgXg");
	this.shape_4.setTransform(0,-5.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F7F24B").s().p("Ai6BEQhNgVAAggIAAhnIIPAAIAABnQAAAfhNAWQhOAVhtABQhtgBhNgVg");
	this.shape_5.setTransform(0,3.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FCCF19").s().p("AiQA6Qg9gQAAgXIAAhdIGbAAIAABdQgBAXg7AQQg9ARhVAAQhUAAg8gRg");
	this.shape_6.setTransform(0,13.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F9A91C").s().p("AhQAnQghgHAAgKIAAhDIDjAAIAABDQAAAKghAHQgiAHgvAAQguAAgigHg");
	this.shape_7.setTransform(-0.3,20.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.intodraw, new cjs.Rectangle(-26.4,-25.5,52.9,51.1), null);


(lib.Group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(4,1,1).p("AAFgdIgJA7");
	this.shape.setTransform(672.1,261.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A74VSIgfAAQgpAAgrgDQgIAAgGgGQgFgHAAgIQABgIAGgGQAGgFAIAAQAqADAoAAIAfAAQAJAAAFAGQAGAFAAAJQAAAIgGAGQgFAGgJAAIAAAAgA6NVKQgGgGgBgIQAAgJAFgGQAGgGAIAAQA9gDA7gEQAIAAAGAFQAHAGAAAIQABAIgGAHQgFAGgJAAQg7AEg9ADIgBAAQgIAAgFgFgA/lVEQg7gIg8gMQgIgCgFgHQgFgHACgIQACgIAHgEQAHgFAIACQA7AMA5AHQAIABAFAHQAGAGgCAIQgBAJgGAFQgFAEgHAAIgDAAgA2dU5QgGgFgBgIQgBgJAFgGQAFgHAIgBQA9gGA6gIQAJgCAGAFQAHAFABAJQABAIgFAGQgFAHgIABQg7AJg9AGIgCAAQgHAAgGgEgAyvUXQgHgEgCgJQgBgIAFgGQAEgHAJgCQA7gLA4gNQAIgCAHAFQAHAEACAIQACAIgFAHQgEAHgIACQg5ANg8AMIgEAAQgGAAgFgEgEgjTAUVQg4gQg7gSQgIgDgEgHQgEgHADgIQACgIAHgEQAIgEAIADQA6ASA4APQAIACAEAHQAEAIgCAIQgCAHgHAFQgFACgFAAIgGAAgAvGTiQgHgEgDgIQgCgIAEgHQAEgHAIgCQA7gRA2gUQAIgDAHAEQAIADACAIQADAIgDAHQgEAIgHADQg4AUg8ARIgFABQgFAAgFgDgEgm2ATNQg8gWg4gXQgHgDgDgIQgDgIADgHQADgIAIgDQAHgDAIADQA3AXA6AWQAIACAEAIQADAHgDAIQgCAIgIAEQgEABgEAAIgHgBgEA0DASfQgIgCgFgGQgEgHABgIIANhVQABgJAHgFQAGgFAIACQAJABAFAGQAFAHgCAIIgNBWQgBAIgHAFQgFAEgGAAIgEAAgArjSSQgIgDgEgHQgDgIADgIQADgHAHgEQA4gZAxgcQAHgFAIADQAIACAEAHQAEAHgCAIQgCAIgHAEQgzAeg5AaQgEABgEAAIgHgBgEgqYARtQg4gbgzgeQgHgEgDgIQgCgIAEgHQAFgHAHgCQAIgDAIAFQAyAdA2AaQAIAEADAIQACAIgDAHQgEAIgIACIgGABQgFAAgEgCgAoUQdQgIgBgFgHQgFgHABgIQABgIAHgFQAwgjAogoQAGgGAIAAQAJAAAFAGQAGAGAAAJQAAAIgGAGQgqApgzAlQgFAEgGAAIgDAAgEgtrAP0Qg0gjgvglQgGgGgBgIQgBgIAFgHQAFgGAIgBQAJgBAGAFQAuAlAyAiQAHAEACAJQABAIgEAHQgFAGgIACIgEAAQgGAAgFgDgEA0hAPRQgIgBgFgHQgGgGABgIQAHg+AEg6QAAgJAGgFQAHgGAIABQAIAAAGAHQAFAGAAAIQgEA7gHA/QgBAIgGAFQgGAFgHAAIgCAAgAl1NyQgHgFgCgIQgBgIAFgHQAigvAXg1QADgHAIgDQAIgDAHADQAIADADAIQADAIgEAHQgYA4glAzQgEAHgJACIgDAAQgGAAgFgEgEgwsANZQgugrgmgtQgFgGAAgJQABgIAGgFQAGgGAJABQAIABAFAGQAlArAsAqQAGAGABAIQAAAIgGAGQgGAGgIAAIAAAAQgIAAgGgFgEA0zALfQgIAAgGgGQgGgGABgIQABg+gCg6QAAgIAGgGQAFgGAIgBQAJAAAGAGQAGAFAAAJQACA7gBA/QgBAIgGAGQgFAFgIAAIgBAAgEgy9AKmQgIgBgFgHQgig1gag3QgDgHADgIQADgIAHgDQAIgEAIADQAHADAEAIQAYA0AgAyQAFAHgCAIQgBAIgHAFQgFADgGAAIgEgBgAkOKcQgIgCgFgHQgEgHACgIQAMg4ACg8QAAgIAGgGQAHgFAIAAQAIAAAGAGQAFAGAAAJQgCBAgNA7QgCAIgHAEQgFADgGAAIgEAAgEA0fAHrQgGgFgBgIQgGg9gJg6QgBgJAEgGQAFgHAIgBQAJgCAGAFQAHAFABAIQAKA8AGA+QAAAIgFAHQgFAGgJABIgBAAQgHAAgGgFgEg0mAHKQgHgEgCgIQgQg8gGg9QAAgJAFgGQAFgGAIgBQAJgBAGAGQAGAFABAIQAFA6APA5QADAIgFAHQgEAHgIACIgFABQgFAAgFgDgAkNGoQgGgFgBgIQgHg5gOg8QgCgIAEgHQAEgHAIgCQAIgCAHAEQAIAFACAIQAPA+AHA7QAAAIgFAHQgFAGgIABIgDAAQgGAAgGgEgEAz7AD/QgHgFgCgIQgNg6gRg4QgDgIAEgHQAEgIAIgCQAIgDAHAEQAHAEADAIQARA6AOA7QACAIgEAHQgFAHgIACIgFABQgFAAgFgDgEg01ADjQgIAAgFgGQgGgHABgIQADg8ANg+QACgIAHgFQAHgEAIABQAIACAEAHQAFAHgCAIQgMA7gDA6QgBAIgGAFQgGAFgHAAIgCAAgAlBDAQgHgEgDgHQgTg3gag5QgDgHADgIQADgIAIgDQAHgDAIADQAIADADAHQAaA6ATA4QADAIgDAHQgEAIgIADIgGABQgFAAgEgCgEAy3AAbQgHgEgEgHQgVg3gag1QgDgIACgIQADgIAHgDQAIgEAIADQAIADADAHQAbA3AWA4QADAIgEAHQgDAIgIADIgHABQgEAAgEgBgEg0JgAHQgIgDgEgHQgDgIACgIQAUg3Abg5QADgHAIgDQAIgDAHAEQAIADACAIQADAIgDAHQgaA3gTA1QgDAIgHAEQgEACgFAAIgGgBgAmegYQgHgDgEgHIgHgNIAAgBQgdg0gIg9QgBgIAFgHQAGgGAIgBQAIgBAGAFQAHAFABAIQAGA1AZAuIABAAIAIAPQADAHgCAIQgDAIgHAEQgFACgEAAIgHgBgEAxcgCpQgIgDgEgHQgdg0ghgxQgFgHACgIQABgJAHgEQAHgFAIACQAIABAFAHQAiAzAeA2QAEAHgCAIQgCAIgIAEQgEACgFAAIgGAAgEgyogDgQgHgEgCgIQgCgIAEgHQAdgyAkgzQAFgHAIgBQAIgCAHAFQAGAFACAIQABAIgEAHQgjAxgdAxQgEAHgIACIgFABQgFAAgFgDgAnAkJQgIgCgEgGQgFgHABgIQALg5Aag9QADgIAHgDQAIgDAIADQAHADAEAIQADAHgDAIQgYA5gKA1QgCAIgHAFQgFADgGAAIgEAAgEAvagFxQgIgBgGgHQgkgugpgtQgFgGAAgJQABgIAGgFQAGgGAIAAQAIABAGAGQApAuAmAwQAFAGgBAIQgBAIgHAGQgFAEgHAAIgCAAgEgwkgGkQgGgFgBgIQgBgIAFgHQAkgtApguQAFgGAIgBQAJAAAGAFQAGAGABAIQAAAIgFAHQgoAtgkAsQgFAHgIABIgDAAQgGAAgGgFgAlqnuQgHgEgDgIQgCgIAEgHQAeg0AlgzQAFgHAJgBQAIgBAGAFQAHAFABAIQACAIgFAHQgkAxgdAyQgEAHgIACIgFABQgGAAgEgDgEAstgIqQgqgpgtgnQgHgGAAgIQgBgIAFgHQAGgGAIgBQAIAAAHAFQAuAoArAqQAGAGAAAIQAAAIgGAGQgGAGgIAAIAAAAQgIAAgGgFgAjhqzQgGgGAAgIQgBgIAGgGQAngtAtgsQAGgGAIAAQAJAAAFAGQAGAGAAAIQAAAIgGAGQgsArgmAsQgGAGgIABIgBAAQgIAAgGgFgEAp5gLFQgugkgygiQgGgFgCgIQgCgIAFgHQAFgHAIgBQAIgCAHAFQAyAjAwAkQAGAFABAIQACAIgGAHQgEAGgJACIgDAAQgGAAgGgEgEAm2gNMQgxgfg1gdQgHgEgCgIQgCgIAEgHQAEgIAIgCQAIgCAHAEQA1AeAyAfQAHAEACAIQACAIgEAHQgFAHgIACIgFABQgFAAgFgDgAgptXQgJgBgFgGQgFgGAAgJQABgIAGgFQAogiApghIANgKQAHgFAIABQAIABAFAGQAGAHgCAIQgBAIgGAFIgNAKQgqAhgmAhQgFAFgIAAIgBAAgEAjogPAQg0gbg3gZQgHgDgDgIQgDgIADgIQAEgHAIgDQAIgDAHAEQA3AZA1AbQAIAEACAIQADAHgEAIQgEAHgIADIgGABQgEAAgFgCgACTvqQgIgCgFgHQgFgHACgIQACgIAGgFQAzgiAzgfQAIgEAIACQAIACAEAHQAEAHgCAIQgCAIgHAFQgzAegxAhQgFAEgGAAIgEAAgEAgRgQkQg1gXg4gWQgHgDgEgHQgDgIADgHQADgIAIgDQAHgEAIADQA4AWA2AYQAIADADAHQADAIgEAIQgDAHgHADIgIACQgEAAgEgCgAFexmQgHgDgEgHQgEgIADgHQACgIAHgEQA3gcA3gYQAHgDAIADQAIADADAHQADAIgDAIQgDAHgHAEQg2AXg1AcQgFACgEAAIgHgBgAc2x5Qg3gUg5gSQgHgDgEgHQgEgIADgHQACgIAIgEQAHgEAIADQA5ASA3AUQAIADAEAHQADAIgDAIQgCAHgIAEQgEACgEAAIgHgBgAZWzCQg4gRg6gQQgHgDgFgHQgEgHACgIQADgIAHgEQAHgEAIACQA6AQA4ARQAIADAEAHQAEAHgCAIQgCAIgIAEQgEACgFAAIgGAAgAI3zHQgHgEgDgIQgDgHADgIQAEgIAIgCQAwgSAxgPIAAAAIAUgFQAIgDAHAFQAHAEACAIQACAIgEAHQgEAHgIACIgSAFIgBABQgvAOgvARIgHABQgFAAgEgBgAVy0CIgZgGIAAAAQgrgLgtgHQgIgCgFgHQgFgGABgIQACgJAHgEQAGgFAIABQAvAIAtAMIAAgBIAZAGQAIACAEAHQAFAHgCAJQgCAIgHAEQgFADgGAAIgFgBgAMc0MQgHgEgCgIQgCgIAFgHQAEgHAIgCQA9gNA7gIQAIgBAHAFQAGAFABAIQACAJgGAGQgFAHgIABQg5AHg7ANIgEAAQgGAAgFgDgASL0nQg6gDg8ACQgIABgGgGQgGgGgBgIQAAgIAFgGQAGgGAIgBQA+gCA8ADQAIAAAGAGQAGAHgBAIQAAAIgGAGQgGAFgIAAIgBAAg");
	this.shape_1.setTransform(340.2,136.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(4,1,1).p("AAVgUIgpAp");
	this.shape_2.setTransform(48.5,72.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(0.2,0,680.1,272.4), null);


(lib.Path = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiWAxQg+gUAAgdQAAgbA+gUQA/gVBXAAQBYAAA/AVQA+AUAAAbQAAAdg+AUQg/AUhYAAQhXAAg/gUg");
	this.shape.setTransform(21.3,6.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path, new cjs.Rectangle(0,0,42.7,13.8), null);


(lib.ClipGroup_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EiYWBAcUhGPgFVg2LgJrUg2LgJsgdugMiQvDmXnwmyQn9m7AAnKQAAnJH9m8QHwmxPDmXUAdugMjA2LgJrUA2LgJsBGPgFTUBIugFgBPoAAAUBPoAAABIuAFgUBGPAFTA2MAJsUA2LAJrAdtAMjQPEGXHwGxQH9G8AAHJQAAHKn9G7QnwGyvEGXUgdtAMjg2LAJrUg2MAJrhGPAFVUhIuAFfhPoAAAUhPoAAAhIugFfg");
	mask.setTransform(2505,684.4);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#3D3D3D").ss(8).p("AH5oWQjhDJjuDqQndHUhFCm");
	this.shape.setTransform(2348.5,312.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3D3D3D").s().p("AkKGpIhAgwQgngdgIgyQgHgxAegoIHFpgQAdgoAygHQAxgHAoAdIBAAwQAoAdAHAyQAHAxgeAoInFJgQgdAogyAHIgSACQgmAAghgYg");
	this.shape_1.setTransform(2234,535.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3D3D3D").s().p("AE1ERIrPjzQgvgQgWgrQgWgtAPgvIAahLQAQgvAsgWQAtgWAvAPILPDzQAvAQAWArQAWAtgPAvIgaBLQgPAvgtAWQgaANgbAAQgTAAgUgGg");
	this.shape_2.setTransform(2140,339.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3D3D3D").s().p("ADIFpIpVnVQgmgfgGgxQgGgyAegnIAyg/QAfgnAxgGQAxgFAnAeIJVHVQAmAfAGAxQAGAygeAnIgyA/QgeAngyAGIgQABQgoAAgggag");
	this.shape_3.setTransform(3104,343.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3D3D3D").s().p("ACkF6IokoMQgkgigBgyQgBgyAigkIA3g5QAigkAygBQAygBAkAiIIkIMQAkAiABAyQABAygiAkIg3A5QgiAkgyABIgDAAQgwAAgjghg");
	this.shape_4.setTransform(2867.5,452.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3D3D3D").s().p("AiLD0QgngXAUgmICSkYIAXg0QARglAQgWQAuhBA1AgQAlAWgWAnQgSAdgZgFQgGAKgKAVIgVAwIifExQgMAZgUAAQgMAAgOgJg");
	this.shape_5.setTransform(2004.8,337.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3D3D3D").s().p("AEGHwQkLnylNnDQgMgQAFgRQAFgPAQgJQAngXAZAjQFOHFEKHwQAVAmgnAXQgPAIgMAAQgUAAgNgYg");
	this.shape_6.setTransform(2646,688.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3D3D3D").s().p("A2ANXQgXgnAjgaQEhjYEijFQQIq/RtohQAngTAXAnQAXAngnASQlGCdk1ClQxRJOvtLuQgOAKgMAAQgSAAgNgXg");
	this.shape_7.setTransform(2566.9,674.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3D3D3D").s().p("AKvKjQjvmvlzlNQlxlNnHjBQgSgIgEgRQgEgPAJgQQAXgnAoARQDQBZC8BzQFNDOEREcQESEfC9FWQAVAmgmAXQgPAIgMAAQgUAAgNgYg");
	this.shape_8.setTransform(2546.4,696.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3D3D3D").s().p("AJKDUIyqlQQgqgMAMgrQAMgsAqAMISqFQQApAMgLArQgKAigcAAQgHAAgJgCg");
	this.shape_9.setTransform(2375,642.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3D3D3D").s().p("AgkAgQgMgLgBgVQgBgRAOgOQANgNATAAIAJAAQARAAAPANQALALACAUQABASgOAOQgNANgTAAIgJAAQgRAAgPgNg");
	this.shape_10.setTransform(2314.5,627.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3D3D3D").s().p("Al+HaQgggfAbgiQFcm/FqmxQAcgiAgAgQAgAggcAiQlvG0lYG7QgNASgPAAQgPAAgPgQg");
	this.shape_11.setTransform(2311.8,631.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3D3D3D").s().p("Az3OuQgMgsArgJQE9hJEuiYQHsj4HvnYQDFi8Dmj+QCLiaEJkzQAdghAgAgQAfAggcAgQkwFiizDCQnVH7mvEzQobF+orB/QgIACgHAAQgeAAgKgjg");
	this.shape_12.setTransform(1994.3,610.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3D3D3D").s().p("ARERRQhShuhwirQh8i/hAheQhgiPhOhmQhjiAhhhiQhshtiHhbQh5hTiYhLQjth0g5gfQijhXhyhYQj1i7iykDQgYgkAmgXQAngWAZAjQDQEvEvDFQBrBGC7BaQDoBxBBAlQEACODUDsQCbCtDKEyQEPGaBABXQAaAjgoAWQgPAJgNAAQgVAAgPgVg");
	this.shape_13.setTransform(1928.8,663.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3D3D3D").s().p("AjpGoQgmgXAVglQDWl1DSmOQAUgnAnAXQAnAXgUAmQjTGOjVF1QgOAYgUAAQgMAAgPgJg");
	this.shape_14.setTransform(1849.5,447.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3D3D3D").s().p("EBJ6AeGQhJhPhGhhQhtiXiCj6QiOkahLiJQiCjrh+iXQifi+jFhxQjKh0kCg8QjbgykPgNQkBgMk8AQQjXALlkAiIpEA5QlYAhjuAOQqWAon1g/QowhHm+jDQjmhlj2irQivh5kDjWQiUh6hFg3Qh6hihmhGQjYiXkNiQQjgh3kgiAQiyhPlYiQQgngQALgsQAFgRANgIQAPgJATAIID8BpQEzCCDVBlQEXCFDgCFQDQB8D8DEQCUByEiDtQDkC4DgCCQD2COD+BXQHVCeJHAjQHmAdLBg+QCBgLHSgtQFvglDjgQQKMgtF4AwQJEBJFmEuQClCLCNDUQBhCTCEEEQCiFCA3BfQCDDkCLCXQAeAgggAgQgQAQgPAAQgQAAgOgQg");
	this.shape_15.setTransform(2294.9,575.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3D3D3D").s().p("AGyFRQnjkAm0lcQgigcAggfQAgggAhAbQGlFPHgD/QAnAUgXAnQgPAagWAAQgLAAgNgHg");
	this.shape_16.setTransform(3160.4,533.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3D3D3D").s().p("ArzDhQgMgrArgKQLZieK7kOQAogPAMArQAMArgoAQQq5ENrbCfIgOACQgfAAgKgkg");
	this.shape_17.setTransform(3082.1,710.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3D3D3D").s().p("AKxR2QiIkDiYkFQn5tnqQtGQgbgiAggfQANgNAPgBQASAAAMAQQC9DwCsDsQJqNUHlOXQAUAmgnAXQgOAJgMAAQgVAAgMgZg");
	this.shape_18.setTransform(3126.4,653.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#3D3D3D").s().p("AojG+QgMgsApgOIO6lVQiejpi3jTQgdghAgggQAggfAcAgQDTDzCvEJQAMATgJAVQgJATgVAHIvzFqQgLADgIAAQgZAAgJggg");
	this.shape_19.setTransform(2990.4,498.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#3D3D3D").s().p("AxyIfQgMgrArgLIEWhHQCagpB6glQHKiJGRjeQGejmFWk6QAggeAgAgQAfAgggAeQjACxjZCZQl5ELm0CyQjUBXkUBQQimAwlMBVQgJACgHAAQgdAAgKgjg");
	this.shape_20.setTransform(3053.1,521.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3D3D3D").s().p("AGhTcQgejxhAjrQhvmcjQl1QjQl3kik3QgPgQACgWQACgXAUgKQGwjnGQkPQAkgZAXAnQAWAngjAZQl+EBmRDaQCUCkB/C0QD7FnCfGeQCeGcA2G2QAGAqgtAAQgtAAgGgqg");
	this.shape_21.setTransform(2877.9,621.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#3D3D3D").s().p("An+CMQgMgrArgKQHfhwHJiSQAqgNAMAsQAMArgqANQnXCUnSBtQgIACgGAAQgeAAgKgjg");
	this.shape_22.setTransform(2889.9,591.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#3D3D3D").s().p("A2tLYQgggfAigbQDbipFSiJQBjgoCog9QDLhJBBgZQEFhjE1iiQD2iCFdi9IJSlDQAmgUAXAnQAXAngnAUIqcFpQnrEJhAAhQk+Cjj+BgQlpB/ixBJQkxB9jCCXQgQAMgOAAQgTAAgRgSg");
	this.shape_23.setTransform(3055,428.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#3D3D3D").s().p("AXFGoQofk2iOhPQlBiyj2hWQk+hwknAAQklgBkYBbQkZBajtCrQgjAZgXgmQgWgnAjgZQESjHFLhdQEohSE1ANQEzANEhBrQCQA2CkBRQB7A9CtBhQDVB3GoDyQAmAVgXAnQgPAZgVAAQgLAAgOgHg");
	this.shape_24.setTransform(3058.3,452.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#3D3D3D").s().p("AmODyQgXgnAlgXQF8jqFXjMQAlgWAXAmQAXAngmAXQlyDclhDaQgNAJgMAAQgUAAgOgZg");
	this.shape_25.setTransform(2907.4,273.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#3D3D3D").s().p("AkaDQQgXgnAigaIHxlrQAjgZAWAnQAXAmgjAaInwFqQgOALgMAAQgSAAgNgXg");
	this.shape_26.setTransform(2830.9,246.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#3D3D3D").s().p("AikDTQggggAcghQCLikB8i5QAYgkAnAWQAnAXgYAkQiEDCiRCtQgPARgPAAQgPAAgPgPg");
	this.shape_27.setTransform(2777.5,226);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#3D3D3D").s().p("AKoKyQropxqpqwQgegfAfggQAgggAfAfQKpKxLoJwQAhAcggAgQgRARgRAAQgPAAgQgNg");
	this.shape_28.setTransform(2989.7,292.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#3D3D3D").s().p("AOhKjQhph/hHhOQhkhthchRQiWiDjphtQhPgllXiJQkFhpiUhZQjSh/iDiqQgagjAngWQAmgXAbAiQCHCwD9CHQCIBJEZBsQEdBuCEBFQC/BjC3CrQCICACxDVQAcAiggAgQgQAPgOAAQgQAAgOgRg");
	this.shape_29.setTransform(2830.7,284.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#3D3D3D").s().p("A7DPHQgrgLAPgpQBdj4BEh9QBsjJCPhyQCPhxDdgrQBfgSEvgWQDzgSCxgsQDfg5ClhrQBLgxBnhWICriPQCpiFCuhfQF1jLGihAQArgHAMAsQAMArgrAHQnVBImMDxQibBeiqCPQh1BjgrAhQhcBIhPAtQijBcjVAzQirAojmASQiDAJhCAFQh0AKhRAPQjcAqiGB3Qh5BrheC0Qg5BuhUDfQgMAfgcAAQgJAAgKgDg");
	this.shape_30.setTransform(3017,340.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#3D3D3D").s().p("AneNhQhaj/BBklQA4j/Clj+QCmj/CoigQCmicDzh+QAmgUAXAnQAXAngnAUQjtB7iZCRQicCTibDrQigDzg4DuQhCEWBWDzQAOApgrAMQgJADgIAAQgdAAgMggg");
	this.shape_31.setTransform(2729.1,397.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#3D3D3D").s().p("AiuDuQgQgJgFgPQgFgRAMgQIEpmWQAagjAnAXQAnAXgaAjIkpGVQgPAVgVAAQgNAAgPgJg");
	this.shape_32.setTransform(2803.4,354.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#3D3D3D").s().p("ASMMtQjNjQkii5QjAh7kliaQlMipilhXQkdiYjDiDQj6ioi4i4QgegfAfggQAggfAfAeQDPDPEhC4QDAB6EmCZIHxEBQEcCYDDCEQD5CoC3C6QAfAfggAgQgQAQgQAAQgPAAgPgPg");
	this.shape_33.setTransform(2753.8,297.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#3D3D3D").s().p("EggvAmDQgngXATgmQBCh/CZhbQA+glDfhhQFhiZFLjFQFYjNDcirQEnjnC0j4QCvjvCUlQQBejWCOmSQBgkOCDmhQA9jAAwh4QBDioBOiAQEVnIJvk3QAmgTAXAnQAXAmgnAUQrIFikCJBQg6CBg8C6QgjBrhDDXQhwFah5FHQiFFmh0DmQidE6i/DdQhiBziEBzQhtBeiTBsQkUDJkkCmQkpCqk8CIQjHBVg2AgQiJBQg5BvQgMAYgUAAQgMAAgOgIg");
	this.shape_34.setTransform(2471.7,525);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#3D3D3D").s().p("AzLT8QgrgMAGgrQA3luC+lbQE7pBKOnaQEEi9FejHQDiiAGajUQAngUAXAnQAWAmgmAUQj7CCh2A/QjNBtigBdQ3mNvivSNQgFAigcAAQgHAAgKgDg");
	this.shape_35.setTransform(2536.2,364.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#3D3D3D").s().p("EAp1AIWIjvgnQsZiAhrgUQn+hhlziDQjVhLi4hbQgvgXg9ghIgogZQgZgRgQgGIgNgDQgxgNhLgNIh+gVQpGhrnBhAQkugrjLgRQiOgMguAAQhtgBhNAaQh2AohuBsQhVBUhVCEQg6BYgxBiIgiBKQAAgBAAAAQAAAAAAAAQAAAAAAABQgBAAAAACQgQAogsgMQgrgMAQgoIANgeQBVjAB+ikQDZkaDqgnQBSgNBuAEQAtACCTAOQDbAVE5AuQHDBCJABrQAiAGBGAKQA+AKAnANQAaAIAmAYIA+AmQBqA4BiArQDEBWDsBJQF9B1IXBdQE1A2JsBdQAqAHgMAsQgKAlghAAIgLgBg");
	this.shape_36.setTransform(2466.1,291.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#3D3D3D").s().p("EAlBAEiQiZiej5hhQithCkkg6QmzhXoZgXQl+gQpVAOQtwAVhhAAQosAEmkgmQgrgEgBgtQAAgSALgMQAMgNAVACQEHAYEsAHQD9AHE4gFQFNgFKagTQJKgLGdAbQITAjGzBnQDpA4CmBMQDPBeCICNQAfAfggAgQgQAQgQAAQgPAAgPgPg");
	this.shape_37.setTransform(2574.2,439);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#3D3D3D").s().p("AJ/N7QpPugr2sbQgeggAgggQAgggAeAgQL+MlJUOoQAXAlgmAXQgPAIgMAAQgVAAgOgWg");
	this.shape_38.setTransform(1875,717.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#3D3D3D").s().p("EAxjAcOQkXj2lejXQk1i+l8iwQmzjJtulCQt8lHmli/QrClCnxmGQh5hfi3idIkrkCQlpktkdiVQgngUAXgmQAXgnAmAUQEyCeGbFeIFPEgQDDCnCVBsQH2FrLbE8QEVB2F6CPQDcBTG5ChQM6EwHXDoQK3FWHdGkQAhAdggAgQgRAQgRAAQgPAAgPgNg");
	this.shape_39.setTransform(2135,604.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#3D3D3D").s().p("ANZMQQigjQi0jBQk2lNlqkVQlqkWmTjWQgmgVAXgmQAXgnAmAUQDoB8DfCSQGEEBFVE/QFUE/EcFzQAbAignAXQgQAJgNAAQgVAAgPgVg");
	this.shape_40.setTransform(1978.5,296.2);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#3D3D3D").s().p("AiBGPQgsgMAOgpIDorLQAOgpArAMQAsAMgOApIjpLLQgKAggcAAQgIAAgKgDg");
	this.shape_41.setTransform(1821.9,240.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#3D3D3D").s().p("AjXGzQgmgWARgoQC1mVDUmDQAVgmAnAXQAnAWgVAmQjXGGiyGTQgLAZgUAAQgLAAgPgJg");
	this.shape_42.setTransform(1879.9,248.9);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#3D3D3D").s().p("Ak/IAQgngWAXglIJRu2QAXglAnAWQAnAXgXAlIpRO2QgOAXgVAAQgMAAgPgJg");
	this.shape_43.setTransform(1949.9,268.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#3D3D3D").s().p("A3DYkQgMgrAqgLQEqhOCTgsQD2hKC9hQQGgixEJkJQCLiLCCi8QBniWB1jUQGjr4FsudQAQgoArALQArAMgPApQjJH/jlHiQh1D2hXCsQhzDghrC4Qh4DOh0CaQiMC4iXCEQkaD4myCpQkLBpoSCJQgJACgHAAQgdAAgJgig");
	this.shape_44.setTransform(1950.2,477.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#3D3D3D").s().p("AwsPAQjqhVkliRQhmgymbjXQoPkTn+klQh8hHlojaQkvi3i4hmQkKiSjbhQQkQhjj5gTQgrgDAAgtQAAgtArADQCBAJB/AbQDpAyECB1QDFBZEHCZIHoEjQEtC0C9BrQHxEaIXETQGUDQBuAzQEoCLDxBEQG6B8I8g1QDggVEdg0QCKgZFshKQFGhCCzgeQEYgwDlgRQIFgmH0CAIEEBHQCgAsBoAWQEzBCDmgiQDrgjDgiqQCPhtDgjzQAdggAgAfQAgAggeAgQhnByhHBHQhiBhhXBFQhpBShoA0QjdBvkOgBQjdgBk4hPQldhjivgnQnFhlpHBEQjfAaklA3IoABnQkyA+jIAeQkXAqjoAKQg/ACg+AAQnhAAmhiYg");
	this.shape_45.setTransform(2333.6,393.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#3D3D3D").s().p("EApxAaAQpemAp8knQjZhll5iZQm1iyifhGQoNjnoflXQnIkhoVmaQlFj6psn8QgWgTABgiQABghAUgUQAXgWAeABQAdABAYAUQFXEZC2CSQElDrDxC2QILGKHfEiQIiFJIVDfQDFBSGJCgQFXCPDwB0QIuEOIUFSQAdASAFAfQAFAcgPAbQgQAagaAIQgJADgKAAQgTAAgTgMg");
	this.shape_46.setTransform(2082.4,635.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#3D3D3D").s().p("AUXSUQlPjfkpjaQxTsru7vQQgYgYADgfQACgcAWgVQAVgWAcgCQAfgCAYAYQEKEREXEEQPbOYRrLwQAcATAFAfQAFAcgQAaQgPAbgaAIQgJADgJAAQgTAAgUgNg");
	this.shape_47.setTransform(3091.1,324.7);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#3D3D3D").s().p("EgucASbQghgBgUgVQgXgWACgfQABgcAUgZQDCj1EgjDQD6irFIiJQERhzFKhgQEQhPFdhNQKniYLBg7QDYgSGzgaQF7ghEGhPQEghWD9i/QDoiuDGkCQAUgaAagIQAdgKAcARQAZAPAJAfQALAhgSAXQjsEyj/C+QkSDMljBgQkIBHmEAfQm5AajaATQq6A9q1CgQriCrmoC3Qp1ERlWGvQgRAWggAAIgEAAg");
	this.shape_48.setTransform(2900.6,682.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#3D3D3D").s().p("EBUwAvGQh9hNhyhfQmalXktp8QhqjfiElXQiPl/hKi5QiBlGh1jjQiYklisjZQjHj7jgiaQkAiwl0hoQlVhgmahJQlLg7mxg2QsKhfsRgEQkagBnkAUQo1AYjMAEQmwAHlPgcQmYgilbhbQplignLlaQoAmDjPoeQgMggAPgZQAOgWAdgIQAegIAaALQAeANAMAfQAzCEBIB7QEiHxJGE2QH7EPKABWQFXAvGsADQEVACHvgUQHVgTE3gEQGogGFjAQQMJAjMCB9QGJA/FqBRQDFAsCVAtQC4A4CXBHQH9DuFyI7QD7GEEMLEQCqHBAtBuQCCFBB9DmQFHJaHNEcQAdASAGAeQAFAcgQAaQgPAbgaAIQgLAEgKAAQgTAAgSgMg");
	this.shape_49.setTransform(2536.9,508.6);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#3D3D3D").s().p("Egt0AqQQgVgVgBggQgBgiAXgTQEIjaHOkuQJMmCCbhwQEqjWEakTQEBj6D/k2QC4jgEUlyQFtnoBYhyQIHqfIGnPQJJoKKnmIQAdgRAeAKQAaAJAPAbQAPAagFAbQgFAegeARQr5G4p4JXQkDD1kFEwQjgEDj6FMQkqGQiXDGQkHFdjLDtQkLE4kADpQkDDrlgDzQiEBbjHCCQjeCQhvBJQmPEHj1DJQgZAUgcABIgEAAQgcAAgVgVg");
	this.shape_50.setTransform(2261.5,488.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("Ag2A0QgSgVAAgfQAAgdASgWQAVgXAhAAQAiAAAUAXQATAWgBAdQABAfgTAVQgUAXgiAAQghAAgVgXg");
	this.shape_51.setTransform(2883.1,7.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#2B2B2B").s().p("AAICJQgUgEgMgRIhciKQgLgRAEgUQAEgUARgMIA6gmQARgMAUAFQAUAEALARIBdCJQALASgEAUQgFAUgRAMIg5AmQgNAIgOAAIgKgBg");
	this.shape_52.setTransform(2830.4,578.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#2B2B2B").s().p("AAeCrQgVgEgKgRIiJjOQgMgRAEgUQAFgUARgMIA5gmQARgMAVAFQAUAEALARICJDNQALASgDAUQgFAUgRAMIg6AmQgMAIgPAAIgKgBg");
	this.shape_53.setTransform(2719.1,630.9);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#2B2B2B").s().p("AgTDAQgTgHgJgTIhvjpQgJgTAHgTQAHgUASgJIB1g3QASgJATAHQAUAHAJATIBvDpQAJATgHATQgHAUgTAJIh0A3QgKAFgKAAQgJAAgJgDg");
	this.shape_54.setTransform(2691.6,685.7);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#2B2B2B").s().p("AAFCuQgTgHgIgTIhqjfQgKgTAIgTQAGgUATgIIA+geQATgJAUAHQASAHAJATIBrDfQAIASgHAUQgHAUgTAIIg+AeQgKAFgLAAQgIAAgJgDg");
	this.shape_55.setTransform(2670.1,642.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#2B2B2B").s().p("AhnDAQgUgFgKgSIhQiQQgKgSAGgTQAGgVASgJIEDiRQASgKAUAGQAUAGAKASIBQCQQAKASgGATQgGAUgSAKIkDCQQgLAGgMAAQgHAAgIgCg");
	this.shape_56.setTransform(2623.9,707.1);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#2B2B2B").s().p("AihCqQgUgGgKgRIgig9QgKgSAGgUQAGgUASgKIFJi2QASgLAUAGQAUAFAKATIAiA8QAKASgGAUQgGAVgSAJIlJC3QgMAGgMAAQgHAAgHgCg");
	this.shape_57.setTransform(2600,675.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#2B2B2B").s().p("AihCqQgUgFgKgTIgig8QgKgSAGgUQAGgUASgKIFJi2QASgLAUAGQAUAFAKATIAiA8QAKASgGAUQgGAVgSAJIlJC3QgMAGgMAAQgHAAgHgCg");
	this.shape_58.setTransform(2537,710.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#2B2B2B").s().p("ADoCuIoIi7QgTgHgJgTQgJgTAHgTIAXhBQAHgUATgJQATgIATAHIIIC6QAUAHAJATQAIATgHATIgXBBQgHAUgTAJQgLAFgLAAQgIAAgIgDg");
	this.shape_59.setTransform(2585,600.1);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#2B2B2B").s().p("AA7CKIjQiFQgRgKgFgVQgEgUALgRIAlg7QALgRAUgEQAVgFARALIDQCFQASALAEAUQAEAUgLARIglA7QgLARgUAFIgLABQgOAAgNgIg");
	this.shape_60.setTransform(2534.1,640.9);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#2B2B2B").s().p("AgwCfIhkhVQgPgOgCgUQgBgVANgQICEibQAOgPATgCQAWgCAPAOIBjBVQAQANACAVQABAUgNAQIiFCbQgNAQgUABIgEAAQgSAAgOgLg");
	this.shape_61.setTransform(2367.3,674);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#2B2B2B").s().p("AgcCFIhFgmQgSgKgGgVQgGgUAKgSIBQiLQAKgSAUgGQATgFASAKIBFAmQASAKAFAUQAGAUgKASIhPCMQgKASgUAGQgHACgGAAQgNAAgLgHg");
	this.shape_62.setTransform(2356,612);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#2B2B2B").s().p("AgJBiIhFgmQgSgKgGgUQgFgUAKgRIAohHQAKgSAUgGQAUgFARAKIBFAmQASAKAGAUQAFAUgKARIgoBHQgKASgUAGQgHACgHAAQgMAAgLgHg");
	this.shape_63.setTransform(2413,627.5);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#2B2B2B").s().p("AgeCIIhFgnQgSgKgGgUQgFgUAKgSIBSiQQAJgTAVgFQATgGASALIBEAmQASAKAHAUQAFAUgKASIhSCRQgKARgUAGQgHACgGAAQgMAAgMgGg");
	this.shape_64.setTransform(2317.1,656.8);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#2B2B2B").s().p("AiLCxQgVgEgLgRIgmg6QgMgRAEgUQAEgVASgLIEpjGQASgMAUAFQAVAEALARIAmA5QALARgEAVQgEAUgRAMIkqDGQgNAIgOAAIgKgBg");
	this.shape_65.setTransform(2491.7,688.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#2B2B2B").s().p("AkMEmQgVgDgMgQIgqg3QgNgRADgUQADgVAQgMII3mxQAQgNAUAEQAVACANARIAqA3QAMAQgDAUQgCAVgRANIo2GwQgOAKgQAAIgHAAg");
	this.shape_66.setTransform(2438.8,681.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#2B2B2B").s().p("AjpBXQgPgOgCgUIgFhEQgBgVANgQQAOgPAUgCIGWgdQAVgBAQANQAPAOACAUIAFBEQABAVgNAQQgOAPgVACImVAdIgEAAQgSAAgPgMg");
	this.shape_67.setTransform(2441.6,593.3);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#2B2B2B").s().p("ACiBeIlJgJQgUAAgPgPQgOgPABgVIAChOQABgVAPgOQAPgOAUAAIFJAJQAUAAAPAPQAOAPAAAVIgCBOQAAAUgQAPQgPAOgTAAIgCAAg");
	this.shape_68.setTransform(2283.7,608.7);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#2B2B2B").s().p("AB5CPIkyh4QgTgHgJgSQgIgTAHgTIAdhKQAIgTATgJQATgIATAHIEyB5QAUAHAIASQAIATgHATIgdBKQgIATgTAJQgKAEgJAAQgKAAgJgEg");
	this.shape_69.setTransform(2251.7,642.7);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#2B2B2B").s().p("AgeCIIhFgnQgSgKgFgUQgGgUAKgSIBSiQQAJgTAVgFQATgFASAJIBFAnQARAKAGAUQAGAUgKASIhSCQQgKATgUAFQgHACgGAAQgMAAgMgGg");
	this.shape_70.setTransform(2224.1,609.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#2B2B2B").s().p("Ag+B8Ig6g3QgOgOgBgVQgBgVAOgOIBzh4QAOgPAUgBQAWAAAOAOIA5A3QAPAPABAUQABAVgOAOIh0B4QgNAPgVABIgBAAQgUAAgOgOg");
	this.shape_71.setTransform(2146.1,600.8);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#2B2B2B").s().p("ABeCJIkBhuQgSgIgIgTQgIgSAIgTIAfhJQAIgTATgIQAUgHATAIIEABtQATAJAIASQAHATgIATIgfBJQgIATgTAIQgJADgKAAQgKAAgJgEg");
	this.shape_72.setTransform(2100,590.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#2B2B2B").s().p("AgDFSQgRgKgEgTIiIo9QgEgUALgQQAKgRATgEIBcgXQAUgEAQAKQAQALAFATICII9QAEAUgLAQQgKARgTAFIhcAWIgMABQgNAAgLgIg");
	this.shape_73.setTransform(2948.4,721.5);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#2B2B2B").s().p("AgvBlQgSgIgIgTIgehOQgHgTAIgSQAHgSATgHIBXgjQATgHASAIQASAIAHATIAfBOQAHATgIASQgIASgSAHIhXAiQgJAEgJAAQgKAAgJgEg");
	this.shape_74.setTransform(3029.6,707.9);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#2B2B2B").s().p("AgvBlQgSgIgIgTIgehOQgHgTAIgSQAHgSATgHIBXgjQATgHASAIQASAIAHATIAfBOQAHATgIASQgIASgSAHIhXAiQgJAEgJAAQgKAAgJgEg");
	this.shape_75.setTransform(3018.6,687.9);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#2B2B2B").s().p("AgTBuQgTgDgMgQIgzhEQgMgQADgTQADgUAQgMIBMg4QAPgMATADQAUADAMAQIAzBEQAMAQgDATQgDAUgQALIhMA5QgNAJgOAAIgIAAg");
	this.shape_76.setTransform(3128.6,578.9);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#2B2B2B").s().p("AgTBuQgTgDgMgQIgzhEQgMgQADgTQADgUAQgMIBMg4QAPgMATADQAUADAMAQIAzBEQAMAQgDATQgDAUgQALIhMA5QgNAJgOAAIgIAAg");
	this.shape_77.setTransform(3109.6,557.9);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#2B2B2B").s().p("AgTBuQgTgDgMgQIgzhEQgMgQADgTQADgUAQgMIBMg4QAPgMATADQAUADAMAQIAzBEQAMAQgDATQgDAUgQALIhMA5QgNAJgOAAIgIAAg");
	this.shape_78.setTransform(3093.6,541.9);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#2B2B2B").s().p("ABMD+QgTgEgMgQIj2lnQgLgRADgTQAEgTAQgMIBOg2QAQgLAUAEQAUADALARID2FnQAMAQgEAUQgDATgRAMIhOA1QgMAJgOAAIgKgBg");
	this.shape_79.setTransform(3061.6,589.1);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#2B2B2B").s().p("AhCBZQgRgLgDgUIgOhTQgEgUAMgQQALgQAVgEIBbgPQAUgEAQAMQAQALAEAUIAOBTQADAUgLAQQgMAQgTADIhdAQIgIABQgPAAgMgJg");
	this.shape_80.setTransform(3051.6,627.9);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#2B2B2B").s().p("AgpBiQgXgJgKgWIgZg6QgKgWAJgWQAJgXAWgKIBDgdQAVgKAXAJQAXAJAKAXIAZA6QAKAVgJAXQgJAXgXAJIhCAeQgLAFgLAAQgLAAgLgFg");
	this.shape_81.setTransform(3004.6,632.9);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#2B2B2B").s().p("AgNCrQgSgHgIgSIhejXQgIgSAHgSQAIgTASgIIBXgmQASgIARAIQATAHAIASIBdDXQAIASgHASQgHATgTAIIhWAlQgKAFgKAAQgHAAgJgEg");
	this.shape_82.setTransform(2978.5,595.8);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#2B2B2B").s().p("AAbEKQgSgIgIgSIiwmTQgIgTAIgSQAHgSATgIIBXgmQASgIASAHQASAIAIASICvGTQAIASgHATQgIASgSAIIhWAmQgKAEgJAAQgJAAgJgDg");
	this.shape_83.setTransform(2915.7,625.2);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#2B2B2B").s().p("AAHCAIiEhsQgQgMgCgSQgCgUAMgPIA8hKQAMgQAUgCQAUgDAPANICFBsQAPAMACASQACAUgMAQIg8BJQgNAQgTACIgGAAQgQAAgNgKg");
	this.shape_84.setTransform(3169.2,500.4);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#2B2B2B").s().p("AgOCQQgTgGgJgSIhSiVQgJgRAGgTQAFgTASgKIBTgtQARgKASAGQATAGAKARIBRCVQAKASgGATQgFATgSAJIhTAuQgLAGgLAAQgHAAgHgCg");
	this.shape_85.setTransform(2875.2,560.4);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#2B2B2B").s().p("AgVBwQgUgEgLgQIg0hNQgLgQAEgTQADgTARgMIBOg1QAQgLATAEQAUAEALAQIA0BNQALAPgEAUQgEATgQAMIhOA1QgMAIgNAAIgKgBg");
	this.shape_86.setTransform(2895,536.1);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#2B2B2B").s().p("AjjB+QgRgKgFgTIgRhEQgEgTAKgQQAKgRAUgFIGmhnQATgFARALQARAKAFATIARBEQAEATgKAQQgKARgUAFImmBnQgGABgGAAQgNAAgLgHg");
	this.shape_87.setTransform(3078.1,672.1);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#2B2B2B").s().p("AheBuQgSgJgHgSIgZhBQgHgSAIgSQAIgSATgHICuhDQASgHATAIQASAIAHATIAZBBQAHARgIATQgIASgTAHIiuBDQgJADgIAAQgKAAgKgEg");
	this.shape_88.setTransform(2993.5,541.5);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#2B2B2B").s().p("AhQB4QgTgGgJgRIghg+QgJgSAGgSQAGgSARgKIClhXQASgJATAGQATAGAJARIAgA+QAKARgGASQgGAUgSAJIikBXQgLAFgLAAQgHAAgIgCg");
	this.shape_89.setTransform(3041.5,523.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#2B2B2B").s().p("AhdCTQgUgEgLgQIgng6QgLgRAEgTQADgUARgLIDRiNQAQgLAUAEQATAEALAQIAnA6QAMAQgEAUQgEAUgQALIjRCNQgNAIgNAAIgKgBg");
	this.shape_90.setTransform(3108.4,479);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#2B2B2B").s().p("AhtCHQgTgGgJgRIghg+QgJgRAGgTQAGgSARgKIDgh1QARgKATAGQATAGAKASIAgA+QAJARgGATQgGASgRAJIjgB2QgKAGgLAAQgIAAgHgDg");
	this.shape_91.setTransform(3144.4,415);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#2B2B2B").s().p("AhtCHQgTgGgJgRIghg+QgJgRAGgTQAGgSARgKIDgh1QARgKATAGQATAGAKASIAgA+QAJARgGATQgGASgRAJIjgB2QgKAGgLAAQgIAAgHgDg");
	this.shape_92.setTransform(3058.4,452);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#2B2B2B").s().p("AgPC8QgTgGgKgSIh2jXQgJgQAFgUQAGgTASgJIB6hEQASgJASAFQATAGAJASIB3DWQAJARgGAUQgFASgRAKIh7BDQgMAHgKAAQgHAAgHgCg");
	this.shape_93.setTransform(2996.2,487.2);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#2B2B2B").s().p("AgoB9QgUgEgLgQIg0hNQgLgRAEgSQADgTARgMIBzhOQAQgLAUADQATAEAMARIA0BMQALARgEASQgEAUgQALIhzBPQgMAIgOAAIgKgBg");
	this.shape_94.setTransform(2939.9,455.8);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#2B2B2B").s().p("AhBB8QgYgIgKgXIgkhSQgKgXAJgXQAJgXAYgKIB7g2QAXgLAXAKQAYAIAJAXIAkBSQAKAWgIAXQgJAYgYAKIh7A2QgMAGgMAAQgLAAgLgFg");
	this.shape_95.setTransform(3131.9,234.4);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#2B2B2B").s().p("AAxCkIjRjcQgNgOABgSQAAgTAOgNIAugsQAOgNATAAQATABAMAOIDRDbQANAOgBATQAAATgOANIguArQgOANgTAAQgTAAgMgOg");
	this.shape_96.setTransform(3070.2,256.7);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#2B2B2B").s().p("AjfBrQgPgLgEgSIgMg/QgDgRAKgQQALgPATgEIGXhMQASgEAQALQAQALADASIALA/QAEARgLAQQgKAPgTAEImXBMIgJABQgNAAgMgIg");
	this.shape_97.setTransform(2966.4,324.7);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#2B2B2B").s().p("AgzCDQgYgHgNgVIgshOQgNgVAGgYQAHgYAVgNIB1hDQAVgNAZAHQAYAGANAWIAsBOQANAVgHAYQgGAYgWAMIh0BEQgOAIgQAAQgIAAgIgCg");
	this.shape_98.setTransform(2936.9,281.4);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#2B2B2B").s().p("AhhBnQgSgJgGgTIgUhDQgGgRAJgTQAJgRATgGICrg2QATgGASAJQASAKAFASIAVBDQAGASgJASQgJARgTAGIirA2QgIACgHAAQgLAAgLgFg");
	this.shape_99.setTransform(2979.2,438.7);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#2B2B2B").s().p("AgoB9QgUgEgLgQIg0hNQgLgRAEgSQADgTARgMIBzhOQAQgLAUADQATAEAMARIA0BMQALARgEASQgEAUgQALIhzBPQgMAIgOAAIgKgBg");
	this.shape_100.setTransform(2909.9,294.8);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#2B2B2B").s().p("AAcC+QgZgBgQgSIieimQgRgRABgZQAAgZATgRIBiheQASgRAZABQAZAAARASICdCmQARARgBAZQAAAZgSASIhjBdQgRARgYAAIgCAAg");
	this.shape_101.setTransform(2891.7,239.4);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#2B2B2B").s().p("AgTCLQgZAAgSgTIg9hAQgSgTACgZQAAgYATgRIBihdQASgRAYAAQAZABARASIA+BBQASASgBAZQgBAYgSARIhjBeQgRARgWAAIgDgBg");
	this.shape_102.setTransform(2859.9,260.4);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#2B2B2B").s().p("AgxCpIhehDQgUgOgEgZQgEgZAPgUIB7isQAOgVAZgDQAYgFAVAPIBcBCQAVAPAEAZQAEAZgOAUIh8CsQgOAUgYAFIgKAAQgTAAgQgLg");
	this.shape_103.setTransform(2805.8,228.8);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#2B2B2B").s().p("Ag4CtIhYg+QgPgLgDgSQgEgTALgPICVjRQAKgQATgDQATgDAPALIBXA+QAQALADASQADATgLAPIiUDSQgLAPgSADIgIABQgOAAgMgJg");
	this.shape_104.setTransform(2823,378.8);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#2B2B2B").s().p("AhfDUIhUhAQgPgMgCgTQgDgSALgPIDckfQAMgOATgDQASgDAPAMIBUBAQAPAMACATQADATgMAOIjbEeQgMAPgSADIgHAAQgPAAgMgJg");
	this.shape_105.setTransform(2753.1,355.6);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#2B2B2B").s().p("ACSBpIlDhPQgSgEgKgRQgKgPAFgSIAKgrQAFgSAQgKQAQgKASAFIFDBPQASAEAKAQQAKAPgFATIgKArQgFATgQAJQgLAHgMAAIgLgCg");
	this.shape_106.setTransform(2756.7,416.4);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#2B2B2B").s().p("ACSBpIlDhPQgSgEgKgRQgKgPAFgSIAKgrQAFgSAQgKQAQgKASAFIFDBPQASAEAKAQQAKAPgFATIgKArQgFASgQAKQgLAHgMAAIgLgCg");
	this.shape_107.setTransform(2722.7,469.4);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#2B2B2B").s().p("ABsBfIj2g4QgKgCgGgJQgGgJADgLIAShSQADgLAJgGQAJgFALACID2A4QAKACAGAKQAGAJgCAKIgTBSQgCALgKAGQgGAEgHAAIgHgBg");
	this.shape_108.setTransform(2626.2,487.8);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#2B2B2B").s().p("AApBpIiXhbQgKgGgCgJQgDgLAGgJIArhJQAGgKAKgCQALgDAJAFICXBbQAKAGACAJQADALgFAJIgsBJQgGAKgKACIgIABQgGAAgGgDg");
	this.shape_109.setTransform(2762,464.5);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#2B2B2B").s().p("AALBQIhNgiQgJgEgEgLQgEgJAEgKIAihOQAFgKAKgDQAKgFAKAFIBMAiQAKAEAEALQAEAJgEAKIgjBOQgEAKgKADQgFACgEAAQgGAAgFgCg");
	this.shape_110.setTransform(2696.8,500.4);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#2B2B2B").s().p("AAmBHIhTgEQgLgBgHgIQgHgIAAgLIAFhUQAAgLAIgIQAIgGALAAIBUAFQALAAAHAIQAHAIAAALIgFBUQAAALgJAHQgHAHgKAAIgCAAg");
	this.shape_111.setTransform(2523.8,482.4);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#2B2B2B").s().p("ABACPIjZhxQgWgLgIgXQgHgYALgXIAihBQALgWAYgIQAYgHAWALIDaBxQAWALAIAXQAHAYgLAWIgiBCQgLAWgYAIQgKADgJAAQgOAAgOgHg");
	this.shape_112.setTransform(2717.2,302.8);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#2B2B2B").s().p("AhUCeQgYgHgMgXIg1hlQgMgWAIgXQAHgYAWgMIC7hiQAWgMAYAHQAYAIAMAWIA1BlQAMAWgIAXQgHAYgWAMIi7BjQgOAHgOAAQgJAAgJgDg");
	this.shape_113.setTransform(2620.8,286.8);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#2B2B2B").s().p("AA4DJQgZgBgRgTIi9jeQgQgTACgZQABgZATgRIBGg7QATgRAZACQAZACARAUIC9DdQAQATgBAZQgCAZgTAQIhGA8QgRAPgWAAIgFgBg");
	this.shape_114.setTransform(2607.4,226.9);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#2B2B2B").s().p("AAbCxQgSgCgKgOIiei3QgLgNABgTQABgRAOgMIBghSQAOgMASACQASABAKANICeC4QALANgBASQgCASgNAMIhgBSQgMALgRAAIgDAAg");
	this.shape_115.setTransform(2569.5,248.2);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#2B2B2B").s().p("AgJCFQgSgCgLgNIhThiQgMgNABgRQACgRANgMIBhhTQANgLARABQASACALANIBUBhQALAOgBARQgBARgOAMIhhBSQgMALgPAAIgDAAg");
	this.shape_116.setTransform(2527.8,268.9);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#2B2B2B").s().p("AgoBqQgUgFgLgSIgjg5QgKgRAEgTQAGgVARgLIBcg5QARgLAVAFQAUAGALARIAiA5QAMASgGASQgFAVgRALIhcA4QgMAIgNAAQgHAAgGgBg");
	this.shape_117.setTransform(2255.6,458.3);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#2B2B2B").s().p("ABZBeIjEgXQgVgCgNgQQgNgRADgUIAHhBQADgVAQgNQAQgNAVADIDEAWQAVADANAQQANAQgDAVIgHBBQgCAVgRANQgOALgQAAIgHgBg");
	this.shape_118.setTransform(2537.4,340.9);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#2B2B2B").s().p("AAPB4IhpgoQgUgIgIgTQgIgTAHgTIAohpQAHgTATgIQATgJATAHIBqApQATAHAJATQAIATgHATIgoBpQgHATgTAJQgKAEgKAAQgJAAgKgDg");
	this.shape_119.setTransform(2573.8,332.8);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#2B2B2B").s().p("AAzBtIhwgGQgVgBgOgPQgOgQABgUIAGhwQABgVAQgOQAPgNAVABIBxAFQAUACAOAPQAOAPgBAVIgGBwQgBAVgQAOQgOANgTAAIgDgBg");
	this.shape_120.setTransform(2648.8,396.9);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#2B2B2B").s().p("AAzBuIhxgHQgUAAgOgQQgOgQABgVIAGhvQABgUAPgOQAQgPAUABIBxAGQAVABAOAQQAOAQgBAUIgGBwQgBAUgPAOQgPAOgTAAIgDAAg");
	this.shape_121.setTransform(2599.8,393.9);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#2B2B2B").s().p("ABzBwIjwgNQgUgBgOgQQgOgPABgVIAGhuQABgUAPgOQAQgOAUABIDwANQAVABAOAPQANAQgBAUIgFBuQgBAVgQAOQgOANgTAAIgDAAg");
	this.shape_122.setTransform(2653,448.4);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#2B2B2B").s().p("ACCBKIkKgPQgVgBgOgPQgNgQABgUIABghQABgUAQgOQAPgOAVABIEKAOQAVABAOAQQANAPgBAVIgBAgQgBAVgQAOQgOANgTAAIgDAAg");
	this.shape_123.setTransform(2602.9,439.4);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#2B2B2B").s().p("AhtDCQgPgEgMgOIhDhYQgLgOAAgQQAAgQALgJIEfjfQALgIAPAEQAPAFAMAOIBCBXQAMAOAAARQAAAQgLAIIkfDfQgHAGgJAAIgKgCg");
	this.shape_124.setTransform(2093.2,707.3);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#2B2B2B").s().p("AEMCEIoxhFQgVgCgOgPQgNgPACgRIAPhtQACgRARgLQAQgLAVACIIyBGQAVACAOAPQANAOgCASIgPBtQgCARgRALQgOAJgQAAIgIgBg");
	this.shape_125.setTransform(2652.1,349.4);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#2B2B2B").s().p("AhNCEIgwgtQgQgOAAgVQgBgVAOgPICHiRQAOgPAVgBQAUAAAQAOIAwAtQAQAOAAAVQABAVgOAPIiHCRQgOAPgVAAIgCABQgTAAgPgOg");
	this.shape_126.setTransform(2449.4,329.9);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#2B2B2B").s().p("ABhBWIjGgFQgUgBgPgPQgOgPABgUIABhCQABgVAPgOQAPgOAVAAIDGAGQAUAAAPAPQAOAPgBAUIgBBDQgBAUgPAPQgPANgTAAIgCAAg");
	this.shape_127.setTransform(2503.4,388.9);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#2B2B2B").s().p("ABhBWIjGgFQgUgBgPgPQgOgPABgUIABhCQABgVAPgOQAPgPAVABIDGAFQAUABAPAPQAOAPgBAUIgBBDQgBAUgPAOQgPAOgTAAIgCAAg");
	this.shape_128.setTransform(2407.4,386.9);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#2B2B2B").s().p("AiRBQQgQgOgBgVIgDhKQgBgUAOgQQAOgPAUgBIDlgLQAUgBAQAOQAPAOABAUIADBLQABAUgOAQQgOAPgUABIjlALIgCAAQgTAAgOgNg");
	this.shape_129.setTransform(2391.9,438.4);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#2B2B2B").s().p("AlGB1QgRgNgCgUIgKhKQgDgUANgQQAMgRAUgCIJbhRQAUgDARANQAQANAEAUIAKBKQACAUgMAQQgNARgVACIpaBRIgIAAQgQAAgNgKg");
	this.shape_130.setTransform(2356,465.2);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#2B2B2B").s().p("AmgBlQgQgOgBgVIgEhaQgBgUAOgQQAOgPAUgBIMEgkQAUgCAQAOQAPAOABAVIAEBZQABAVgOAPQgOAQgUABIsEAkIgCABQgTAAgOgNg");
	this.shape_131.setTransform(2493,442.4);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#2B2B2B").s().p("ACWChIlxifQgSgGgIgUQgIgTAIgTIAehHQAJgTATgIQATgHATAHIFxCeQATAHAIAUQAIATgJATIgeBHQgIATgTAIQgKAEgJAAQgKAAgKgEg");
	this.shape_132.setTransform(2082.6,630.2);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#2B2B2B").s().p("AhgCeQgVgEgLgRIgthAQgLgRADgUQAEgVARgLIDciYQARgMAUAEQAVADALARIAsA/QAMARgEAVQgDAUgRAMIjcCYQgNAJgPAAIgJAAg");
	this.shape_133.setTransform(2038.3,682.1);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#2B2B2B").s().p("Ah1CPQgTgGgKgTIgjhFQgJgSAGgUQAHgTASgJIDuh6QATgJAUAGQATAHAKASIAjBFQAJATgGAUQgHASgSAKIjvB5QgKAFgMAAQgIAAgIgCg");
	this.shape_134.setTransform(2005.3,660.1);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#2B2B2B").s().p("ABqDBIk/jzQgQgNgDgVQgDgUANgQIAvg+QAMgRAVgCQAUgDARAMIE/DzQAQANADAVQADAUgNAQIgvA+QgMAQgVADIgIABQgQAAgNgKg");
	this.shape_135.setTransform(1954.6,615.2);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#2B2B2B").s().p("Ag6BlIgXgRQgQgNgDgUQgDgVAMgQIBRhpQALgQAVgDQAUgDARANIAXARQAQANADAUQADAVgNAQIhQBpQgMAQgUADIgHABQgQAAgOgLg");
	this.shape_136.setTransform(2017.1,599.1);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#2B2B2B").s().p("AA0DDIj0iHQgRgKgGgUQgGgUAKgRIBcinQAKgSAUgGQAUgFASAKIDzCHQASAJAGAUQAGAUgKARIhcCnQgKASgTAGQgIACgHAAQgMAAgMgGg");
	this.shape_137.setTransform(2026.1,546.9);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#2B2B2B").s().p("AAABwIhqhSQgRgNgCgTQgEgVANgQIAvg+QAMgQAVgDQAVgDAPAMIBrBSQAQANAEAUQACAUgMARIgvA9QgMAQgVADIgIABQgQAAgNgKg");
	this.shape_138.setTransform(1986,579.1);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#2B2B2B").s().p("AAgBqIh9guQgUgHgIgTQgJgTAIgTIAahIQAHgTATgJQATgIAUAHIB9AuQATAHAJATQAIATgHASIgaBJQgHATgTAJQgKAFgLAAQgJAAgJgEg");
	this.shape_139.setTransform(1850,239.1);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#2B2B2B").s().p("AAkBqIh/grQgUgGgJgTQgJgTAHgTIAXhIQAHgVATgIQATgKATAGIB/ArQAUAHAJASQAJATgHASIgXBJQgHAUgTAJQgLAGgLAAQgIAAgIgCg");
	this.shape_140.setTransform(1841,269.1);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#2B2B2B").s().p("AgECIIiCh1QgPgNgBgUQgBgVANgPIBJhRQAOgQAVgBQAUgBAPAOICCB1QAPANABAUQACAVgOAPIhJBRQgOAQgVABIgEAAQgSAAgNgNg");
	this.shape_141.setTransform(1878.3,572.6);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#2B2B2B").s().p("AgECIIiCh1QgPgNgBgUQgBgVANgPIBJhRQAOgQAVgBQAUgBAPAOICCB1QAPANABAUQACAVgOAPIhJBRQgOAQgVABIgEAAQgSAAgNgNg");
	this.shape_142.setTransform(1843.3,546.6);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#2B2B2B").s().p("AAABwIhqhSQgRgNgCgUQgEgUANgRIAvg9QANgQAUgDQAVgDAPAMIBsBSQAQANADATQACAVgMAQIgvA+QgMAQgVADIgIABQgQAAgNgKg");
	this.shape_143.setTransform(1924,536.1);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#2B2B2B").s().p("AAABvIhrhSQgQgMgDgUQgDgUANgRIAvg9QAMgQAVgDQAUgDAQAMIBrBSQARANACATQAEAVgNAQIgvA+QgMARgVACIgIABQgQAAgNgLg");
	this.shape_144.setTransform(1868,493.1);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#2B2B2B").s().p("AgYCOIhQgqQgWgMgGgXQgIgYAMgWIBJiIQAMgWAXgHQAXgHAWAMIBPAqQAXAMAGAXQAIAYgMAWIhKCIQgMAWgXAHQgJACgJAAQgNAAgNgHg");
	this.shape_145.setTransform(2098.4,386.6);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#2B2B2B").s().p("AAYCGIiXhWQgRgKgGgUQgFgTAKgSIA2hfQAKgSAUgGQAUgFARAKICXBWQASAKAGAUQAFATgKASIg2BfQgKASgUAGQgHACgHAAQgMAAgMgHg");
	this.shape_146.setTransform(1823.4,411.6);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#2B2B2B").s().p("AAYCGIiXhWQgRgKgGgUQgFgTAKgSIA2hfQAKgSAUgGQAUgFASAKICXBWQASAKAFAUQAFATgKASIg2BfQgKASgUAGQgHACgHAAQgMAAgMgHg");
	this.shape_147.setTransform(1965.3,504.6);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#2B2B2B").s().p("AAYCGIiXhWQgRgKgGgUQgFgTAKgSIA2hfQAKgSAUgGQAUgFASAKICXBWQASAKAFAUQAFATgKASIg2BfQgKASgUAGQgHACgHAAQgMAAgMgHg");
	this.shape_148.setTransform(1925.3,469.6);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#2B2B2B").s().p("AAYCGIiXhWQgRgKgGgUQgFgTAKgSIA2hfQAKgSAUgGQAUgFASAKICXBWQASAKAFAUQAFATgKASIg2BfQgKASgUAGQgHACgHAAQgMAAgMgHg");
	this.shape_149.setTransform(1885.3,442.6);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#2B2B2B").s().p("AgcDUIhyg1QgSgIgHgUQgHgTAIgTICCkYQAJgSATgHQATgHASAIIByA1QASAIAHAUQAHATgIATIiCEYQgJASgTAHQgJADgIAAQgKAAgKgEg");
	this.shape_150.setTransform(1904,276.4);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#2B2B2B").s().p("ABWCrIkSiOQgSgKgHgTQgGgTAKgSIA5hvQAJgTAUgGQAUgGASAJIESCOQASAKAHASQAGAUgKASIg5BvQgJATgUAGQgIACgIAAQgLAAgLgFg");
	this.shape_151.setTransform(1965,316.4);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#191919").s().p("AHMIZQiPiDuBmcQkZiBlCiNIkKh0IGQjmIatKTIMWHWQi+A8jbAiQiUAWhzAAQjfAAhfhWg");
	this.shape_152.setTransform(2275,703.2);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#191919").s().p("Ap1jlIHMiWIB6AzQCSA+B7A6QGLC8ANBQQAMBRl8CAQh2AniQApIh3Afg");
	this.shape_153.setTransform(1891.5,650.4);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#191919").s().p("AjyVXQn0hVheheQgqgpATg3QAMglA6hMQBFhdAagvQAxhYAEhVQALjjkukGQo/nzkJl3QhTh1gphbIgahDMAvpgGQICbA4QC2BHCJBMQG6D0imDLQhVBqlmHlQlOHGjdEGQqWMUmMAAQggAAgfgGg");
	this.shape_154.setTransform(2241.3,311.2);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#191919").s().p("AUYcDQhOgRhNgfQidhCh3hwQgzgvg8hOQg5hRgeg+QhIiQgiisQgciOgEi6QgDiagRiWQgklMhzjpQgag2gshFQgmg4gwg4QhVhhh8hlIh2hiQhIg7gzgwIg2gvIgagYIiQhzQhUhCiih2Ij8i2Qiqh9hTg/QiMhqhuhbIAPgcQBFARBVAcQBFAWBSAeQCLAyCdBFIBJAiIBIAhICPBIIBHAnIBHAnQAXANAuAdIBGAqICIBfIAiAaIAhAcIBAA3IBvBoQBFA/AwAwQBDBEAvA3QA6BDAwBFQAxBHAqBNIAnBOIAjBPIAPAnIA0CiIAKAqIARBRQAdCcAGCsQAFCcgLCpQgKCnAOCDQAQCcA0CDQAVA6ArBLIAdAuIA5BJQBfBvCKBLQBCAkBKAaQAdALAsALQAoALAjAFIgCAgQhJgChXgUg");
	this.shape_155.setTransform(2832,710.3);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f().s("#191919").ss(20).p("A3pNdIAqhbQA3hvBAhdQDOkpDagNQBogGC8AvQE0BMAYAFQDGAlCSgWQC6gdCRiAQB+hvCRitQBQhgCci7QCLidCPhnQCziBDohT");
	this.shape_156.setTransform(3040.9,349.3);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#191919").s().p("Al/bzQiTgEhLgEQjUgLjlgYQhpgLhygQQh9gRhdgRIABgaIG3gVQD2gNC/gNIDZgRQBbgHB9gNQD0gbCzghQBvgVBcgZQBwgfBIgiQAwgXAZgSQAegWAKgSIAthWIA2hiQAshNBDhxIBwi6QBAhtAphNQA3hqAchMQAJgXAEgSQAGgUABgOIABgKIAAgDIgBgGQgFgRgKgVQgQgighg0QgagogiguQhGhahFhJQhKhPhShGQiwiVi2hgQhggzhkgoQhmgohlghQh2gmhVgYIjNg7Qg0gPg6gVQhGgcgmgSQh1g3hZg/QgzgjgrgnQgwgrgmgpQgtg1gdgrIgggzQgQgbgMgaQg1hugPh2QgIg7ADg6QACgfAFgbQAFgiAIgXIAZAEQADAaAGAaIAMA0QAPA0AUAvQAnBdA+BSQByCVC7BrQCYBXDgBGICfA4IA0AXQBpAvBgA4QBUAwBsBIQA+ApB6BVIC2CAQBqBNBJA2QBwBUBBA0QBpBUBDA+QAsAnAnAoQAuAxAgArQAXAhAOAaIAIAUIAHAXQAGAXACAVQADAigEAqQgFAmgHAcQgMA3gXA+QgTA0gYA4QgoBeg3BvQhbC2hxDQIhjC2IgMAUQgqA+hJAzQg0AihEAeQhhApiHAeQhjAViBAQQjHAYj4AEIhdABIiCgBg");
	this.shape_157.setTransform(2772.3,351.7);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f().s("#191919").ss(42).p("EhROgj0QQrCIILI+QBeBpCPDAQCJCmCwB1QDMCJERBGQAEAAEAA8QCtApCMAqQE/BjESCbQBJApCKBRQB6BEByAuQFFCGFEgRQCLgICygjQBogUD3g7QF3hYD2grQGYhGGxgYQHAgZDYgDQFogFECAfQKDBQETFgQA6BKAnBYQAcA8AxCNQCNGUClFrQBQCvDMHDQCwGABBBz");
	this.shape_158.setTransform(2330.4,558.7);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f().s("#636363").ss(3).p("AGXocQjIDgjJD3QmSHsgGBx");
	this.shape_159.setTransform(2315.3,305.3);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#212121").s().p("EhqtAotMAAAhRZMDVbAAAMAAABRZg");
	this.shape_160.setTransform(2502,489.4);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59,this.shape_60,this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85,this.shape_86,this.shape_87,this.shape_88,this.shape_89,this.shape_90,this.shape_91,this.shape_92,this.shape_93,this.shape_94,this.shape_95,this.shape_96,this.shape_97,this.shape_98,this.shape_99,this.shape_100,this.shape_101,this.shape_102,this.shape_103,this.shape_104,this.shape_105,this.shape_106,this.shape_107,this.shape_108,this.shape_109,this.shape_110,this.shape_111,this.shape_112,this.shape_113,this.shape_114,this.shape_115,this.shape_116,this.shape_117,this.shape_118,this.shape_119,this.shape_120,this.shape_121,this.shape_122,this.shape_123,this.shape_124,this.shape_125,this.shape_126,this.shape_127,this.shape_128,this.shape_129,this.shape_130,this.shape_131,this.shape_132,this.shape_133,this.shape_134,this.shape_135,this.shape_136,this.shape_137,this.shape_138,this.shape_139,this.shape_140,this.shape_141,this.shape_142,this.shape_143,this.shape_144,this.shape_145,this.shape_146,this.shape_147,this.shape_148,this.shape_149,this.shape_150,this.shape_151,this.shape_152,this.shape_153,this.shape_154,this.shape_155,this.shape_156,this.shape_157,this.shape_158,this.shape_159,this.shape_160];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0, new cjs.Rectangle(1789.5,236.9,1442.9,655.1), null);


(lib.Path_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#5555FF").ss(0.5).p("AfrHLMg/VAAAQgxAAgjgjQgkgkAAgxIAAqlQAAgxAkgjQAjgkAxAAMA/VAAAQAxAAAkAkQAjAjAAAxIAAKlQAAAxgjAkQgkAjgxAAg");
	this.shape.setTransform(214.9,46.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(-0.7,-0.7,431.3,93.8), null);


(lib.Path_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D1D1D1").ss(0.5).p("AAcAAQAAAMgIAIQgIAIgMAAQgLAAgIgIQgIgIAAgMQAAgLAIgIQAIgIALAAQAMAAAIAIQAIAIAAALg");
	this.shape_1.setTransform(3.1,3.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_2, new cjs.Rectangle(-0.7,-0.7,7.6,7.6), null);


(lib.PlayButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		playSound("kokokuo");
		playSound("buzz");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF5943").s().p("A2zD3Qkdgxidg/QiihAAAhHQAAhGCihBQCdg+EdgwQJdhnNWABQNXgBJdBnQEdAwCdA+QCiBBAABGQAABHiiBAQidA/kdAxQpdBltXAAQtWAApdhlg");
	this.shape.setTransform(0,-21.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6D54").s().p("A2zErQkdgtidg6Qiig9AAhCIAAnOMBAfAAAIAAHOQAABCiiA9QidA6kdAtQpdBftXAAQtWAApdhfg");
	this.shape_1.setTransform(0,17);

	this.instance = new lib.PlayButtonHover();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-206.4,-56.4,412.9,112.9);


(lib.learn2movie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var bob_distance = 6;
		createjs.Tween.get(this.lesson2_animated, {loop: -1})
			.to({y:this.lesson2_animated.y - bob_distance}, 2000, createjs.Ease.cubicInOut)
			.to({y:this.lesson2_animated.y}, 2000, createjs.Ease.cubicInOut);

		/*stage.update()*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.lesson2_animated = new lib.learn2draw();
	this.lesson2_animated.name = "lesson2_animated";
	this.lesson2_animated.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.lesson2_animated).wait(1));

}).prototype = getMCSymbolPrototype(lib.learn2movie, new cjs.Rectangle(-26.4,-25.5,52.9,51.1), null);


(lib.Learn2Button = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		playSound("buzz");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.instance = new lib.learn2movie();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:1.7,scaleY:1.7,y:-4},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.4,-25.5,52.9,51.1);


(lib.learnmovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var bob_distance = 9;
		createjs.Tween.get(this.lesson1_animated, {loop: -1})
			.to({y:this.lesson1_animated.y - bob_distance}, 4000, createjs.Ease.cubicInOut)
			.to({y:this.lesson1_animated.y}, 4000, createjs.Ease.cubicInOut);

		/*stage.update()*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.lesson1_animated = new lib.learndraw();
	this.lesson1_animated.name = "lesson1_animated";
	this.lesson1_animated.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.lesson1_animated).wait(1));

}).prototype = getMCSymbolPrototype(lib.learnmovie, new cjs.Rectangle(-26.4,-25.5,52.9,51.1), null);


(lib.LearnButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		playSound("buzz");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.instance = new lib.learnmovie();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY:-0.1,scaleX:2.06,scaleY:2.06,y:-22.2},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.4,-25.5,52.9,51.1);


(lib.lab2movie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var bob_distance = 11;
		createjs.Tween.get(this.lab2_animated, {loop: -1})
			.to({y:this.lab2_animated.y - bob_distance}, 2500, createjs.Ease.cubicInOut)
			.to({y:this.lab2_animated.y}, 2500, createjs.Ease.cubicInOut);

		/*stage.update()*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.lab2_animated = new lib.lab2draw();
	this.lab2_animated.name = "lab2_animated";
	this.lab2_animated.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.lab2_animated).wait(1));

}).prototype = getMCSymbolPrototype(lib.lab2movie, new cjs.Rectangle(-74,-71.6,148.1,143.4), null);


(lib.Lab2Button = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		playSound("taipei_101_damper");
		playSound("buzz");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.instance = new lib.lab2movie();
	this.instance.parent = this;
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:1.56,scaleY:1.56,y:-29},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-71.6,148.1,143.4);


(lib.lab1movie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var bob_distance = 8;
		createjs.Tween.get(this.lab1_animated, {loop: -1})
			.to({y:this.lab1_animated.y - bob_distance}, 4500, createjs.Ease.cubicInOut)
			.to({y:this.lab1_animated.y}, 4500, createjs.Ease.cubicInOut);

		/*stage.update()*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.lab1_animated = new lib.lab1draw();
	this.lab1_animated.name = "lab1_animated";
	this.lab1_animated.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.lab1_animated).wait(1));

}).prototype = getMCSymbolPrototype(lib.lab1movie, new cjs.Rectangle(-42.9,-41.5,85.9,83.1), null);


(lib.Lab1Button = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		playSound("buzz");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.instance = new lib.lab1movie();
	this.instance.parent = this;
	this.instance.setTransform(42.9,41.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY:0.1,scaleX:1.47,scaleY:1.47,y:23.7},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,85.9,83.1);


(lib.intromovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var bob_distance = 8;
		createjs.Tween.get(this.intro_animated, {loop: -1})
			.to({y:this.intro_animated.y - bob_distance}, 5000, createjs.Ease.cubicInOut)
			.to({y:this.intro_animated.y}, 5000, createjs.Ease.cubicInOut);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.intro_animated = new lib.intodraw();
	this.intro_animated.name = "intro_animated";
	this.intro_animated.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.intro_animated).wait(1));

}).prototype = getMCSymbolPrototype(lib.intromovie, new cjs.Rectangle(-26.4,-25.5,52.9,51.1), null);


(lib.IntroButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		playSound("buzz");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.instance = new lib.intromovie();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:1.83,scaleY:1.83,y:-21.9},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.4,-25.5,52.9,51.1);


(lib.Path_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Group();
	this.instance.parent = this;
	this.instance.setTransform(340.1,136.2,1,1,0,0,0,340.1,136.2);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0,0,680.2,272.4), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask.setTransform(2502,384);

	// Layer_3
	this.instance = new lib.ClipGroup_0();
	this.instance.parent = this;
	this.instance.setTransform(2505,636.1,1,1,0,0,0,2505,566);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#212121").s().p("AnLHtIAAjvIA8AAIAAAqICMAAIAAhTIigAAIAAgHIAwgIIBwgTIAAi3IigAAIAAgHIAwgIIBwgTIAAi4Ij6AAIAAgVIDLhQQDZhfBEhKIApAAQBABKDbBfQBuAvBhAhIAAAVIkEAAIAAC3QBaAQBQAMIAAAHIiqAAIAAC2QBaAQBQAMIAAAHIiqAAIAABTIAeAAIAADFg");
	this.shape.setTransform(2890,267.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#212121").s().p("Ak6P5IA/l/IgNAAIAAhJIAcAAIg6hzIA1AAIg1hoIBPAAIhFiHIBAAAIhAh8IA6AAIg6hxIA7AAIhFiHIBPAAIhFiHIBAAAIhAh9IA6AAIg6hyIBuAAIAAg/IAsAAIgihTIAiAAIgihIIBkAAIAAgpIAZAAIguggIAzAAIAAimIABAAIAhgVIAjAVIAACmIAzAAIguAgIAZAAIAAApIBkAAIgiBIIAiAAIgjBTIA3AAIAAA/IBuAAIg7ByIA7AAIhAB9IBAAAIhGCHIA8AAIhGCHIBQAAIg7BxIA7AAIhAB8IBAAAIhGCHIA8AAIg2BoIA2AAIg7BzIAnAAIAABJIgOAAIBAF/g");
	this.shape_1.setTransform(2802.5,212.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#212121").s().p("AgeAJIAAgSIA9AAIAAASg");
	this.shape_2.setTransform(2692,243.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#212121").s().p("AgnAFIAAgJIBPAAIAAAJg");
	this.shape_3.setTransform(2692,245.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#212121").s().p("AgeATIAHglIAuAAIAIAlg");
	this.shape_4.setTransform(2692,246.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#212121").s().p("AgnAOIAAgbIBPAAIAAAbg");
	this.shape_5.setTransform(2692,249);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#212121").s().p("AgeFFIAAqJIA9AAIAAKJg");
	this.shape_6.setTransform(2692,282);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#212121").s().p("AjQBVIAAipIGhAAIAACoQhbhBhyAAQhyAAhaBCg");
	this.shape_7.setTransform(2667.9,262.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#212121").s().p("AgbAJIAAgRIA2AAIAAARg");
	this.shape_8.setTransform(2731.5,251);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#212121").s().p("AgiAEIAAgHIBFAAIAAAHg");
	this.shape_9.setTransform(2731.5,252.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#212121").s().p("AgbASIAHgiIAoAAIAHAig");
	this.shape_10.setTransform(2731.5,253.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#212121").s().p("AgiANIAAgZIBFAAIAAAZg");
	this.shape_11.setTransform(2731.5,255.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#212121").s().p("AgbEuIAApbIA2AAIAAJbg");
	this.shape_12.setTransform(2731.5,286.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#212121").s().p("Ai3BPIAAidIFuAAIAACcQhOg8hlAAQhjAAhRA9g");
	this.shape_13.setTransform(2710.4,268.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#212121").s().p("AgXAIIAAgPIAvAAIAAAPg");
	this.shape_14.setTransform(2619,247.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#212121").s().p("AgeAEIAAgHIA8AAIAAAHg");
	this.shape_15.setTransform(2619,249.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#212121").s().p("AgXAQIAGgfIAiAAIAHAfg");
	this.shape_16.setTransform(2619,250.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#212121").s().p("AgeAMIAAgXIA8AAIAAAXg");
	this.shape_17.setTransform(2619,252.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#212121").s().p("AgXEbIAAo1IAvAAIAAI1g");
	this.shape_18.setTransform(2619,281);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#212121").s().p("AidBKIAAiTIE7AAIAACSQhFg5hWAAQhVAAhFA6g");
	this.shape_19.setTransform(2600.8,264.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#212121").s().p("AgXAIIAAgPIAvAAIAAAPg");
	this.shape_20.setTransform(2764,259.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#212121").s().p("AgeAEIAAgHIA8AAIAAAHg");
	this.shape_21.setTransform(2764,260.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#212121").s().p("AgXAQIAGgfIAiAAIAHAfg");
	this.shape_22.setTransform(2764,261.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#212121").s().p("AgeAMIAAgXIA8AAIAAAXg");
	this.shape_23.setTransform(2764,263.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#212121").s().p("AgXEbIAAo1IAvAAIAAI1g");
	this.shape_24.setTransform(2764,292.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#212121").s().p("AidBKIAAiTIE7AAIAACSQhEg5hXAAQhVABhFA5g");
	this.shape_25.setTransform(2745.8,275.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#212121").s().p("AliLHIAApPIAUAAIAAg/IAUAAIAArBIAeAAIAAg+IEEAAIAAA+IDRAAIAAEjICqAAIAAQsg");
	this.shape_26.setTransform(2634.5,238.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#212121").s().p("AjlI2IAAwsIAyAAIAAg/IFnAAIAAA/IAyAAIAAQsg");
	this.shape_27.setTransform(2567,254.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#212121").s().p("ApNIhIDFrLIglAAIAAggIAoAAIAAg0IgoAAIAAgfIB5AAIA/gfIhUAAIAAg0IhGAAIAAgKIAKAAICigvQCrg3AogkQgFgDgEgFQgEgFAAgEQAAgFAHgDQAIgDAKAAQAJAAAHADQAIADAAAFQAAAEgEAFQgEAFgGADQApAkCrA3QBVAbBNAUIAKAAIAAAKIg8AAIAAA0IhXAAIA/AfIByAAIAAAfIgeAAIAAA0IAeAAIAAAgIgcAAIDGLLg");
	this.shape_28.setTransform(2478,267.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#212121").s().p("AgYAaIAYgzIAZAzg");
	this.shape_29.setTransform(2399.5,165.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#212121").s().p("AheA+IAAh7IC9AAIAAB7g");
	this.shape_30.setTransform(2399.5,173.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#212121").s().p("AiGAqIAAhSIENAAIAABSg");
	this.shape_31.setTransform(2399.5,177.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#212121").s().p("AikAkIAAhHIFJAAIAABHg");
	this.shape_32.setTransform(2399.5,180);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#212121").s().p("AjCLcIAA23IGFAAIAAW3g");
	this.shape_33.setTransform(2399.5,252.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#212121").s().p("AkXIXIAAwtIIvAAIAAQtg");
	this.shape_34.setTransform(2337,262.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#212121").s().p("AjMIXIAAgqIgKAAIAAgKIAKAAIAAgVIgKAAIAAgKIAKAAIAAgVIgKAAIAAgLIAKAAIAAgUIgKAAIAAgKIAKAAIAAgWIgKAAIAAgKIAKAAIAAgUIgKAAIAAgLIAKAAIAAgVIgKAAIAAgKIAKAAIAAgVIgKAAIAAgKIAKAAIAAgVIgKAAIAAgLIAKAAIAAgUIgKAAIAAgKIAKAAIAAgVIgKAAIAAgLIAKAAIAAgVIgKAAIAAgKIAKAAIAAgUIgKAAIAAgLIAKAAIAAgVIgKAAIAAgKIAKAAIAAgVIgKAAIAAgKIAKAAIAAgVIgKAAIAAgLIAKAAIAAgTIgKAAIAAgKIAKAAIAAgWIgKAAIAAgKIAKAAIAAgUIgKAAIAAgLIAKAAIAAgVIgKAAIAAgKIAKAAIAAgVIgKAAIAAgKIAKAAIAAgVIgKAAIAAgLIAKAAIAAgUIgKAAIAAgKIAKAAIAAgVIgKAAIAAgLIAKAAIAAgVIgKAAIAAgKIAKAAIAAgUIgKAAIAAgLIAKAAIAAgVIgKAAIAAgKIAKAAIAAgVIgKAAIAAgKIAKAAIAAgVIgKAAIAAgLIAKAAIAAgUIgKAAIAAgKIAKAAIAAgWIgKAAIAAgKIAKAAIAAgUIgKAAIAAgLIAKAAIAAgVIAoAAIAAgfIFJAAIAAAfIAoAAIAAAVIAKAAIAAALIgKAAIAAAUIAKAAIAAAKIgKAAIAAAWIAKAAIAAAKIgKAAIAAAUIAKAAIAAALIgKAAIAAAVIAKAAIAAAKIgKAAIAAAVIAKAAIAAAKIgKAAIAAAVIAKAAIAAALIgKAAIAAAUIAKAAIAAAKIgKAAIAAAVIAKAAIAAALIgKAAIAAAVIAKAAIAAAKIgKAAIAAAUIAKAAIAAALIgKAAIAAAVIAKAAIAAAKIgKAAIAAAVIAKAAIAAAKIgKAAIAAAVIAKAAIAAALIgKAAIAAAUIAKAAIAAAKIgKAAIAAAWIAKAAIAAAKIgKAAIAAATIAKAAIAAALIgKAAIAAAVIAKAAIAAAKIgKAAIAAAVIAKAAIAAAKIgKAAIAAAVIAKAAIAAALIgKAAIAAAUIAKAAIAAAKIgKAAIAAAVIAKAAIAAALIgKAAIAAAVIAKAAIAAAKIgKAAIAAAUIAKAAIAAALIgKAAIAAAVIAKAAIAAAKIgKAAIAAAVIAKAAIAAAKIgKAAIAAAVIAKAAIAAALIgKAAIAAAUIAKAAIAAAKIgKAAIAAAWIAKAAIAAAKIgKAAIAAAUIAKAAIAAALIgKAAIAAAVIAKAAIAAAKIgKAAIAAAVIAKAAIAAAKIgKAAIAAAqg");
	this.shape_35.setTransform(2280.5,273.5);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#212121").s().p("AkXJ0IAAyfID6hIIAABfIE1grIAASzg");
	this.shape_36.setTransform(2224,256.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#212121").s().p("Ai0E9IAAk3IjIAUIDIjPIAAhdIF7gqIAAC1IC2BXIi2ASIAAFbg");
	this.shape_37.setTransform(2168.1,288);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#212121").s().p("AjgG0IAArBIAoAAIAAhTIAoAAIAAg0IAoAAIAAgfIBtAAIAAAfIAoAAIAAA0ICCAAIAABTIAyAAIAALBg");
	this.shape_38.setTransform(2115.5,273);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#C6C6C6").s().p("AkXIDIAAwFIIvAAIAAQFg");
	this.shape_39.setTransform(1910,285.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#C6C6C6").s().p("AjbJzIAAyDIAiAAIAAgYIAiAAIAAgZIAtAAIAAgxIDVAAIAAAxIAtAAIAAAZIAiAAIAAAYIAiAAIAASDg");
	this.shape_40.setTransform(3142,297.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#C6C6C6").s().p("AjgGkIAAqnIAoAAIAAhQIAoAAIAAgyIAoAAIAAgeIBtAAIAAAeIAoAAIAAAyICCAAIAABQIAyAAIAAKng");
	this.shape_41.setTransform(1868.5,286);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#C6C6C6").s().p("AlyuNIGZBFIAAiXIFKByIACdMIrjABg");
	this.shape_42.setTransform(2602,209.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#C6C6C6").s().p("AkXPKIAA+TIIvAAIAAeTg");
	this.shape_43.setTransform(2231,217);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#DDDDDD").s().p("AlJlOIFsAZIAAg3IEnAqIAAKvIqTAAg");
	this.shape_44.setTransform(3185,300.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#C6C6C6").s().p("AlJlOIFsAZIAAg3IEnAqIAAKvIqTAAg");
	this.shape_45.setTransform(3062,291.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#C6C6C6").s().p("AjvKeIAAw8IA1AAIAAiAICLAAIAAhPIAqAAIAAgwIB1AAIAAAwIAqAAIAABPIArAAIAACAIArAAIAAQ8g");
	this.shape_46.setTransform(3019,254);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#C6C6C6").s().p("AjbTpMAAAgkMIAiAAIAAgxIAiAAIAAgyIAtAAIAAhiIDVAAIAABiIAtAAIAAAyIAiAAIAAAxIAiAAMAAAAkMg");
	this.shape_47.setTransform(2710,234.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#DDDDDD").s().p("AjgGlIAAqpIAoAAIAAhQIAoAAIAAgxIAoAAIAAgfIBtAAIAAAfIAoAAIAAAxICCAAIAABQIAyAAIAAKpg");
	this.shape_48.setTransform(2429.5,286.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#DDDDDD").s().p("AkXMGIAA4LIIvAAIAAYLg");
	this.shape_49.setTransform(2374,321.6);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#DDDDDD").s().p("AkXMGIAA4LIIvAAIAAYLg");
	this.shape_50.setTransform(2506,264.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#DDDDDD").s().p("AjMQrIAAhSIgKAAIAAgVIAKAAIAAgqIgKAAIAAgUIAKAAIAAgqIgKAAIAAgUIAKAAIAAgqIgKAAIAAgVIAKAAIAAgqIgKAAIAAgUIAKAAIAAgqIgKAAIAAgUIAKAAIAAgqIgKAAIAAgVIAKAAIAAgpIgKAAIAAgVIAKAAIAAgpIgKAAIAAgVIAKAAIAAgpIgKAAIAAgVIAKAAIAAgpIgKAAIAAgVIAKAAIAAgpIgKAAIAAgVIAKAAIAAgpIgKAAIAAgVIAKAAIAAgqIgKAAIAAgUIAKAAIAAgqIgKAAIAAgVIAKAAIAAgpIgKAAIAAgVIAKAAIAAgpIgKAAIAAgUIAKAAIAAgqIgKAAIAAgVIAKAAIAAgoIgKAAIAAgWIAKAAIAAgpIgKAAIAAgVIAKAAIAAgpIgKAAIAAgVIAKAAIAAgpIgKAAIAAgVIAKAAIAAgpIgKAAIAAgVIAKAAIAAgqIgKAAIAAgUIAKAAIAAgqIgKAAIAAgUIAKAAIAAgqIgKAAIAAgUIAKAAIAAgqIgKAAIAAgVIAKAAIAAgpIgKAAIAAgVIAKAAIAAgqIgKAAIAAgUIAKAAIAAgpIgKAAIAAgWIAKAAIAAgoIgKAAIAAgWIAKAAIAAgpIgKAAIAAgVIAKAAIAAgpIAoAAIAAg+IFJAAIAAA+IAoAAIAAApIAKAAIAAAVIgKAAIAAApIAKAAIAAAWIgKAAIAAAoIAKAAIAAAWIgKAAIAAApIAKAAIAAAUIgKAAIAAAqIAKAAIAAAVIgKAAIAAApIAKAAIAAAVIgKAAIAAAqIAKAAIAAAUIgKAAIAAAqIAKAAIAAAUIgKAAIAAAqIAKAAIAAAUIgKAAIAAAqIAKAAIAAAVIgKAAIAAApIAKAAIAAAVIgKAAIAAApIAKAAIAAAVIgKAAIAAApIAKAAIAAAVIgKAAIAAApIAKAAIAAAWIgKAAIAAAoIAKAAIAAAVIgKAAIAAAqIAKAAIAAAUIgKAAIAAApIAKAAIAAAVIgKAAIAAApIAKAAIAAAVIgKAAIAAAqIAKAAIAAAUIgKAAIAAAqIAKAAIAAAVIgKAAIAAApIAKAAIAAAVIgKAAIAAApIAKAAIAAAVIgKAAIAAApIAKAAIAAAVIgKAAIAAApIAKAAIAAAVIgKAAIAAApIAKAAIAAAVIgKAAIAAApIAKAAIAAAVIgKAAIAAAqIAKAAIAAAUIgKAAIAAAqIAKAAIAAAUIgKAAIAAAqIAKAAIAAAVIgKAAIAAAqIAKAAIAAAUIgKAAIAAAqIAKAAIAAAUIgKAAIAAAqIAKAAIAAAVIgKAAIAABSg");
	this.shape_51.setTransform(2649.5,209.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#DDDDDD").s().p("AjYLSIAArEIjuAtIDunYIAAjVIHFhfIAAGbIDaDHIjaApIAAMYg");
	this.shape_52.setTransform(2551.5,269.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#DDDDDD").s().p("AjgL1IAAzJIAoAAIAAiQIAoAAIAAhaIAoAAIAAg2IBtAAIAAA2IAoAAIAABaICCAAIAACQIAyAAIAATJg");
	this.shape_53.setTransform(2671.5,252.3);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#DDDDDD").s().p("AjgJ3IAAv9IAoAAIAAh4IAoAAIAAhLIAoAAIAAgtIBtAAIAAAtIAoAAIAABLICCAAIAAB4IAyAAIAAP9g");
	this.shape_54.setTransform(2464.5,265.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#C6C6C6").s().p("AlypcIGZAtIAAhkIFKBMIACTbIrjAAg");
	this.shape_55.setTransform(2813,255);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#C6C6C6").s().p("AlypcIGZAtIAAhkIFKBMIACTbIrjAAg");
	this.shape_56.setTransform(2168,251);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#DDDDDD").s().p("AjMNcIAAhDIgKAAIAAgRIAKAAIAAghIgKAAIAAgRIAKAAIAAghIgKAAIAAgRIAKAAIAAgiIgKAAIAAgQIAKAAIAAghIgKAAIAAgRIAKAAIAAgiIgKAAIAAgQIAKAAIAAghIgKAAIAAgRIAKAAIAAgiIgKAAIAAgRIAKAAIAAghIgKAAIAAgQIAKAAIAAgiIgKAAIAAgRIAKAAIAAghIgKAAIAAgQIAKAAIAAgiIgKAAIAAgRIAKAAIAAghIgKAAIAAgRIAKAAIAAghIgKAAIAAgRIAKAAIAAgiIgKAAIAAgQIAKAAIAAghIgKAAIAAgRIAKAAIAAghIgKAAIAAgRIAKAAIAAggIgKAAIAAgRIAKAAIAAgiIgKAAIAAgRIAKAAIAAghIgKAAIAAgQIAKAAIAAgiIgKAAIAAgRIAKAAIAAghIgKAAIAAgRIAKAAIAAghIgKAAIAAgRIAKAAIAAgiIgKAAIAAgQIAKAAIAAghIgKAAIAAgRIAKAAIAAghIgKAAIAAgRIAKAAIAAgiIgKAAIAAgQIAKAAIAAghIgKAAIAAgSIAKAAIAAghIgKAAIAAgRIAKAAIAAghIgKAAIAAgQIAKAAIAAgiIgKAAIAAgRIAKAAIAAghIgKAAIAAgRIAKAAIAAghIAoAAIAAgyIFJAAIAAAyIAoAAIAAAhIAKAAIAAARIgKAAIAAAhIAKAAIAAARIgKAAIAAAiIAKAAIAAAQIgKAAIAAAhIAKAAIAAARIgKAAIAAAhIAKAAIAAASIgKAAIAAAhIAKAAIAAAQIgKAAIAAAiIAKAAIAAARIgKAAIAAAhIAKAAIAAARIgKAAIAAAhIAKAAIAAAQIgKAAIAAAiIAKAAIAAARIgKAAIAAAhIAKAAIAAARIgKAAIAAAhIAKAAIAAARIgKAAIAAAiIAKAAIAAAQIgKAAIAAAhIAKAAIAAARIgKAAIAAAiIAKAAIAAARIgKAAIAAAgIAKAAIAAARIgKAAIAAAhIAKAAIAAARIgKAAIAAAhIAKAAIAAAQIgKAAIAAAiIAKAAIAAARIgKAAIAAAhIAKAAIAAARIgKAAIAAAhIAKAAIAAARIgKAAIAAAiIAKAAIAAAQIgKAAIAAAhIAKAAIAAARIgKAAIAAAiIAKAAIAAAQIgKAAIAAAhIAKAAIAAARIgKAAIAAAiIAKAAIAAARIgKAAIAAAhIAKAAIAAAQIgKAAIAAAiIAKAAIAAARIgKAAIAAAhIAKAAIAAAQIgKAAIAAAiIAKAAIAAARIgKAAIAAAhIAKAAIAAARIgKAAIAAAhIAKAAIAAARIgKAAIAABDg");
	this.shape_57.setTransform(2268.5,230);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#DDDDDD").s().p("AkiOiIAAhIIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAglIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgTIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAglIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgjIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAglIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAglIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgTIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIgOAAIAAgSIAOAAIAAgkIA5AAIAAg2IHTAAIAAA2IA5AAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAATIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAlIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAlIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAjIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAlIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAATIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAAAlIAOAAIAAASIgOAAIAAAkIAOAAIAAASIgOAAIAABIg");
	this.shape_58.setTransform(2876.5,235);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#DDDDDD").s().p("AluRvIAAhZIgSAAIAAgVIASAAIAAgtIgSAAIAAgVIASAAIAAgsIgSAAIAAgXIASAAIAAgsIgSAAIAAgWIASAAIAAgsIgSAAIAAgWIASAAIAAgsIgSAAIAAgWIASAAIAAgsIgSAAIAAgWIASAAIAAgsIgSAAIAAgXIASAAIAAgrIgSAAIAAgXIASAAIAAgsIgSAAIAAgVIASAAIAAgsIgSAAIAAgXIASAAIAAgrIgSAAIAAgXIASAAIAAgsIgSAAIAAgWIASAAIAAgsIgSAAIAAgWIASAAIAAgsIgSAAIAAgWIASAAIAAgsIgSAAIAAgWIASAAIAAgrIgSAAIAAgXIASAAIAAgsIgSAAIAAgVIASAAIAAgtIgSAAIAAgVIASAAIAAgsIgSAAIAAgXIASAAIAAgsIgSAAIAAgWIASAAIAAgsIgSAAIAAgWIASAAIAAgsIgSAAIAAgWIASAAIAAgsIgSAAIAAgWIASAAIAAgsIgSAAIAAgWIASAAIAAgsIgSAAIAAgXIASAAIAAgsIgSAAIAAgVIASAAIAAgtIgSAAIAAgVIASAAIAAgsIgSAAIAAgXIASAAIAAgsIgSAAIAAgWIASAAIAAgsIgSAAIAAgWIASAAIAAgsIgSAAIAAgWIASAAIAAgsIBIAAIAAhCIJNAAIAABCIBIAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAXIgSAAIAAAsIASAAIAAAVIgSAAIAAAtIASAAIAAAVIgSAAIAAAsIASAAIAAAXIgSAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAXIgSAAIAAAsIASAAIAAAVIgSAAIAAAtIASAAIAAAVIgSAAIAAAsIASAAIAAAXIgSAAIAAArIASAAIAAAWIgSAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAXIgSAAIAAArIASAAIAAAXIgSAAIAAAsIASAAIAAAVIgSAAIAAAsIASAAIAAAXIgSAAIAAArIASAAIAAAXIgSAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAWIgSAAIAAAsIASAAIAAAXIgSAAIAAAsIASAAIAAAVIgSAAIAAAtIASAAIAAAVIgSAAIAABZg");
	this.shape_59.setTransform(2326.5,216.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#DDDDDD").s().p("AjgEYIAAnEIAoAAIAAg2IAoAAIAAghIAoAAIAAgUIBtAAIAAAUIAoAAIAAAhICCAAIAAA2IAyAAIAAHEg");
	this.shape_60.setTransform(2890.5,282);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#DDDDDD").s().p("AkXIDIAAwFIIvAAIAAQFg");
	this.shape_61.setTransform(2967,277.5);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#C6C6C6").s().p("AjgKjIAAxEIAoAAIAAiAIAoAAIAAhRIAoAAIAAgwIBtAAIAAAwIAoAAIAABRICCAAIAACAIAyAAIAAREg");
	this.shape_62.setTransform(2925.5,264.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#DDDDDD").s().p("AjgEYIAAnEIAoAAIAAg2IAoAAIAAghIAoAAIAAgUIBtAAIAAAUIAoAAIAAAhICCAAIAAA2IAyAAIAAHEg");
	this.shape_63.setTransform(1833.5,300);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#DDDDDD").s().p("AgSAbIASg1IATA1g");
	this.shape_64.setTransform(2108.5,173.7);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#DDDDDD").s().p("AhGBBIAAiBICNAAIAACBg");
	this.shape_65.setTransform(2108.5,181.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#DDDDDD").s().p("AhjAsIAAhXIDHAAIAABXg");
	this.shape_66.setTransform(2108.5,186.2);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#DDDDDD").s().p("Ah6AmIAAhLID1AAIAABLg");
	this.shape_67.setTransform(2108.5,189);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#DDDDDD").s().p("AiQMAIAA3/IEhAAIAAX/g");
	this.shape_68.setTransform(2108.5,265.2);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#DDDDDD").s().p("AkXIDIAAwFIIvAAIAAQFg");
	this.shape_69.setTransform(2302,266.5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#C6C6C6").s().p("AkXIDIAAwFIIvAAIAAQFg");
	this.shape_70.setTransform(2746,262.5);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#DDDDDD").s().p("AjlIDIAAwFIHLAAIAAQFg");
	this.shape_71.setTransform(3106,273.5);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#C6C6C6").s().p("AjMLGIAAg3IgKAAIAAgOIAKAAIAAgcIgKAAIAAgNIAKAAIAAgcIgKAAIAAgOIAKAAIAAgcIgKAAIAAgNIAKAAIAAgcIgKAAIAAgOIAKAAIAAgbIgKAAIAAgOIAKAAIAAgcIgKAAIAAgNIAKAAIAAgcIgKAAIAAgOIAKAAIAAgcIgKAAIAAgNIAKAAIAAgbIgKAAIAAgOIAKAAIAAgcIgKAAIAAgOIAKAAIAAgcIgKAAIAAgNIAKAAIAAgbIgKAAIAAgPIAKAAIAAgbIgKAAIAAgOIAKAAIAAgbIgKAAIAAgOIAKAAIAAgcIgKAAIAAgOIAKAAIAAgaIgKAAIAAgOIAKAAIAAgbIgKAAIAAgPIAKAAIAAgbIgKAAIAAgNIAKAAIAAgcIgKAAIAAgOIAKAAIAAgcIgKAAIAAgOIAKAAIAAgbIgKAAIAAgNIAKAAIAAgcIgKAAIAAgOIAKAAIAAgcIgKAAIAAgNIAKAAIAAgcIgKAAIAAgOIAKAAIAAgbIgKAAIAAgOIAKAAIAAgcIgKAAIAAgNIAKAAIAAgcIgKAAIAAgOIAKAAIAAgcIgKAAIAAgNIAKAAIAAgcIgKAAIAAgOIAKAAIAAgbIgKAAIAAgOIAKAAIAAgcIgKAAIAAgNIAKAAIAAgcIAoAAIAAgpIFJAAIAAApIAoAAIAAAcIAKAAIAAANIgKAAIAAAcIAKAAIAAAOIgKAAIAAAbIAKAAIAAAOIgKAAIAAAcIAKAAIAAANIgKAAIAAAcIAKAAIAAAOIgKAAIAAAcIAKAAIAAANIgKAAIAAAcIAKAAIAAAOIgKAAIAAAbIAKAAIAAAOIgKAAIAAAcIAKAAIAAANIgKAAIAAAcIAKAAIAAAOIgKAAIAAAcIAKAAIAAANIgKAAIAAAbIAKAAIAAAOIgKAAIAAAcIAKAAIAAAOIgKAAIAAAcIAKAAIAAANIgKAAIAAAbIAKAAIAAAPIgKAAIAAAbIAKAAIAAAOIgKAAIAAAaIAKAAIAAAOIgKAAIAAAcIAKAAIAAAOIgKAAIAAAbIAKAAIAAAOIgKAAIAAAbIAKAAIAAAPIgKAAIAAAbIAKAAIAAANIgKAAIAAAcIAKAAIAAAOIgKAAIAAAcIAKAAIAAAOIgKAAIAAAbIAKAAIAAANIgKAAIAAAcIAKAAIAAAOIgKAAIAAAcIAKAAIAAANIgKAAIAAAcIAKAAIAAAOIgKAAIAAAbIAKAAIAAAOIgKAAIAAAcIAKAAIAAANIgKAAIAAAcIAKAAIAAAOIgKAAIAAAcIAKAAIAAANIgKAAIAAAcIAKAAIAAAOIgKAAIAAA3g");
	this.shape_72.setTransform(2053.5,249);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#DDDDDD").s().p("AlypcIGZAtIAAhkIFKBMIACTbIrjAAg");
	this.shape_73.setTransform(2006,249);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#DDDDDD").s().p("AjYHgIAAnXIjuAeIDuk6IAAiOIHFg+IAAERIDaCEIjaAbIAAIPg");
	this.shape_74.setTransform(1955.5,289);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#DDDDDD").s().p("AjgGkIAAqnIAoAAIAAhQIAoAAIAAgyIAoAAIAAgeIBtAAIAAAeIAoAAIAAAyICCAAIAABQIAyAAIAAKng");
	this.shape_75.setTransform(2075.5,269);

	var maskedShapeInstanceList = [this.instance,this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59,this.shape_60,this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(1819,70.1,1366,697.9), null);


(lib.DisplayBox = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Path_2();
	this.instance.parent = this;
	this.instance.setTransform(320.3,-46,1.186,1.23,0,0,0,3.2,3.2);
	this.instance.alpha = 0.25;

	this.instance_1 = new lib.Path_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(7.2,0.1,1.515,1.23,0,0,0,215.2,46.3);
	this.instance_1.alpha = 0.898;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CACAFF").s().p("AgEAFQgDgCAAgDQAAgCADgDQACgCACAAQAIAAAAAHQAAADgDACQgCADgDAAQgCAAgCgDg");
	this.shape.setTransform(-335.8,38.1,1.496,1.469);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CACAFF").s().p("AgEAGQgDgCAAgEQAAgCADgCQACgDACAAQAIAAAAAHQAAAIgIAAQgCAAgCgCg");
	this.shape_1.setTransform(-335.8,32.4,1.496,1.469);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CACAFF").s().p("AgEAGQgDgDAAgDQAAgDADgBQACgDACAAQAIAAAAAHQAAADgDADQgCACgDAAQgCAAgCgCg");
	this.shape_2.setTransform(-335.8,21.6,1.496,1.469);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CACAFF").s().p("AgEAFQgDgBAAgEQAAgDADgCQACgCACAAQAIAAAAAHQAAAIgIAAQgCAAgCgDg");
	this.shape_3.setTransform(-335.8,15.9,1.496,1.469);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CACAFF").s().p("AgEAFQgDgCAAgDQAAgCADgCQACgDACAAQAIAAAAAHQAAAIgIAAQgCAAgCgDg");
	this.shape_4.setTransform(-335.8,3.5,1.496,1.469);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(49,49,255,0.898)").s().p("AgaDbIAAm1IA1gqIAAIJg");
	this.shape_5.setTransform(-336.6,14.7,1.496,1.23);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(49,49,255,0.898)").s().p("AgcG4IAAtvIA5hSIAAQUg");
	this.shape_6.setTransform(-329.3,0,1.496,1.23);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#CCCCCC").p("EAhLAILMhD7AAAIAAwVMBD7AAAQAqAAAeAeQAeAeAAArIAANHQAAArgeAeQgeAegqAAg");
	this.shape_7.setTransform(7.9,0,1.496,1.23);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(0,0,102,0.71)").s().p("EgiwAILIAAwUMBD7AAAQAqAAAeAdQAeAeAAArIAANHQAAAqgeAeQgeAfgqAAg");
	this.shape_8.setTransform(7.9,0,1.496,1.23);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(0,0,153,0.867)").s().p("EgiwAILIAAwUMBD7AAAQAqAAAeAdQAeAeAAArIAANHQAAAqgeAeQgeAfgqAAg");
	this.shape_9.setTransform(7.9,0,1.496,1.23);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.DisplayBox, new cjs.Rectangle(-340.6,-65.2,682.3,130.5), null);


// stage content:
(lib.index = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var _this = this;

		var frequency = 10;
		stage.enableMouseOver(frequency);



		this.play_button.addEventListener("mouseover", play_mo);
		this.play_button.addEventListener("mouseout", mouse_out);


		this.intro_button.addEventListener("mouseover", intro_mo);
		this.intro_button.addEventListener("mouseout", mouse_out);


		this.lesson1_button.addEventListener("mouseover", lesson1_mo);
		this.lesson1_button.addEventListener("mouseout", mouse_out);


		this.lab1_button.addEventListener("mouseover", lab1_mo);
		this.lab1_button.addEventListener("mouseout", mouse_out);


		this.lesson2_button.addEventListener("mouseover", lesson2_mo);
		this.lesson2_button.addEventListener("mouseout", mouse_out);


		this.lab2_button.addEventListener("mouseover", lab2_mo);
		this.lab2_button.addEventListener("mouseout", mouse_out);


		function play_mo()
		{
			_this.path.alpha = 1;
			_this.display_box.visible = true;
			_this.text.text = "ALLOW THE DAMPER BABIES TO LEAD THE WAY!";
			_this.text.visible = true;

		}


		function intro_mo()
		{
		    _this.path.alpha = 1;
		    _this.display_box.visible = true;
		    _this.text.text = "WHAT ARE THE DAMPER BABIES UP TO IN TAIPEI?";
		    _this.text.visible = true;

		}


		function lesson1_mo()
		{
		    _this.path.alpha = 1;
		    _this.display_box.visible = true;
		    _this.text.text = "SPRINGS, DAMPERS, EIGENFREQUENCIES AND MORE!";
		    _this.text.visible = true;

		}


		function lab1_mo()
		{
		    _this.path.alpha = 1;
		    _this.display_box.visible = true;
		    _this.text.text = "THE DAMPER BABIES ARE MAKING SOMETHING IN THEIR LABS.";
		    _this.text.visible = true;

		}


		function lesson2_mo()
		{
		    _this.path.alpha = 1;
		    _this.display_box.visible = true;
		    _this.text.text = "TAIPEI 101, ODES, TRANSFER FUNCTIONS AND MORE!";
		    _this.text.visible = true;

		}


		function lab2_mo()
		{
		    _this.path.alpha = 1;
		    _this.display_box.visible = true;
		    _this.text.text = "WHAT ARE THE DAMPER BABIES DOING TO TAIPEI 101?!";
		    _this.text.visible = true;

		}


		function mouse_out()
		{
			_this.path.alpha = .5;
			_this.display_box.visible = false;
			_this.text.visible = false;

		}


		this.play_button.addEventListener("click", go_to_intro);
		this.intro_button.addEventListener("click", go_to_intro);
		this.lesson1_button.addEventListener("click", go_to_lesson1);
		this.lab1_button.addEventListener("click", go_to_lab1);
		this.lesson2_button.addEventListener("click", go_to_lesson2);
		this.lab2_button.addEventListener("click", go_to_lab2);




		function go_to_intro() {
			window.open("introduction.html", "_blank");
		}

		function go_to_lesson1() {
			window.open("lesson1.html", "_blank");
		}

		function go_to_lab1() {
			window.open("lab1.html", "_blank");
		}

		function go_to_lesson2() {
			window.open("lesson2.html", "_blank");
		}

		function go_to_lab2() {
			window.open("lab2.html", "_blank");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Text
	this.text = new cjs.Text("", "35px 'Lucida Console'", "#FFFFFF");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 44;
	this.text.lineWidth = 634;
	this.text.parent = this;
	this.text.setTransform(688.2,205.6);

	this.text_1 = new lib.IntroText();
	this.text_1.name = "text_1";
	this.text_1.parent = this;
	this.text_1.setTransform(681.5,264.9);
	this.text_1.visible = false;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1},{t:this.text}]}).wait(1));

	// Display
	this.display_box = new lib.DisplayBox();
	this.display_box.name = "display_box";
	this.display_box.parent = this;
	this.display_box.setTransform(683.8,244.9,1,1,0,0,0,0.3,0);
	this.display_box.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.display_box).wait(1));

	// TAKE A TOUR
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AguDSIgBAAQgKAAgKgBIgUgCIgQABIgRAAIgFAAIgDAAIgFgEIgBgLIgBgZIAAgeIgBgZIgBgHIAAgKIABgGIgKjIIAAgEIAAgDIAAgFIAAgEIAAgVIABgeIAAgWQAEgEAJgCQAKgDAKAAIAPgBQAcAAAaACQAbABAbAEQAwAGAeAaQAeAaALAwIAAAHIAAAKIAAAHIAAADIAAACIAAAWQgBAMgDAKIgEAJIgFAMIgDAIIgSAUIgSASIAAAEIAJASIANAbIAOAcIAIASIAJARQAHAKAFAMQAFALgBAJQgBAIgNAAIgVgBIgVgBQgRAAgRACIghACIgEAAIgDAAIgDgEIgEgOIgHgWIgGgVIgEgPIgJgTQgFgLgDgKIAAAGIAAAGQAAAWACAVIABAsIAAAFIAAAFQgDAGgHACIgOABgAgdhlQgDAEABAKIAAACIAAACIAAAVIACAXQAAAIACAEQABAFAIAAQANgBAIgHQAJgIAFgLQAEgMAAgMQAAgQgKgIQgLgIgOAAQgMAAgDAEg");
	this.shape.setTransform(818.5,94.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgIDVIgJAAQgvAAgagTQgbgSgLgfQgMgegDglQgDglABglIAAgMIAAgQIABgIIAAgSIABgbIACgcIAAgSIABgFIABgGIABgPIABgVIABgPIAAAAIADgNQADgHAFgCIAQgDIAGAAIAKAAIAIAAIALAAIANAAIAHAAIAHABIAJABIAHABIABAAIAJADQAEABABAEIABAJIAAAIQAAAWgCAUIgDAqIAAAGIABAJIgBAFIgBAMIgBARIgCAMIAAAMIAAARIAAALIAAAPIAAARIAAAJIACARQABAJAFAGQAFAHAJAAQAKAAAGgJQAFgJACgMQACgNAAgNIAAgUIABgHIABgLIABgJIAAgLIAAgRIAAgLIAAg0IgBg0IAAgJIAAgGQAAgQADgIQADgHAIgCQAIgBAPAAQAUAAATAEQAUAFAUACQAEABABAGIAAAIIAAAFIgBAGIAAA/QgDATAAAUIAAAnIgBANIgBAXIgCAXIgBAOIAAAFIAAAEIAAAQIgCAUIgBAOQgDAcgNAVQgNAWgVASQgJAIgPAGIgaAJIgKABIgOABIgKABIgIAAg");
	this.shape_1.setTransform(786.7,94.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhODKQgdgXgRgiQgSgjgHgnQgIgnAAgiQgBgtALgoQALgoAWgfQAWgfAdgSQAegRAiABQAiACAlAYIAAABIABAAQAMAJAKAKQAKAKAIALQAHAJAEAJIAHAUIAHARIAIASQAEAKACANIAFAcIABAZQAAAUgDAUQgCAUgEAUQgJArgTAiQgUAiggAUQggAUgrAAQgrAAgdgWgAgHhrIgGAJQgPAVgHAaQgHAZAAAZQAAATAFATQAFATAGATQADAIAHAJQAHAIAJABQAJAAAGgIQAHgGACgJIADgKIAEgLIABgHIACgJIABgKIABgYIABgZQAAgUgDgTQgCgUgKgRQgEgHgFgFQgEgGgIAAQgEAAgEAFg");
	this.shape_2.setTransform(753.9,95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAXDNIgUgBQgIgCgLAAIgRABIgSABIgFAAIgFAAIgDgCIgDgDIAAgDIAAgDQAAg/ADg/QADg/AAg/IAAgQIgCgRQgBgCgDgBIgGAAQgLAAgLABIgUACIgDgBQgBAAAAAAQAAAAgBgBQAAAAAAAAQAAgBAAAAIAAhoIABgCIACgCIAegBIAfAAIAuABIAsAAIAMAAIAMgBIACAAIACAAIAPABIAWACIAPABIACABIACACIABAKIABAOIABAKIAAAFIAAAGIgBAdQAAAOgDAOQgDADgDABIgGABIgXgBIgWgBIgEAAIgCAAIgCACIAAADIAAAEIAAAPIACAQIAAAQIAAAYIAAAZIAAAQIAABUQAAAqgFAqQgEAGgIABIgLABIgDAAg");
	this.shape_3.setTransform(726.4,94.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AA6DYQgKAAgDgKQgEgKgBgNQAAgLgDgHQgCgEgJAAIgQgBIgBAAIgBAAIgCAAIgYABQgOAAgLAGIgBADIgBABIgBATQgBAJgEAGQgEAEgLADIgVADIgVABIAAAAIgJgBIgKAAIgFgBIgHgBIgIgBIgFgBIgFgBIgDAAQgBAAgBAAQAAAAgBgBQAAAAAAAAQAAgBAAgBIAAAAIAKg7IAQhLIAWhmIAiiWIAEgSQACgIAEgEQAFgGAOAAIABAAIAOABIAXACIAOAAIAPAAIAVAAIAQgBQAHgBAFAFQAFAFADAGIAFAMIANAtIASBDIATBNIASBPQAIAnAFAeQAGAeAAARIAAADIAAACIgBABIggABIhIALgAgIhOIgEAJIgDAHIgBAFIgCALIgDARIgBALIgBACIgBACIgDAeIAAAHIAAALIAAAGIgBAGIgBAJIgBAGIAAACIABAAIABABIADAAIACAAIAPABIAPgBIAGAAIAGAAQABAAAAAAQAAAAAAAAQAAgBAAAAQAAgBAAAAIgBgCQAAgRgCgQQgBgQgDgOIgEgSIgGgaIgEgXQgDgKgBAAIgBAAg");
	this.shape_4.setTransform(678.8,94.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAIDTIgpgBIgYABIgYAAQgIAAgFgCQgHgDgBgIIgBgMIAAgOIAAgKIAAgOIAAgPIABgHIAAgJIAAgOIABgJIAAgRIAAgZIgBgZIAAgQIAAgLIgFhZQgCgugBgsIAAgWIABgGQACgDACgCIDEAEQAHABAEAHQACAHAAAIIAAAIIgBAJIABATIAAASIAAAJIgBALQgIAKgLADQgLACgMAAIgTgBIgSgBIgEAAQgBAAAAAAQAAAAgBABQAAAAAAAAQAAABgBABIgDAbIAAAPQADAEAGAAIAJABIABAAIAAAAIASgBIASgBIALABQAHABAGACQAGADACAFIAAAGIAAAGIAAABIABACIAAAWIABAWQgBANgEALQgEALgOABIg5AAQgEAAgCAEQgDAEgBADIgBAIIgBALIAAABQAAAMAHADQAHAEAJABIA6AAIAJABQADABADAEIADAOIABANIgBAMIgBAMIAAABIAAAIIABALIAAAIIAAACQAAAIgHAEQgGADgIABIgPABIgBAAIAAAAIgJAAIgMABIgsgCg");
	this.shape_5.setTransform(632.3,94.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ACQDYIg9gDQgeAAgegFQgDgBgCgDIgEgFIgyiOIgBgCIgBgCIgCACIAAAKIABAsIABArIAAAuQAAAGgDADQgCADgFABIgZAAIgFAAIgFgBIgpAAIgKgBIgKgBQgEgBgEgEQgDgDAAgEIABhmIABhlIAAgrIgBgrIABg6IABg7IAZAAIAYgCIAMgBIAMgBIALAAIAiACIAGAGQACACAAADIAAAHIgBAHIgHBXIAAApIACgBIACgCIAahCIAZhDIADgHQACgEADgCIAOAAIAHgBIAGAAIBVAAQABAAABAAQAAABABAAQAAAAABAAQAAABAAAAQABAAAAABQAAABAAAAQABABAAAAQAAABAAAAIgBABIAAABIgDAIIgEAIIgLAWIgMAVIhBCPIBhC+IAFAJQADAFAAAFQAAABAAABQgBABAAAAQAAABAAAAQgBAAAAABIgFABg");
	this.shape_6.setTransform(604.1,95.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AA6DYQgKAAgDgKQgEgKgBgNQAAgLgDgHQgCgEgJAAIgQgBIgBAAIgBAAIgCAAIgYABQgOAAgLAGIgBADIgBABIgBATQgBAJgEAGQgEAEgLADIgVADIgVABIAAAAIgJgBIgKAAIgFgBIgHgBIgIgBIgFgBIgFgBIgDAAQgBAAgBAAQAAAAgBgBQAAAAAAAAQAAgBAAgBIAAAAIAKg7IAQhLIAWhmIAiiWIAEgSQACgIAEgEQAFgGAOAAIABAAIAOABIAXACIAOAAIAPAAIAVAAIAQgBQAHgBAFAFQAFAFADAGIAFAMIANAtIASBDIATBNIASBPQAIAnAFAeQAGAeAAARIAAADIAAACIgBABIggABIhIALgAgIhOIgEAJIgDAHIgBAFIgCALIgDARIgBALIgBACIgBACIgDAeIAAAHIAAALIAAAGIgBAGIgBAJIgBAGIAAACIABAAIABABIADAAIACAAIAPABIAPgBIAGAAIAGAAQABAAAAAAQAAAAAAAAQAAgBAAAAQAAgBAAAAIgBgCQAAgRgCgQQgBgQgDgOIgEgSIgGgaIgEgXQgDgKgBAAIgBAAg");
	this.shape_7.setTransform(569.6,94.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAWDNIgTgBQgIgCgKAAIgSABIgSABIgFAAIgEAAIgEgCIgDgDIAAgDIAAgDQABg/ACg/QADg/ABg/IAAgQIgCgRQgBgCgEgBIgGAAQgMAAgKABIgUACIgDgBQgBAAAAAAQAAAAAAgBQgBAAAAAAQAAgBAAAAIAAhoIABgCIACgCIAegBIAfAAIAuABIAsAAIAMAAIAMgBIACAAIACAAIAPABIAWACIAOABIAEABIABACIABAKIABAOIABAKIAAAFIAAAGIgBAdQgBAOgCAOQgDADgDABIgHABIgWgBIgXgBIgDAAIgCAAIgCACIAAADIAAAEIAAAPIACAQIAAAQIAAAYIAAAZIAAAQIAABUQAAAqgFAqQgEAGgIABIgLABIgEAAg");
	this.shape_8.setTransform(543.9,94.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Play Button
	this.play_button = new lib.PlayButton();
	this.play_button.name = "play_button";
	this.play_button.parent = this;
	this.play_button.setTransform(682.6,98.4);
	new cjs.ButtonHelper(this.play_button, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.play_button).wait(1));

	// Lab Button 2
	this.lab2_button = new lib.Lab2Button();
	this.lab2_button.name = "lab2_button";
	this.lab2_button.parent = this;
	this.lab2_button.setTransform(983.2,545.7);
	new cjs.ButtonHelper(this.lab2_button, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.lab2_button).wait(1));

	// Learn Button 2
	this.lesson2_button = new lib.Learn2Button();
	this.lesson2_button.name = "lesson2_button";
	this.lesson2_button.parent = this;
	this.lesson2_button.setTransform(790.6,352.6);
	new cjs.ButtonHelper(this.lesson2_button, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.lesson2_button).wait(1));

	// Lab Button 1
	this.lab1_button = new lib.Lab1Button();
	this.lab1_button.name = "lab1_button";
	this.lab1_button.parent = this;
	this.lab1_button.setTransform(611.1,455.7,1,1,0,0,0,42.9,41.5);
	new cjs.ButtonHelper(this.lab1_button, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.lab1_button).wait(1));

	// Learn Button 1
	this.lesson1_button = new lib.LearnButton();
	this.lesson1_button.name = "lesson1_button";
	this.lesson1_button.parent = this;
	this.lesson1_button.setTransform(470.6,617.6);
	new cjs.ButtonHelper(this.lesson1_button, 0, 1, 1);

	this.instance = new lib.Path();
	this.instance.parent = this;
	this.instance.setTransform(470.7,652.1,1,1,0,0,0,21.3,6.9);
	this.instance.alpha = 0.41;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.lesson1_button}]}).wait(1));

	// Intro Button
	this.intro_button = new lib.IntroButton();
	this.intro_button.name = "intro_button";
	this.intro_button.parent = this;
	this.intro_button.setTransform(362.6,417.6);
	new cjs.ButtonHelper(this.intro_button, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.intro_button).wait(1));

	// Shadows
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#9E9E9E").s().p("AlPBrQiLgtAAg+QAAg+CLgsQCLgsDEAAQDFAACLAsQCLAsAAA+QAAA+iLAtQiLAsjFAAQjEAAiLgsg");
	this.shape_9.setTransform(983.7,642.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#9E9E9E").s().p("AiWAxQg+gVAAgcQAAgbA+gVQA/gUBXAAQBYAAA/AUQA+AVAAAbQAAAcg+AVQg/AUhYAAQhXAAg/gUg");
	this.shape_10.setTransform(790.7,387.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#9E9E9E").s().p("Aj0BPQhmghABguQgBguBmggQBlghCPAAQCPAABmAhQBlAgABAuQgBAuhlAhQhmAhiPAAQiOAAhmghg");
	this.shape_11.setTransform(611.4,511.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#9E9E9E").s().p("AiWAxQg+gVAAgcQAAgcA+gTQA/gVBXAAQBYAAA/AVQA+ATAAAcQAAAcg+AVQg/AUhYAAQhXAAg/gUg");
	this.shape_12.setTransform(470.7,652.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#9E9E9E").s().p("AiWAxQg+gVAAgcQAAgbA+gVQA/gUBXAAQBYAAA/AUQA+AVAAAbQAAAcg+AVQg/AUhYAAQhXAAg/gUg");
	this.shape_13.setTransform(362.7,452.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

	// Path
	this.path = new lib.Path_3();
	this.path.name = "path";
	this.path.parent = this;
	this.path.setTransform(652.5,517.9,1,1,0,0,0,340.1,136.2);
	this.path.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.path).wait(1));

	// Background
	this.instance_1 = new lib.ClipGroup();
	this.instance_1.parent = this;
	this.instance_1.setTransform(686,601,1,1,0,0,0,2505,601);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1136,384,5010,1202);
// library properties:
lib.properties = {
	id: '90DA7FC47A87944BA3D7F44131831EBD',
	width: 1366,
	height: 768,
	fps: 22,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"sounds/buzz.mp3", id:"buzz"},
		{src:"sounds/kokokuo.mp3", id:"kokokuo"},
		{src:"sounds/taipei_101_damper.mp3", id:"taipei_101_damper"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90DA7FC47A87944BA3D7F44131831EBD'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
