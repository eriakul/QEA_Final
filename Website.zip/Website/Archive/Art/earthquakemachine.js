(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.piston3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A08C7C").s().p("AmuBIIAAiPINdAAIAACPg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.piston3, new cjs.Rectangle(-43,-7.2,86.1,14.5), null);


(lib.piston2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A08C7C").s().p("AmuBIIAAiPINdAAIAACPg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.piston2, new cjs.Rectangle(-43,-7.2,86.1,14.4), null);


(lib.piston1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A08C7C").s().p("AmuBIIAAiPINdAAIAACPg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.piston1, new cjs.Rectangle(-43,-7.2,86.1,14.4), null);


(lib.massdamper = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3DAFB7").s().p("AjHAUIAAgnIGPAAIAAAng");
	this.shape.setTransform(19,49.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6EE1F2").s().p("AmFAUIAAgnIMLAAIAAAng");
	this.shape_1.setTransform(0,49.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2BBDCF").s().p("AieghIBsiAIDRAAIkRFDg");
	this.shape_2.setTransform(-17.6,67.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#006E7A").s().p("Ai5ClIAAlJIFzAAIhIFJg");
	this.shape_3.setTransform(17.7,68);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#17A2BB").s().p("AkhClIhJlJILVAAIhJFJg");
	this.shape_4.setTransform(0,68);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#63CBD0").s().p("AiEKUIAA0nIAKAAIAAHWIBFAAIAADRIApAAIAABuIAmAAIAABQIhPAAIAADmIAyAAIAABkIAnAAIBhB4g");
	this.shape_5.setTransform(12.4,-18.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#A5F7FD").s().p("AkKKUIBhh4IAoAAIAAhkIAyAAIAAjmIhQAAIAAhQIAoAAIAAhuIAoAAIAAjRIA8AAIAAnWIAdAAIAAHWIBGAAIAADRIAoAAIAABuIAoAAIAABQIhQAAIAADmIAyAAIAABkIAoAAIBhB4g");
	this.shape_6.setTransform(-1,-18.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.massdamper, new cjs.Rectangle(-39,-84.5,78,169), null);


(lib.mass7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3DAFB7").s().p("AjHAUIAAgnIGPAAIAAAng");
	this.shape.setTransform(19,-16.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6EE1F2").s().p("AmFAUIAAgnIMLAAIAAAng");
	this.shape_1.setTransform(0,-16.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2BBDCF").s().p("AieghIBsiAIDRAAIkRFDg");
	this.shape_2.setTransform(-17.6,1.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#006E7A").s().p("Ai5ClIAAlJIFzAAIhIFJg");
	this.shape_3.setTransform(17.7,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#17A2BB").s().p("AkhClIhJlJILVAAIhJFJg");
	this.shape_4.setTransform(0,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mass7, new cjs.Rectangle(-39,-18.5,78,37), null);


(lib.mass6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3DAFB7").s().p("AjHAUIAAgnIGPAAIAAAng");
	this.shape.setTransform(19,-16.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6EE1F2").s().p("AmFAUIAAgnIMLAAIAAAng");
	this.shape_1.setTransform(0,-16.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2BBDCF").s().p("AieghIBsiAIDRAAIkRFDg");
	this.shape_2.setTransform(-17.6,1.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#006E7A").s().p("Ai5ClIAAlJIFzAAIhIFJg");
	this.shape_3.setTransform(17.7,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#17A2BB").s().p("AkhClIhJlJILVAAIhJFJg");
	this.shape_4.setTransform(0,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mass6, new cjs.Rectangle(-39,-18.5,78,37), null);


(lib.mass5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3DAFB7").s().p("AjHAUIAAgnIGPAAIAAAng");
	this.shape.setTransform(19,-16.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6EE1F2").s().p("AmFAUIAAgnIMLAAIAAAng");
	this.shape_1.setTransform(0,-16.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2BBDCF").s().p("AieghIBsiAIDRAAIkRFDg");
	this.shape_2.setTransform(-17.6,1.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#006E7A").s().p("Ai5ClIAAlJIFzAAIhIFJg");
	this.shape_3.setTransform(17.7,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#17A2BB").s().p("AkhClIhJlJILVAAIhJFJg");
	this.shape_4.setTransform(0,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mass5, new cjs.Rectangle(-39,-18.5,78,37), null);


(lib.mass4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3DAFB7").s().p("AjHAUIAAgnIGPAAIAAAng");
	this.shape.setTransform(19,-16.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6EE1F2").s().p("AmFAUIAAgnIMLAAIAAAng");
	this.shape_1.setTransform(0,-16.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2BBDCF").s().p("AieghIBsiAIDRAAIkRFDg");
	this.shape_2.setTransform(-17.6,1.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#006E7A").s().p("Ai5ClIAAlJIFzAAIhIFJg");
	this.shape_3.setTransform(17.7,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#17A2BB").s().p("AkhClIhJlJILVAAIhJFJg");
	this.shape_4.setTransform(0,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mass4, new cjs.Rectangle(-39,-18.5,78,37), null);


(lib.mass3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3DAFB7").s().p("AjHAUIAAgnIGPAAIAAAng");
	this.shape.setTransform(19,-16.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6EE1F2").s().p("AmFAUIAAgnIMLAAIAAAng");
	this.shape_1.setTransform(0,-16.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2BBDCF").s().p("AieghIBsiAIDRAAIkRFDg");
	this.shape_2.setTransform(-17.6,1.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#006E7A").s().p("Ai5ClIAAlJIFzAAIhIFJg");
	this.shape_3.setTransform(17.7,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#17A2BB").s().p("AkhClIhJlJILVAAIhJFJg");
	this.shape_4.setTransform(0,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mass3, new cjs.Rectangle(-39,-18.5,78,37), null);


(lib.mass2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3DAFB7").s().p("AjHAUIAAgnIGPAAIAAAng");
	this.shape.setTransform(19,-16.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6EE1F2").s().p("AmFAUIAAgnIMLAAIAAAng");
	this.shape_1.setTransform(0,-16.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2BBDCF").s().p("AieghIBsiAIDRAAIkRFDg");
	this.shape_2.setTransform(-17.6,1.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#006E7A").s().p("Ai5ClIAAlJIFzAAIhIFJg");
	this.shape_3.setTransform(17.7,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#17A2BB").s().p("AkhClIhJlJILVAAIhJFJg");
	this.shape_4.setTransform(0,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mass2, new cjs.Rectangle(-39,-18.5,78,37), null);


(lib.mass1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3DAFB7").s().p("AjHAUIAAgnIGPAAIAAAng");
	this.shape.setTransform(19,-16.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6EE1F2").s().p("AmFAUIAAgnIMLAAIAAAng");
	this.shape_1.setTransform(0,-16.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2BBDCF").s().p("AieghIBsiAIDRAAIkRFDg");
	this.shape_2.setTransform(-17.6,1.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#006E7A").s().p("Ai5ClIAAlJIFzAAIhIFJg");
	this.shape_3.setTransform(17.7,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#17A2BB").s().p("AkhClIhJlJILVAAIhJFJg");
	this.shape_4.setTransform(0,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mass1, new cjs.Rectangle(-39,-18.5,78,37), null);


(lib.mass0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A3F8FB").s().p("AssAyIAAhjIZZAAIAABjg");
	this.shape.setTransform(0,52);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3DAFB7").s().p("Ag4AuQgXgTAAgbQAAgaAXgTQAXgTAhAAQAhAAAYATQAXATAAAaQAAAbgXATQgYATghAAQggAAgYgTg");
	this.shape_1.setTransform(18.4,-50.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6EE1F2").s().p("Ag3AuQgYgTAAgbQAAgaAYgTQAWgTAhAAQAhAAAYATQAXATAAAaQAAAbgXATQgYATghAAQggAAgXgTg");
	this.shape_2.setTransform(-18.3,-50.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#5ED7E1").s().p("AiJAKIgEgTIEWAAIAFATg");
	this.shape_3.setTransform(35.6,13.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#5ED7E1").s().p("AiHAKIgEgSIERAAIAGASg");
	this.shape_4.setTransform(34.1,6.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#5ED7E1").s().p("AiFAJIgEgRIEOAAIAFARg");
	this.shape_5.setTransform(32.6,0.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#5ED7E1").s().p("AiDAJIgEgRIEJAAIAGARg");
	this.shape_6.setTransform(31.1,-5.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#5ED7E1").s().p("AiBAJIgDgRIEFAAIAEARg");
	this.shape_7.setTransform(29.7,-10.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#5ED7E1").s().p("Ah/AJIgEgQIECAAIAEAQg");
	this.shape_8.setTransform(28.4,-16.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#5ED7E1").s().p("Ah9AIIgEgPID+AAIAEAPg");
	this.shape_9.setTransform(27,-21.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#5ED7E1").s().p("Ah7AIIgEgPID6AAIAFAPg");
	this.shape_10.setTransform(25.7,-26.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#5ED7E1").s().p("Ah6AIIgDgPID2AAIAFAPg");
	this.shape_11.setTransform(24.5,-32);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#5ED7E1").s().p("Ah4AHIgDgOIDyAAIAFAOg");
	this.shape_12.setTransform(23.3,-36.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#007E8C").s().p("AhAGVIirspIDzAAIDkMpg");
	this.shape_13.setTransform(33.7,2.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#5ED7E1").s().p("AiMAKIAFgTIEUAAIgDATg");
	this.shape_14.setTransform(-35.8,13.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#5ED7E1").s().p("AiKAKIAFgSIEQAAIgEASg");
	this.shape_15.setTransform(-34.3,6.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#5ED7E1").s().p("AiIAJIAGgRIELAAIgEARg");
	this.shape_16.setTransform(-32.8,0.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#5ED7E1").s().p("AiGAJIAGgRIEHAAIgEARg");
	this.shape_17.setTransform(-31.3,-5.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#5ED7E1").s().p("AiEAJIAFgRIEEAAIgEARg");
	this.shape_18.setTransform(-29.9,-10.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#5ED7E1").s().p("AiCAJIAFgQIEAAAIgEAQg");
	this.shape_19.setTransform(-28.6,-16.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#5ED7E1").s().p("AiAAIIAEgPID9AAIgDAPg");
	this.shape_20.setTransform(-27.2,-21.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#5ED7E1").s().p("Ah+AIIAFgPID4AAIgEAPg");
	this.shape_21.setTransform(-25.9,-26.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#5ED7E1").s().p("Ah8AIIAEgPID1AAIgDAPg");
	this.shape_22.setTransform(-24.7,-32);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#5ED7E1").s().p("Ah6AHIAEgOIDxAAIgDAOg");
	this.shape_23.setTransform(-23.5,-36.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#006E7A").s().p("AjqGVIDjspIDyAAIiqMpg");
	this.shape_24.setTransform(-33.9,2.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#006E7A").s().p("AluIDIAAwFIGEAAIFZQFg");
	this.shape_25.setTransform(35.6,-0.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#17A2BB").s().p("ArLIDIFYwFILnAAIFZQFg");
	this.shape_26.setTransform(0.6,-0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mass0, new cjs.Rectangle(-81.3,-57,162.6,114), null);


(lib.mup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFF0B0").ss(3).p("Agch1IiLDCQgMARAKATQAKAUAVAAIEVAAQAVAAAKgUQAKgTgMgRIiLjCQgLgPgSAAQgRAAgLAPg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4CD957").s().p("AiKCFQgVgBgKgSQgKgUAMgRICMjCQAKgPARAAQASAAALAPICKDCQANARgKAUQgKASgWABg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#66FFFF").s().p("AiKCFQgVgBgKgSQgKgUAMgRICMjCQAKgPARAAQASAAALAPICKDCQANARgKAUQgKASgWABg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#009966").s().p("AiKCFQgVgBgKgSQgKgUAMgRICMjCQAKgPARAAQASAAALAPICKDCQANARgKAUQgKASgWABg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape}]},1).to({state:[{t:this.shape_3},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.6,-14.7,53.3,35.5);


(lib.mdown = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFF0B0").ss(3).p("Agch1IiLDCQgMARAKATQAKAUAVAAIEVAAQAVAAAKgUQAKgTgMgRIiLjCQgLgPgSAAQgRAAgLAPg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4CD957").s().p("AiKCFQgVgBgKgSQgKgUAMgRICMjCQAKgPARAAQASAAALAPICKDCQANARgKAUQgKASgWABg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#66FFFF").s().p("AiKCFQgVgBgKgSQgKgUAMgRICMjCQAKgPARAAQASAAALAPICKDCQANARgKAUQgKASgWABg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#009966").s().p("AiKCFQgVgBgKgSQgKgUAMgRICMjCQAKgPARAAQASAAALAPICKDCQANARgKAUQgKASgWABg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape}]},1).to({state:[{t:this.shape_3},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.6,-14.7,53.3,35.5);


(lib.lights = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A08C7C").s().p("AgRARQgHgHAAgKQAAgJAHgHQAHgGAKgBQAKABAIAGQAHAIAAAIQAAAJgHAIQgIAGgKABQgKgBgHgGg");
	this.shape.setTransform(0,11.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A08C7C").s().p("AgRAQQgHgGAAgKQAAgJAHgHQAIgGAJAAQAKAAAIAGQAHAHAAAJQAAAKgHAGQgIAHgKAAQgJAAgIgHg");
	this.shape_1.setTransform(0,4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A08C7C").s().p("AgRAQQgHgGAAgKQAAgJAHgHQAHgGAKAAQAKAAAIAGQAHAIAAAIQAAAJgHAHQgIAHgKABQgKgBgHgHg");
	this.shape_2.setTransform(0,-3.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#7AED26").s().p("AgRAQQgHgGAAgKQAAgJAHgGQAHgIAKAAQAKAAAIAIQAHAGAAAJQAAAKgHAGQgIAIgKgBQgKABgHgIg");
	this.shape_3.setTransform(0,-11.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#7AED26").s().p("AgRAQQgHgGAAgKQAAgJAHgHQAHgGAKAAQAKAAAIAGQAHAIAAAIQAAAJgHAHQgIAHgKABQgKgBgHgHg");
	this.shape_4.setTransform(0,-3.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#A08C7C").s().p("AgRAQQgHgGAAgKQAAgJAHgGQAHgIAKAAQAKAAAIAIQAHAGAAAJQAAAKgHAGQgIAIgKgBQgKABgHgIg");
	this.shape_5.setTransform(0,-11.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#7AED26").s().p("AgRAQQgHgGAAgKQAAgJAHgHQAIgGAJAAQAKAAAIAGQAHAHAAAJQAAAKgHAGQgIAHgKAAQgJAAgIgHg");
	this.shape_6.setTransform(0,4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#7AED26").s().p("AgRARQgHgHAAgKQAAgJAHgHQAHgGAKgBQAKABAIAGQAHAIAAAIQAAAJgHAIQgIAGgKABQgKgBgHgGg");
	this.shape_7.setTransform(0,11.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_1},{t:this.shape}]},24).to({state:[{t:this.shape_5},{t:this.shape_2},{t:this.shape_6},{t:this.shape}]},24).to({state:[{t:this.shape_5},{t:this.shape_2},{t:this.shape_1},{t:this.shape_7}]},24).wait(24));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-14,5.1,28.1);


(lib.graph = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var frame_rate = 1/24;
		var steps = 30;
		this.data1 = new Array(steps).fill(0);
		this.data2 = new Array(steps).fill(0);
		
		var width = 60;
		var height = 60;
		var _this = this;
		
		
		
		var loop = function(){
			
			_this.removeAllChildren();
		
			for (x = 0; x < steps; x += 1){
				start = -width/2 + (width/steps) * x;
				end = start + (width/steps);
				var stroke_color = "#7AC943";
				var line =  new createjs.Shape(new createjs.Graphics().beginStroke(stroke_color)
					.moveTo(start, _this.data1[x])
					.lineTo(end, _this.data1[x + 1])
					.endStroke());
					_this.addChild(line);
				
				var stroke_color = "#FF931E";
				var line =  new createjs.Shape(new createjs.Graphics().beginStroke(stroke_color)
					.moveTo(start, _this.data2[x])
					.lineTo(end, _this.data2[x + 1])
					.endStroke());
					_this.addChild(line);
				
				
				}
			}
		
		setInterval(loop, frame_rate*1000);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

}).prototype = getMCSymbolPrototype(lib.graph, null, null);


(lib.fup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFF0B0").ss(3).p("Agch1IiLDCQgMARAKATQAKAUAVAAIEVAAQAVAAAKgUQAKgTgMgRIiLjCQgLgPgSAAQgRAAgLAPg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4CD957").s().p("AiKCFQgVgBgKgSQgKgUAMgRICMjCQAKgPARAAQASAAALAPICKDCQANARgKAUQgKASgWABg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#66FFFF").s().p("AiKCFQgVgBgKgSQgKgUAMgRICMjCQAKgPARAAQASAAALAPICKDCQANARgKAUQgKASgWABg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#009966").s().p("AiKCFQgVgBgKgSQgKgUAMgRICMjCQAKgPARAAQASAAALAPICKDCQANARgKAUQgKASgWABg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape}]},1).to({state:[{t:this.shape_3},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.6,-14.7,53.3,35.5);


(lib.fdown = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFF0B0").ss(3).p("Agch1IiLDCQgMARAKATQAKAUAVAAIEVAAQAVAAAKgUQAKgTgMgRIiLjCQgLgPgSAAQgRAAgLAPg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4CD957").s().p("AiKCFQgVgBgKgSQgKgUAMgRICMjCQAKgPARAAQASAAALAPICKDCQANARgKAUQgKASgWABg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#66FFFF").s().p("AiKCFQgVgBgKgSQgKgUAMgRICMjCQAKgPARAAQASAAALAPICKDCQANARgKAUQgKASgWABg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#009966").s().p("AiKCFQgVgBgKgSQgKgUAMgRICMjCQAKgPARAAQASAAALAPICKDCQANARgKAUQgKASgWABg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape}]},1).to({state:[{t:this.shape_3},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.6,-14.7,53.3,35.5);


(lib.EvilButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#3131FF").ss(3).p("ALdDPI25AAQghAAgYgYQgXgYAAggIAAj9QAAghAXgXQAYgYAhAAIW5AAQAhAAAYAYQAXAXAAAhIAAD9QAAAggXAYQgYAYghAAg");
	this.shape.setTransform(0,0,1.275,1.251);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(14,0,63,0.867)").s().p("ArcDPQghAAgYgYQgXgYAAggIAAj9QAAghAXgXQAYgYAhAAIW5AAQAhAAAYAYQAXAXAAAhIAAD9QAAAggXAYQgYAYghAAg");
	this.shape_1.setTransform(0,0,1.275,1.251);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,0,51,0.867)").s().p("ArcDPQghAAgYgYQgXgYAAggIAAj9QAAghAXgXQAYgYAhAAIW5AAQAhAAAYAYQAXAXAAAhIAAD9QAAAggXAYQgYAYghAAg");
	this.shape_2.setTransform(0,0,1.275,1.251);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(0,0,51,0.867)").s().p("ArcDPQghAAgYgYQgXgYAAggIAAj9QAAghAXgXQAYgYAhAAIW5AAQAhAAAYAYQAXAXAAAhIAAD9QAAAggXAYQgYAYghAAg");
	this.shape_3.setTransform(0,0,1.275,1.251);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112.2,-27.3,217.5,54.8);


(lib.cloud5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDAA8").s().p("AgsCWQgpAUg4AAQg+AAgrgZQgsgZAAgjQAAgjAsgZIACgBIgGgCQhSgiAAgyQAAgyBSgkQBSgjB0AAQBzAABSAjQBTAkAAAyIAAAGQAUAIATALQBCAlAAA2QAAA2hCAmQhCAmhdAAQhZAAg/gig");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud5, new cjs.Rectangle(-33.3,-18.3,66.7,36.8), null);


(lib.cloud4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDAA8").s().p("Ah+DrQgjgjAAgyQAAgUAGgSIgYABQhQAAg4g4Qg4g4AAhPQAAhPA4g5QA4g4BQAAQBLAAA2AyQBCgyBYAAQBvAABOBPQBPBOAABvQAABuhPBPQhOBOhvAAQgsAAgmgMQgbASgjAAQgyAAgkgkg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud4, new cjs.Rectangle(-37.2,-27,74.4,54.2), null);


(lib.cloud3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDAA8").s().p("AlJETQg8AqhNAAQhlAAhIhIQhIhJAAhlQAAhlBIhIQApgpAzgRQgEgTAAgUQAAhBAugvQAuguBCAAQBBAAAuAuQAvAvAABBIAAABIAhgLQAPgzBLgmQBegvCEAAQCFAABeAvQBeAvAABDQAAAhgYAdQAXgDAYAAQBpAABLA1QBKA2AABKQAABMhKA0QhLA2hpAAQhYAAhCglQgcAmgtAhQh1BWilAAQiiAAh0hTg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud3, new cjs.Rectangle(-71.2,-35.8,142.5,71.6), null);


(lib.cloud2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDAA8").s().p("AB1HPQh8BFilAAQjHAAiMhjQiMhkAAiNQAAiNCMhjQBCguBOgZQgMgsAAgwQAAiFBdheQBeheCFAAQCEAABeBeQBeBeAACFQAAAugLAqQAhgIAlABQCKgBBhBiQBhBgAACKQAACJhhBhQhhBiiKAAQh0AAhXhGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud2, new cjs.Rectangle(-65.2,-53.2,130.5,106.5), null);


(lib.cloud1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDAA8").s().p("AvSG1QhihCABhfQgBheBihDQBhhCCKAAIAOAAQAOhmBshLQBghBB8gQQAFh3B/hXQCEhYC7gBQC6ABCFBYQCEBaABB+QgBAigJAhQBEgTBOABQCwAAB8BaQB8BZAACAQAAB/h8BaQh8BaiwAAQh/AAhkguQiJAti5AAQjSAAiUg7QgigNgagPQhAgBg4gMQgYApgyAhQhhBEiJAAQiKAAhhhEg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud1, new cjs.Rectangle(-107.6,-50.4,215.3,100.9), null);


(lib.taipei = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var num_blocks = 8;
		
		this.k = 500;
		this.b = 700;
		this.k2 = 500;
		this.b2 = 800;
		this.frequency = 0;
		
		var discrete_mass = 70;
		
		
		var block_size = 10;
		var wall_width = 60;
		var width  = 490;
		var height = 240;
		var frame_rate  = 1/24;
		
		this.wall  = {x: 0,  lx: 0, v: 0, t: 0};
		
		this.masses = [this.mass1, this.mass2, this.mass3, this.mass4, this.mass5, this.mass6, this.mass7, this.massdamper]
		
		this.blocks = [];
		
		for (x = 0; x < num_blocks; x = x + 1){
		
			var new_block = {x: 0, v: 0, mass: discrete_mass};
			
			this.blocks.push(new_block);
		
			}
			
		this.blocks[num_blocks-1].mass = 0
		
		
		
		var _this = this;
		var loop = function() {
			
			_this.wall.t += frame_rate;
			_this.wall.lx = _this.wall.x;
			_this.wall.x = 5 * Math.sin(2 * Math.PI * _this.frequency * _this.wall.t);
			_this.wall.v = (_this.wall.x - _this.wall.lx) / frame_rate;
			
				var F_spring = -1*_this.k * ( (_this.blocks[0].x - (_this.wall.x)) );
				var F_damper = -1*_this.b * ( _this.blocks[0].v - _this.wall.v );
				var F_spring1 = _this.k * (( _this.blocks[1].x - ( _this.blocks[0].x)));
				var F_damper1 = _this.b * ( _this.blocks[1].v - _this.blocks[0].v);
			
					var a = ( F_spring + F_damper + F_spring1 + F_damper1 ) / _this.blocks[0].mass;
					_this.blocks[0].v += a * frame_rate;
					_this.blocks[0].x += _this.blocks[0].v * frame_rate;
					
			
			
			
			for ( i = 1; i < num_blocks - 1; i = i + 1){
			
				var F_spring = -1*_this.k * ( (_this.blocks[i].x - (_this.blocks[i-1].x ) ) );
				var F_damper = -1*_this.b * ( _this.blocks[i].v - _this.blocks[i-1].v );
				var F_spring1 = _this.k * (( _this.blocks[i+1].x - ( _this.blocks[i].x)));
				var F_damper1 = _this.b * (_this.blocks[i+1].v - _this.blocks[i].v );
			
					var a = ( F_spring + F_damper + F_spring1 + F_damper1 ) / _this.blocks[i].mass;
					_this.blocks[i].v += a * frame_rate;
					_this.blocks[i].x += _this.blocks[i].v * frame_rate;
					
			}
				
			
				var F_spring = -1*_this.k2 * ( (_this.blocks[num_blocks - 1].x - (_this.blocks[num_blocks - 2].x ) ) );
				var F_damper = -1*_this.b2 * ( _this.blocks[num_blocks - 1].v - _this.blocks[num_blocks - 2].v );
				var a = ( F_spring + F_damper) /(_this.blocks[num_blocks - 1].mass*5 + discrete_mass);
					_this.blocks[num_blocks - 1].v += a * frame_rate;
					_this.blocks[num_blocks - 1].x += _this.blocks[num_blocks - 1].v * frame_rate;
			
			_this.mass0.x = _this.wall.x;
			
			for ( i = 0; i < num_blocks; i = i + 1){
				_this.masses[i].x = _this.blocks[i].x;
				}
			}
		
		setInterval(loop,frame_rate*1000)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mass0 = new lib.mass0();
	this.mass0.name = "mass0";
	this.mass0.parent = this;
	this.mass0.setTransform(0,210.5);

	this.massdamper = new lib.massdamper();
	this.massdamper.name = "massdamper";
	this.massdamper.parent = this;
	this.massdamper.setTransform(0.1,-185);

	this.mass7 = new lib.mass7();
	this.mass7.name = "mass7";
	this.mass7.parent = this;
	this.mass7.setTransform(0.1,-82);

	this.mass6 = new lib.mass6();
	this.mass6.name = "mass6";
	this.mass6.parent = this;
	this.mass6.setTransform(0.1,-45);

	this.mass5 = new lib.mass5();
	this.mass5.name = "mass5";
	this.mass5.parent = this;
	this.mass5.setTransform(0.1,-8);

	this.mass4 = new lib.mass4();
	this.mass4.name = "mass4";
	this.mass4.parent = this;
	this.mass4.setTransform(0.1,29);

	this.mass3 = new lib.mass3();
	this.mass3.name = "mass3";
	this.mass3.parent = this;
	this.mass3.setTransform(0.1,66);

	this.mass2 = new lib.mass2();
	this.mass2.name = "mass2";
	this.mass2.parent = this;
	this.mass2.setTransform(0.1,103);

	this.mass1 = new lib.mass1();
	this.mass1.name = "mass1";
	this.mass1.parent = this;
	this.mass1.setTransform(0.1,140);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.mass1},{t:this.mass2},{t:this.mass3},{t:this.mass4},{t:this.mass5},{t:this.mass6},{t:this.mass7},{t:this.massdamper},{t:this.mass0}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.taipei, new cjs.Rectangle(-81.3,-269.5,162.6,537), null);


(lib.pistons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var bob_distance = 45;
		createjs.Tween.get(this.piston1, {loop: -1})
			.to({x:this.piston1.x + bob_distance/2}, 1000, createjs.Ease.linear)
			.to({x:this.piston1.x}, 2500, createjs.Ease.cubicInOut);
			
		createjs.Tween.get(this.piston2, {loop: -1})
			.to({x:this.piston2.x - bob_distance/2}, 1500, createjs.Ease.linear)
			.to({x:this.piston2.x}, 2500, createjs.Ease.cubicInOut);
			
			
		createjs.Tween.get(this.piston3, {loop: -1})
			.to({x:this.piston3.x + bob_distance/2}, 1400, createjs.Ease.linear)
			.to({x:this.piston3.x}, 2500, createjs.Ease.cubicInOut);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.piston3 = new lib.piston3();
	this.piston3.name = "piston3";
	this.piston3.parent = this;
	this.piston3.setTransform(-11.2,15.9);

	this.piston2 = new lib.piston2();
	this.piston2.name = "piston2";
	this.piston2.parent = this;
	this.piston2.setTransform(11.8,0);

	this.piston1 = new lib.piston1();
	this.piston1.name = "piston1";
	this.piston1.parent = this;
	this.piston1.setTransform(-11.2,-15.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.piston1},{t:this.piston2},{t:this.piston3}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.pistons, new cjs.Rectangle(-54.3,-23.1,109.1,46.3), null);


(lib.Evil = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.evil_button.addEventListener("click", fl_ClickToGoToWebPage);
		
		function fl_ClickToGoToWebPage() {
			window.open("lab2.html", "_blank");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai4AaIFkhjIANAwIljBjg");
	this.shape.setTransform(-126.5,-74.3,1.275,1.251);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ai0gtIATguIFWCJIgTAug");
	this.shape_1.setTransform(-222.8,-75.6,1.275,1.251);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(10).p("AEChXQAAA9hMBDQhTBKhjAAQhiAAhThKQhMhDAAg9QAAgZAUgCQAPgBApAOQB3ApA+AAQA+AAB4gpQApgOAOABQAVACAAAZg");
	this.shape_2.setTransform(-174.8,-12.6,1.275,1.251);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhKCnIAAkTICVg5IAAFMg");
	this.shape_3.setTransform(-125.3,-57.2,1.275,1.251);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhHCwIAAlfICPBNIAAESg");
	this.shape_4.setTransform(-225.3,-58.4,1.275,1.251);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#57C7FF").s().p("AklLtQiHg5hphpQhohog5iIQg8iNAAiZQAAivBNibIgBAAQh2h4BAjUQAUhCAkhDIAfg2QgFB0AvA/QAnA2BaAeQBjhQB4grQB7gtCEAAQCAAAB3ApQB0AoBhBLQBhgcArg1QA0g+AAh3IAdA2QAhBCARBCQA5DSh1B2QBUCkAAC2QAACZg7CNQg5CIhpBoQhoBpiIA5QiMA7iaAAQiYAAiNg7g");
	this.shape_5.setTransform(-174.8,-34.9,1.275,1.251);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAtBkQgLgYgNgVQgOgWgPgUIgMgPIgeAcIAAA3IAdAAIAAATIhMAAIAAgTIAcAAIAAihIgcAAIAAgTIBMAAIAAATIgdAAIAABTIBVhTIgVAAIAAgTIBHAAIAAATIgaAAIhCBDIAGAHIAFAGIACADQAPASANAUQAOAVAJATIApAAIAAATg");
	this.shape_6.setTransform(19.2,223.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgwBaQgUgOgMgXQgMgYAAgdQAAgSAGgSQAGgTAMgPQALgPARgJQASgJAXgBQAWABAQAHQAQAIAKAMQAKAMAHAOQAGAOADANQACAOAAAJQgBAdgKAYQgLAXgVAOQgUAOgdABQgbgBgWgOgAghhLQgPAIgIAOQgJANgDAPQgEAOgBAMQABAWAIATQAKATAQAMQARAMAWAAQAYAAAPgMQARgMAIgTQAIgTAAgWQAAgKgDgOQgDgPgIgNQgIgPgOgJQgPgJgVAAQgUAAgOAJg");
	this.shape_7.setTransform(-3.9,223.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgKA6QgEgEAAgFQAAgEAEgFQAFgDAGAAQAFAAAEADQAFAEAAAFQAAAFgEAEQgFAEgGAAQgFAAgFgEgAgEAVIgDhSIAPAAIgDBSg");
	this.shape_8.setTransform(262.9,73.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgJgYIg+AAIgJAYIATAAIAAAMIguAAIAAgMIANAAIAphhIggAAIAAgMIA0AAIAtBtIAMAAIAAAMgAAbANIgbhBIgZBBIA0AAg");
	this.shape_9.setTransform(249.5,73);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AANA9IAAgMIARAAIAAgqIg7AAIAAAqIARAAIAAAMIguAAIAAgMIASAAIAAhhIgSAAIAAgMIAuAAIAAAMIgRAAIAAAsIA7AAIAAgsIgRAAIAAgMIAtAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_10.setTransform(236.3,73);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgKgYIg9AAIgKAYIAUAAIAAAMIguAAIAAgMIAOAAIAnhhIgeAAIAAgMIA0AAIAtBtIALAAIAAAMgAAcANIgbhBIgZBBIA0AAg");
	this.shape_11.setTransform(223,73);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AANA9IAAgMIARAAIAAgqIg7AAIAAAqIARAAIAAAMIguAAIAAgMIASAAIAAhhIgSAAIAAgMIAuAAIAAAMIgRAAIAAAsIA7AAIAAgsIgRAAIAAgMIAuAAIAAAMIgSAAIAABhIASAAIAAAMg");
	this.shape_12.setTransform(209.7,73);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgKgYIg9AAIgKAYIAUAAIAAAMIguAAIAAgMIAOAAIAnhhIgeAAIAAgMIA0AAIAtBtIALAAIAAAMgAAcANIgbhBIgZBBIA0AAg");
	this.shape_13.setTransform(196.4,73);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AANA9IAAgMIAQAAIAAgqIg5AAIAAAqIARAAIAAAMIguAAIAAgMIAQAAIAAhhIgQAAIAAgMIAuAAIAAAMIgRAAIAAAsIA5AAIAAgsIgQAAIAAgMIAuAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_14.setTransform(183.2,73);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgJgYIg+AAIgJAYIATAAIAAAMIguAAIAAgMIANAAIAphhIggAAIAAgMIA0AAIAtBtIAMAAIAAAMgAAbANIgbhBIgZBBIA0AAg");
	this.shape_15.setTransform(169.9,73);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AANA9IAAgMIARAAIAAgqIg7AAIAAAqIARAAIAAAMIguAAIAAgMIASAAIAAhhIgSAAIAAgMIAuAAIAAAMIgRAAIAAAsIA7AAIAAgsIgRAAIAAgMIAtAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_16.setTransform(156.7,73);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgKgYIg9AAIgKAYIAUAAIAAAMIguAAIAAgMIANAAIAohhIgeAAIAAgMIA0AAIAtBtIALAAIAAAMgAAcANIgbhBIgaBBIA1AAg");
	this.shape_17.setTransform(143.4,73);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AANA9IAAgMIAQAAIAAgqIg5AAIAAAqIARAAIAAAMIguAAIAAgMIARAAIAAhhIgRAAIAAgMIAuAAIAAAMIgRAAIAAAsIA5AAIAAgsIgQAAIAAgMIAuAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_18.setTransform(130.2,73);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgJgYIg+AAIgKAYIAUAAIAAAMIguAAIAAgMIAOAAIAohhIgfAAIAAgMIAzAAIAtBtIAMAAIAAAMgAAbANIgbhBIgYBBIAzAAg");
	this.shape_19.setTransform(116.9,73);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AANA9IAAgMIAQAAIAAgqIg5AAIAAAqIARAAIAAAMIguAAIAAgMIARAAIAAhhIgRAAIAAgMIAuAAIAAAMIgRAAIAAAsIA5AAIAAgsIgQAAIAAgMIAuAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_20.setTransform(103.7,73);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgKgYIg9AAIgJAYIATAAIAAAMIguAAIAAgMIAOAAIAnhhIgeAAIAAgMIAzAAIAtBtIAMAAIAAAMgAAbANIgbhBIgYBBIAzAAg");
	this.shape_21.setTransform(90.4,73);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AANA9IAAgMIAQAAIAAgqIg6AAIAAAqIARAAIAAAMIguAAIAAgMIARAAIAAhhIgRAAIAAgMIAuAAIAAAMIgRAAIAAAsIA6AAIAAgsIgQAAIAAgMIAtAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_22.setTransform(77.2,73);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgJgYIg+AAIgJAYIATAAIAAAMIguAAIAAgMIANAAIAphhIggAAIAAgMIA0AAIAtBtIAMAAIAAAMgAAbANIgahBIgaBBIA0AAg");
	this.shape_23.setTransform(63.9,73);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AANA9IAAgMIARAAIAAgqIg6AAIAAAqIARAAIAAAMIguAAIAAgMIARAAIAAhhIgRAAIAAgMIAuAAIAAAMIgRAAIAAAsIA6AAIAAgsIgRAAIAAgMIAuAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_24.setTransform(50.7,73);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgKgYIg9AAIgKAYIAUAAIAAAMIguAAIAAgMIAOAAIAnhhIgeAAIAAgMIA0AAIAtBtIALAAIAAAMgAAcANIgbhBIgZBBIA0AAg");
	this.shape_25.setTransform(37.4,73);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AANA9IAAgMIAQAAIAAgqIg5AAIAAAqIAQAAIAAAMIguAAIAAgMIARAAIAAhhIgRAAIAAgMIAuAAIAAAMIgQAAIAAAsIA5AAIAAgsIgQAAIAAgMIAtAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_26.setTransform(24.2,73);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgKgYIg9AAIgKAYIAUAAIAAAMIguAAIAAgMIAOAAIAnhhIgeAAIAAgMIA0AAIAtBtIALAAIAAAMgAAcANIgbhBIgZBBIA0AAg");
	this.shape_27.setTransform(10.8,73);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AANA9IAAgMIAQAAIAAgqIg5AAIAAAqIAQAAIAAAMIguAAIAAgMIARAAIAAhhIgRAAIAAgMIAuAAIAAAMIgQAAIAAAsIA5AAIAAgsIgQAAIAAgMIAtAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_28.setTransform(-2.4,73);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgJgYIg+AAIgJAYIATAAIAAAMIguAAIAAgMIANAAIAphhIggAAIAAgMIA0AAIAtBtIAMAAIAAAMgAAbANIgbhBIgZBBIA0AAg");
	this.shape_29.setTransform(-15.7,73);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AANA9IAAgMIARAAIAAgqIg7AAIAAAqIARAAIAAAMIgtAAIAAgMIARAAIAAhhIgRAAIAAgMIAtAAIAAAMIgRAAIAAAsIA7AAIAAgsIgRAAIAAgMIAuAAIAAAMIgSAAIAABhIASAAIAAAMg");
	this.shape_30.setTransform(-28.9,73);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgKgYIg9AAIgKAYIAUAAIAAAMIguAAIAAgMIANAAIAohhIgeAAIAAgMIA0AAIAtBtIALAAIAAAMgAAcANIgbhBIgaBBIA1AAg");
	this.shape_31.setTransform(289.2,45.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AANA9IAAgMIAQAAIAAgqIg5AAIAAAqIARAAIAAAMIguAAIAAgMIARAAIAAhhIgRAAIAAgMIAuAAIAAAMIgRAAIAAAsIA5AAIAAgsIgQAAIAAgMIAuAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_32.setTransform(276,45.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgKgYIg9AAIgKAYIAUAAIAAAMIguAAIAAgMIAOAAIAnhhIgeAAIAAgMIAzAAIAtBtIAMAAIAAAMgAAbANIgbhBIgYBBIAzAAg");
	this.shape_33.setTransform(262.7,45.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AANA9IAAgMIAQAAIAAgqIg6AAIAAAqIARAAIAAAMIguAAIAAgMIARAAIAAhhIgRAAIAAgMIAuAAIAAAMIgRAAIAAAsIA6AAIAAgsIgQAAIAAgMIAtAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_34.setTransform(249.5,45.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgJgYIg+AAIgJAYIATAAIAAAMIguAAIAAgMIANAAIAphhIggAAIAAgMIA0AAIAtBtIAMAAIAAAMgAAbANIgahBIgaBBIA0AAg");
	this.shape_35.setTransform(236.2,45.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AANA9IAAgMIARAAIAAgqIg6AAIAAAqIARAAIAAAMIguAAIAAgMIARAAIAAhhIgRAAIAAgMIAuAAIAAAMIgRAAIAAAsIA6AAIAAgsIgRAAIAAgMIAuAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_36.setTransform(223,45.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgJgYIg+AAIgJAYIATAAIAAAMIguAAIAAgMIANAAIAphhIggAAIAAgMIA0AAIAtBtIAMAAIAAAMgAAbANIgbhBIgZBBIA0AAg");
	this.shape_37.setTransform(209.7,45.2);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AANA9IAAgMIARAAIAAgqIg6AAIAAAqIARAAIAAAMIguAAIAAgMIARAAIAAhhIgRAAIAAgMIAuAAIAAAMIgRAAIAAAsIA6AAIAAgsIgRAAIAAgMIAuAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_38.setTransform(196.5,45.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgKgYIg9AAIgKAYIAUAAIAAAMIguAAIAAgMIAOAAIAnhhIgeAAIAAgMIA0AAIAtBtIALAAIAAAMgAAcANIgbhBIgZBBIA0AAg");
	this.shape_39.setTransform(183.2,45.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AANA9IAAgMIAQAAIAAgqIg5AAIAAAqIAQAAIAAAMIguAAIAAgMIARAAIAAhhIgRAAIAAgMIAuAAIAAAMIgQAAIAAAsIA5AAIAAgsIgQAAIAAgMIAtAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_40.setTransform(170,45.2);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgJgYIg+AAIgJAYIATAAIAAAMIguAAIAAgMIANAAIAphhIggAAIAAgMIA0AAIAtBtIAMAAIAAAMgAAbANIgbhBIgZBBIA0AAg");
	this.shape_41.setTransform(156.7,45.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AANA9IAAgMIARAAIAAgqIg7AAIAAAqIARAAIAAAMIgtAAIAAgMIARAAIAAhhIgRAAIAAgMIAtAAIAAAMIgRAAIAAAsIA7AAIAAgsIgRAAIAAgMIAuAAIAAAMIgSAAIAABhIASAAIAAAMg");
	this.shape_42.setTransform(143.5,45.2);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgKgYIg9AAIgKAYIAUAAIAAAMIguAAIAAgMIAOAAIAnhhIgeAAIAAgMIA0AAIAtBtIALAAIAAAMgAAcANIgbhBIgZBBIA0AAg");
	this.shape_43.setTransform(130.2,45.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AANA9IAAgMIAQAAIAAgqIg5AAIAAAqIARAAIAAAMIgvAAIAAgMIARAAIAAhhIgRAAIAAgMIAvAAIAAAMIgRAAIAAAsIA5AAIAAgsIgQAAIAAgMIAtAAIAAAMIgQAAIAABhIAQAAIAAAMg");
	this.shape_44.setTransform(117,45.2);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgKgYIg9AAIgKAYIAUAAIAAAMIguAAIAAgMIAOAAIAnhhIgeAAIAAgMIA0AAIAtBtIALAAIAAAMgAAcANIgbhBIgZBBIA0AAg");
	this.shape_45.setTransform(103.6,45.2);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AANA9IAAgMIAQAAIAAgqIg5AAIAAAqIARAAIAAAMIgvAAIAAgMIARAAIAAhhIgRAAIAAgMIAvAAIAAAMIgRAAIAAAsIA5AAIAAgsIgQAAIAAgMIAtAAIAAAMIgQAAIAABhIAQAAIAAAMg");
	this.shape_46.setTransform(90.4,45.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgJgYIg+AAIgJAYIATAAIAAAMIguAAIAAgMIANAAIAphhIggAAIAAgMIA0AAIAtBtIAMAAIAAAMgAAbANIgbhBIgZBBIA0AAg");
	this.shape_47.setTransform(77.1,45.2);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AANA9IAAgMIARAAIAAgqIg7AAIAAAqIARAAIAAAMIguAAIAAgMIASAAIAAhhIgSAAIAAgMIAuAAIAAAMIgRAAIAAAsIA7AAIAAgsIgRAAIAAgMIAuAAIAAAMIgSAAIAABhIASAAIAAAMg");
	this.shape_48.setTransform(63.9,45.2);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgKgYIg9AAIgKAYIAUAAIAAAMIguAAIAAgMIAOAAIAnhhIgeAAIAAgMIA0AAIAtBtIALAAIAAAMgAAcANIgbhBIgZBBIA0AAg");
	this.shape_49.setTransform(50.6,45.2);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AANA9IAAgMIAQAAIAAgqIg5AAIAAAqIARAAIAAAMIguAAIAAgMIAQAAIAAhhIgQAAIAAgMIAuAAIAAAMIgRAAIAAAsIA5AAIAAgsIgQAAIAAgMIAuAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_50.setTransform(37.4,45.2);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgJgYIg+AAIgJAYIATAAIAAAMIguAAIAAgMIANAAIAphhIggAAIAAgMIA0AAIAtBtIAMAAIAAAMgAAbANIgbhBIgZBBIA0AAg");
	this.shape_51.setTransform(24.1,45.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AANA9IAAgMIAQAAIAAgqIg5AAIAAAqIARAAIAAAMIguAAIAAgMIAQAAIAAhhIgQAAIAAgMIAuAAIAAAMIgRAAIAAAsIA5AAIAAgsIgQAAIAAgMIAuAAIAAAMIgRAAIAABhIARAAIAAAMg");
	this.shape_52.setTransform(10.9,45.2);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgJgYIg+AAIgJAYIATAAIAAAMIguAAIAAgMIANAAIAphhIggAAIAAgMIA0AAIAtBtIAMAAIAAAMgAAbANIgbhBIgZBBIA0AAg");
	this.shape_53.setTransform(-2.4,45.2);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AAaA9IgahKIgYBKIgNAAIgNhtIgKAAIAAgMIArAAIAAAMIgVAAIAKBYIAZhLIAHAAIAaBKIAJhXIgWAAIAAgMIAsAAIAAAMIgKAAIgMBtg");
	this.shape_54.setTransform(-15.6,45.2);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("Ag2A9IAAgMIARAAIAAhhIgRAAIAAgMIA3AAIAQABQAIABAHAEQAHADAEAIIADAIIABAJIgCAJIgEAJQgCADgEADIgHADQAHABAGADQAGAEAEAGQAEAGAAAIQAAAFgCAGQgCAFgEAEQgGAHgJACQgJADgKAAgAgZAxIAgAAIANgBQAHAAAFgDQAGgCACgFQADgEAAgFQAAgFgCgEQgDgEgEgCQgGgEgHgCIgPgBIgfAAgAgZgEIAZAAQAIAAAHgBQAHgBAGgFQADgDACgEQACgEAAgFQgBgIgFgGQgFgFgIgBIgNgBIgJAAIgTAAg");
	this.shape_55.setTransform(-29,45.2);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgJA6QgFgEAAgFQAAgEAFgFQADgDAGAAQAGAAAEADQAEAEABAFQgBAFgEAEQgDAEgHAAQgFAAgEgEgAgEAVIgDhSIAPAAIgDBSg");
	this.shape_56.setTransform(223.2,-10.1);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("Ag5BEIAAgMIASAAIAAhsIgSAAIAAgMIAeAAIAAAOQAGgHAKgFQAKgFANAAQAMAAALAGQALAHAHAMIAEALIABAMQAAAPgGAJQgHALgKAHQgLAGgOAAQgJABgHgDQgHgDgFgEQgGgDgDgFIAAAsIAgAAIAAAMgAgJgyQgIAFgFAJQgEAHAAALQAAAKAFAIQAFAIAIAFQAIAFAKAAQAJAAAIgFQAIgEAGgIQAFgIAAgMQAAgEgCgHQgBgGgEgGQgEgFgHgFQgHgDgLAAQgKgBgJAGg");
	this.shape_57.setTransform(209.3,-6.9);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgrBCIAAgLIAmAAIAAhtIglAAIAAgLIAwAAIAAB4IAmAAIAAALg");
	this.shape_58.setTransform(196.4,-10.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgcAqQgLgHgGgLQgFgLAAgNQAAgOAHgLQAHgLAMgGQALgGAOAAQARAAALAHQALAHAFAMQAFALAAANIhYAAIAAABQAAAJAFAIQAEAHAGAEQAGAEAHABIAOABQAIAAALgDQAMgDANgHIADALQgKAGgNAEQgNAEgNAAQgSAAgMgHgAAlgJIgBgHQgCgEgEgFQgEgEgHgEQgHgDgLAAQgMAAgIAEQgIAEgFAGQgEAGgBAHIBKAAIAAAAg");
	this.shape_59.setTransform(183.2,-8.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AAMBCIAAgLIARAAIAAgxQAAgGgBgFQgBgEgFgEQgEgDgKAAQgHAAgFADQgHACgGAFIgLAHIAAA2IASAAIAAALIgvAAIAAgLIASAAIAAhtIgTAAIAAgLIAeAAIAAA3QAJgHAKgGQAJgEALAAQANgBAGAFQAHAFACAGQADAHAAAGIAAA2IARAAIAAALg");
	this.shape_60.setTransform(170.2,-10.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgcAqQgLgHgGgLQgFgLAAgNQAAgOAHgLQAHgLAMgGQALgGAOAAQARAAALAHQALAHAFAMQAFALAAANIhYAAIAAABQAAAJAFAIQAEAHAGAEQAGAEAHABIAOABQAIAAALgDQAMgDANgHIADALQgKAGgNAEQgNAEgNAAQgSAAgMgHgAAlgJIgBgHQgCgEgEgFQgEgEgHgEQgHgDgLAAQgMAAgIAEQgIAEgFAGQgEAGgBAHIBKAAIAAAAg");
	this.shape_61.setTransform(143.4,-8.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AAMBCIAAgLIASAAIAAgxQAAgGgCgFQgBgEgFgEQgEgDgKAAQgGAAgGADQgHACgGAFIgLAHIAAA2IASAAIAAALIgvAAIAAgLIASAAIAAhtIgTAAIAAgLIAeAAIAAA3QAIgHALgGQAJgEAMAAQAMgBAHAFQAGAFACAGQACAHABAGIAAA2IARAAIAAALg");
	this.shape_62.setTransform(130.4,-10.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgHA8QgGgBgGgDQgFgDgEgGQgDgFAAgJIAAg2IgQAAIAAgMIAQAAIAAgbIALAAIAAAbIA3AAIAAAMIg3AAIAAAxQAAAFACAFQACAFAFADIAIACIAIABQAHAAAHgCIAPgEIANgGIABAMIgWAIQgLAEgNAAIgJgBg");
	this.shape_63.setTransform(116.8,-10);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("Ag0AvIAAgLIAaAAIAAhEIgaAAIAAgMIAmAAIAAAZIAOgNQAHgGAIgEQAIgFALABQAFgBAEACQAEACACAEIAEAFIABAHIgMAAQgCgFgDgCQgDgBgEAAQgGAAgGACQgFADgIAGIgTASIAAAqIApAAIAAALg");
	this.shape_64.setTransform(90.9,-8.9);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgcArQgMgHgHgLQgGgLgBgOQABgOAHgLQAHgLANgGQAMgGAOAAQAQAAAKAFQALAFAGAIQAGAHADAJQACAIAAAGQABAOgHALQgHALgLAGQgMAHgRAAQgQAAgNgGgAgVgfQgKAFgGAJQgEAIAAAJQAAAJAEAIQAFAJAKAFQAJAGANAAQANAAAKgFQAJgEAFgJQAFgIAAgLIgBgJQgCgHgFgGQgEgGgIgEQgJgEgNAAQgMAAgJAFg");
	this.shape_65.setTransform(77.2,-8.8);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgsBCIAAgLIAWAAIAAhEIgWAAIAAgMIAWAAIAAgLIAAgGIABgGQACgGAEgEQAFgDAFgCIAKgCIAJAAIAKAAIAMABIAKABIgEALIgNgBIgPgBQgMAAgEACQgGADAAAEQgCAEABAFIAAALIAtAAIAAAMIgtAAIAABEIAtAAIAAALg");
	this.shape_66.setTransform(64.1,-10.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgQAuQgJgDgIgEIAAAKIgMAAIAAgkIAMAAIAAAMQAIAGAJADQAJADAJAAIAIAAIALgDQAFgBAEgEQAEgDAAgGIAAgDIgBgDQgDgEgFgCQgFgBgEAAIgKgBIgPgBQgIAAgIgDQgHgCgFgEQgDgCgCgEIgBgIQAAgOAKgIQALgIATAAQAHAAAJACQAIACAIAFIAAgJIAMAAIAAAiIgMAAIAAgNQgHgEgIgDQgJgCgIAAIgIAAIgJADIgIAFQgDADAAAFQAAADABACIAEAFQAGADAHABQAIABAHAAIAQABQAIABAGACQAGABAEAFQAEAFAAAIQAAAKgFAGQgGAHgJAEQgJAEgMAAQgMAAgJgDg");
	this.shape_67.setTransform(37.5,-8.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AALBCIAAgLIAMAAIgNgOIgMgOIgLgJIgNAJIAAAnIgeAAIAAgLIASAAIAAhtIgSAAIAAgLIAeAAIAABQIAlgcIgKAAIAAgMIAvAAIAAAMIgVAAIggAZIAPAPIANANIANAPIAVAAIAAALg");
	this.shape_68.setTransform(24.3,-10.8);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AALAvIAAgLIASAAIAAg2QAAgHgDgDQgEgFgFgBIgJgBQgJABgKAEQgKAFgHAHIAAA2IASAAIAAALIgwAAIAAgLIASAAIAAhEIgSAAIAAgMIAeAAIAAAOQAIgIAKgEQAKgFALABQAIgBAGACQAEACAEADQAFAEACAGQABAGAAAGIAAA2IASAAIAAALg");
	this.shape_69.setTransform(11,-8.9);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgkAsQgIgEgFgGQgEgHAAgHQABgGAEgIQAEgGAKgFQALgFARAAIAPABIAPACIAAgHQABgFgDgFQgBgFgEgCQgEgDgGgBQgGgBgEAAIgOACIgOADIgJAEIgDgMIAUgGQALgDAMAAQAMAAAIAEQAJAEADAHIAEAJIAAAIIAAAzIASAAIAAALIgdAAIAAgSQgKAJgLAGQgJAGgNAAQgLAAgHgFgAgSACQgIABgHAEQgDACgCAEQgCADAAAEQAAAEADAEQACAEAGADQAEACAIAAQAMAAAKgGQALgHAIgKIAAgKIgOgCIgMgBIgQABg");
	this.shape_70.setTransform(-2.3,-8.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AAMBCIAAgLIARAAIAAgxQABgGgCgFQgCgEgEgEQgFgDgIAAQgIAAgFADQgHACgFAFIgMAHIAAA2IASAAIAAALIgwAAIAAgLIASAAIAAhtIgSAAIAAgLIAeAAIAAA3QAIgHALgGQAJgEALAAQANgBAGAFQAHAFACAGQACAHAAAGIAAA2IASAAIAAALg");
	this.shape_71.setTransform(-15.4,-10.8);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgfA9IAAgMIAaAAIAAhhIgmAAIAAAfIgMAAIAAgrIBvAAIAAArIgMAAIAAgfIgmAAIAABhIAaAAIAAAMg");
	this.shape_72.setTransform(-28.8,-10.3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgJA6QgFgEAAgFQAAgEAFgFQADgDAGAAQAGAAAEADQAEAEABAFQgBAGgEADQgDAEgHAAQgFAAgEgEgAgEAVIgDhSIAPAAIgDBSg");
	this.shape_73.setTransform(196.6,-65.7);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgjA9QgLgHgFgLQgGgMAAgMQAAgOAGgKQAHgLALgGQALgHAOAAQAIAAAKADQAKAEAIAKIAAgrIgcAAIAAgMIAoAAIAAB5IASAAIAAALIgeAAIAAgQQgGAJgKAFQgKAFgKAAQgQAAgLgHgAgbgMQgIAFgFAIQgFAIAAAKQAAAJAEAJQAFAIAIAGQAIAFAMAAQAKAAAIgFQAIgFAFgIQAEgJAAgLIgBgMQgCgGgEgFQgEgFgHgEQgHgDgKAAQgLAAgIAFg");
	this.shape_74.setTransform(183.6,-66.3);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgcAqQgLgHgGgLQgFgLAAgNQAAgOAHgLQAHgLAMgGQALgGAOAAQARAAALAHQALAHAFAMQAFALAAANIhYAAIAAABQAAAJAFAIQAEAHAGAEQAGAEAHABIAOABQAIAAALgDQAMgDANgHIADALQgKAGgNAEQgNAEgNAAQgSAAgMgHgAAlgJIgBgHQgCgEgEgFQgEgEgHgEQgHgDgLAAQgMAAgIAEQgIAEgFAGQgEAGgBAHIBKAAIAAAAg");
	this.shape_75.setTransform(169.9,-64.4);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgjA9QgLgHgFgLQgGgMAAgMQAAgOAGgKQAHgLALgGQALgHAOAAQAIAAAKADQAKAEAIAKIAAgrIgcAAIAAgMIAoAAIAAB5IASAAIAAALIgeAAIAAgQQgGAJgKAFQgKAFgKAAQgQAAgLgHgAgbgMQgIAFgFAIQgFAIAAAKQAAAJAEAJQAFAIAIAGQAIAFAMAAQAKAAAIgFQAIgFAFgIQAEgJAAgLIgBgMQgCgGgEgFQgEgFgHgEQgHgDgKAAQgLAAgIAFg");
	this.shape_76.setTransform(157.1,-66.3);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgcAqQgLgHgGgLQgFgLAAgNQAAgOAHgLQAHgLAMgGQALgGAOAAQARAAALAHQALAHAFAMQAFALAAANIhYAAIAAABQAAAJAFAIQAEAHAGAEQAGAEAHABIAOABQAIAAALgDQAMgDANgHIADALQgKAGgNAEQgNAEgNAAQgSAAgMgHgAAlgJIgBgHQgCgEgEgFQgEgEgHgEQgHgDgLAAQgMAAgIAEQgIAEgFAGQgEAGgBAHIBKAAIAAAAg");
	this.shape_77.setTransform(143.4,-64.4);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgcAqQgLgHgGgLQgFgLAAgNQAAgOAHgLQAHgLAMgGQALgGAOAAQARAAALAHQALAHAFAMQAFALAAANIhYAAIAAABQAAAJAFAIQAEAHAGAEQAGAEAHABIAOABQAIAAALgDQAMgDANgHIADALQgKAGgNAEQgNAEgNAAQgSAAgMgHgAAlgJIgBgHQgCgEgEgFQgEgEgHgEQgHgDgLAAQgMAAgIAEQgIAEgFAGQgEAGgBAHIBKAAIAAAAg");
	this.shape_78.setTransform(130.2,-64.4);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgXArQgLgGgHgLQgHgLgBgPQAAgIADgIQADgIAGgHQAHgIAKgEQAKgFANAAQAJAAAIADQAIACAIAFIAAgKIAMAAIAAAlIgMAAIAAgOQgHgGgJgDQgIgCgJAAQgMAAgJAFQgJAFgFAJQgFAIAAAJQAAAFACAGQACAHAFAGQAFAGAIADQAJAEALAAQAJAAAIgDQAIgDAGgEIAJgHIAFAMQgKAIgLAEQgMAFgPAAQgNAAgMgGg");
	this.shape_79.setTransform(117,-64.4);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgXArQgLgGgHgLQgHgLgBgPQAAgIADgIQADgIAGgHQAHgIAKgEQAKgFANAAQAJAAAIADQAIACAIAFIAAgKIAMAAIAAAlIgMAAIAAgOQgHgGgJgDQgIgCgJAAQgMAAgJAFQgJAFgFAJQgFAIAAAJQAAAFACAGQACAHAFAGQAFAGAIADQAJAEALAAQAJAAAIgDQAIgDAGgEIAJgHIAFAMQgKAIgLAEQgMAFgPAAQgNAAgMgGg");
	this.shape_80.setTransform(103.7,-64.4);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgTAuQgGgCgFgEQgFgEgDgGQgCgGAAgGIAAg0IgSAAIAAgNIAeAAIAAA7QAAAFABAGQACAFAFADQAEADAEABIAJABQAJAAAIgGQAJgFAHgJIAAgyIgSAAIAAgNIAdAAIAABQIASAAIAAAMIgdAAIAAgOQgJAIgHADQgGAEgFABIgJABQgGgBgHgBg");
	this.shape_81.setTransform(90.4,-64.2);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgQAuQgJgDgIgEIAAAKIgMAAIAAgkIAMAAIAAAMQAIAGAJADQAJADAJAAIAIAAIALgDQAFgBAEgEQAEgDAAgGIAAgDIgCgDQgDgEgEgCQgEgBgFAAIgLgBIgOgBQgIAAgIgDQgHgCgFgEQgEgCgBgEIgBgIQAAgOAKgIQAMgIARAAQAIAAAJACQAIACAIAFIAAgJIALAAIAAAiIgLAAIAAgNQgHgEgJgDQgIgCgIAAIgJAAIgJADIgHAFQgDADgBAFQABADABACIAFAFQAEADAIABQAHABAIAAIAQABQAHABAHACQAGABAEAFQADAFABAIQAAAKgGAGQgEAHgKAEQgJAEgNAAQgLAAgJgDg");
	this.shape_82.setTransform(77.3,-64.4);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgzBDIAAgMIAYAAIAVgjIgohKIgPAAIAAgMIAqAAIAAAMIgOAAIAhA/IAjg/IgMAAIAAgMIAnAAIAAAMIgOAAIg+BtIARAAIAAAMg");
	this.shape_83.setTransform(50.8,-62.3);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgrBCIAAgLIAmAAIAAhtIglAAIAAgMIAwAAIAAB5IAmAAIAAALg");
	this.shape_84.setTransform(37.4,-66.4);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgrBCIAAgLIAmAAIAAhtIglAAIAAgMIAwAAIAAB5IAmAAIAAALg");
	this.shape_85.setTransform(24.1,-66.4);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AglAsQgIgEgDgGQgFgHAAgHQABgGAEgIQAFgGAJgFQALgFARAAIAPABIAPACIAAgHQAAgFgBgFQgCgFgEgCQgFgDgFgBQgFgBgFAAIgPACIgMADIgKAEIgDgMIAVgGQAKgDAMAAQAMAAAIAEQAJAEADAHIADAJIABAIIAAAzIARAAIAAALIgcAAIAAgSQgKAJgKAGQgLAGgMAAQgLAAgIgFgAgSACQgJABgGAEQgDACgCAEQgCADAAAEQAAAEADAEQACAEAGADQAFACAGAAQANAAAKgGQALgHAIgKIAAgKIgOgCIgMgBIgQABg");
	this.shape_86.setTransform(11,-64.4);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AALAvIAAgLIASAAIAAg1QAAgIgDgDQgEgFgEgBIgKgBQgJABgKAEQgKAFgHAIIAAA1IASAAIAAALIgwAAIAAgLIASAAIAAhEIgSAAIAAgMIAeAAIAAANQAIgHALgEQAJgFALABQAIAAAGABQAFACADADQAFAEABAGQACAGAAAHIAAA1IASAAIAAALg");
	this.shape_87.setTransform(-2.3,-64.5);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgrBFIAAgLIAmAAIAAhEIggAAIAAgMIArAAIAABQIAmAAIAAALgAgIgqIAAgaIAOAAIAAAag");
	this.shape_88.setTransform(-15.6,-66.7);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgsBCIAAgLIAWAAIAAhEIgWAAIAAgMIAWAAIAAgLIAAgGIABgGQACgHAEgDQAFgEAFgBIAKgDIAJAAIAKABIAMABIAKABIgEAMIgNgCIgPgBQgMAAgEADQgGACAAAEQgCAEAAAFIAAALIAuAAIAAAMIguAAIAABEIAuAAIAAALg");
	this.shape_89.setTransform(-28.7,-66.4);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgcAqQgLgHgGgLQgFgLAAgNQAAgOAHgLQAHgLAMgGQALgGAOAAQARAAALAHQALAHAFAMQAFALAAANIhYAAIAAABQAAAJAFAIQAEAHAGAEQAGAEAHABIAOABQAIAAALgDQAMgDANgHIADALQgKAGgNAEQgNAEgNAAQgSAAgMgHgAAlgJIgBgHQgCgEgEgFQgEgEgHgEQgHgDgLAAQgMAAgIAEQgIAEgFAGQgEAGgBAHIBKAAIAAAAg");
	this.shape_90.setTransform(236.2,-92.2);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AASAuIgSg0IgQA0IgNAAIgXhPIgIAAIAAgMIAjAAIAAAMIgQAAIATA/IASg5IAKAAIASA5IATg/IgQAAIAAgMIAiAAIAAAMIgHAAIgYBPg");
	this.shape_91.setTransform(223.2,-92.2);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgRAbIAQg1IATAAIgVA1g");
	this.shape_92.setTransform(195.7,-87.5);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AAMBCIAAgLIASAAIAAgyQAAgFgCgFQgBgEgFgEQgEgDgKAAQgGAAgGADQgHACgGAFIgLAHIAAA2IASAAIAAALIgvAAIAAgLIASAAIAAhtIgTAAIAAgMIAeAAIAAA4QAIgHALgGQAJgEAMAAQAMgBAHAFQAGAEACAHQACAHABAGIAAA2IARAAIAAALg");
	this.shape_93.setTransform(183.4,-94.2);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgXArQgLgGgHgLQgHgLgBgPQAAgIADgIQADgIAGgHQAHgIAKgEQAKgFANAAQAJAAAIADQAIACAIAFIAAgKIAMAAIAAAlIgMAAIAAgOQgHgGgJgDQgIgCgJAAQgMAAgJAFQgJAFgFAJQgFAIAAAJQAAAFACAGQACAHAFAGQAFAGAIADQAJAEALAAQAJAAAIgDQAIgDAGgEIAJgHIAFAMQgKAIgLAEQgMAFgPAAQgNAAgMgGg");
	this.shape_94.setTransform(170,-92.2);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("Ag0AvIAAgLIAbAAIAAhEIgbAAIAAgMIAmAAIAAAZIAOgNQAHgGAIgEQAIgFALABQAFAAAEABQAEABACAEIADAGIACAHIgMABQgBgGgDgCQgEgCgEABQgGAAgFACQgGADgIAGIgTASIAAAqIAqAAIAAALg");
	this.shape_95.setTransform(157.2,-92.3);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AglAsQgHgEgFgGQgDgHAAgHQgBgGAFgIQAEgGALgFQAKgFASAAIAOABIAPACIAAgHQABgFgCgFQgCgFgEgCQgEgDgGgBQgGgBgEAAIgPACIgNADIgJAEIgDgMIAVgGQAKgDALAAQANAAAJAEQAIAEADAHIADAJIABAIIAAAzIARAAIAAALIgdAAIAAgSQgIAJgMAGQgKAGgMAAQgLAAgIgFgAgTACQgHABgGAEQgEACgCAEQgCADAAAEQAAAEACAEQADAEAFADQAFACAHAAQANAAAKgGQALgHAIgKIAAgKIgNgCIgOgBIgQABg");
	this.shape_96.setTransform(143.6,-92.2);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgcAqQgLgHgGgLQgFgLAAgNQAAgOAHgLQAHgLAMgGQALgGAOAAQARAAALAHQALAHAFAMQAFALAAANIhYAAIAAABQAAAJAFAIQAEAHAGAEQAGAEAHABIAOABQAIAAALgDQAMgDANgHIADALQgKAGgNAEQgNAEgNAAQgSAAgMgHgAAlgJIgBgHQgCgEgEgFQgEgEgHgEQgHgDgLAAQgMAAgIAEQgIAEgFAGQgEAGgBAHIBKAAIAAAAg");
	this.shape_97.setTransform(130.2,-92.2);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgQAuQgJgDgIgEIAAAKIgMAAIAAgkIAMAAIAAAMQAIAGAJADQAJADAJAAIAIAAIALgDQAFgBAEgEQAEgDAAgGIAAgDIgBgDQgEgEgEgCQgFgBgEAAIgKgBIgPgBQgIAAgIgDQgGgCgGgEQgDgCgCgEIgBgIQAAgOAKgIQALgIATAAQAHAAAJACQAJACAHAFIAAgJIAMAAIAAAiIgMAAIAAgNQgHgEgIgDQgJgCgIAAIgIAAIgJADIgIAFQgDADgBAFQAAADACACIAEAFQAFADAIABQAIABAHAAIAQABQAIABAGACQAGABAEAFQADAFABAIQAAAKgFAGQgGAHgJAEQgKAEgLAAQgMAAgJgDg");
	this.shape_98.setTransform(117.1,-92.2);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgcAqQgLgHgGgLQgFgLAAgNQAAgOAHgLQAHgLAMgGQALgGAOAAQARAAALAHQALAHAFAMQAFALAAANIhYAAIAAABQAAAJAFAIQAEAHAGAEQAGAEAHABIAOABQAIAAALgDQAMgDANgHIADALQgKAGgNAEQgNAEgNAAQgSAAgMgHgAAlgJIgBgHQgCgEgEgFQgEgEgHgEQgHgDgLAAQgMAAgIAEQgIAEgFAGQgEAGgBAHIBKAAIAAAAg");
	this.shape_99.setTransform(103.6,-92.2);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("Ag0AvIAAgLIAaAAIAAhEIgaAAIAAgMIAmAAIAAAZIAOgNQAHgGAIgEQAIgFALABQAFAAAEABQAEABACAEIAEAGIABAHIgMABQgCgGgDgCQgDgCgEABQgGAAgGACQgFADgIAGIgTASIAAAqIApAAIAAALg");
	this.shape_100.setTransform(90.9,-92.3);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgZBBIgWgDIADgMIATAFQAKABALAAQASAAAJgFQAKgGgBgPIAAgaQgFAFgGADQgGAEgIACIgNACQgSgBgKgGQgLgHgGgJQgFgJgBgLQAAgKAHgKQAFgKAMgHQAKgHARAAQAMAAAKAFQAKAEAGAGIAAgNIAaAAIAAANIgOAAIAABVQAAARgMAJQgLAJgVAAQgMAAgNgDgAgZgzQgJAEgFAHQgGAHAAAKQABAJAEAHQAFAHAKADQAIAEALABQAKgBAJgEQAJgDAEgHQAGgHgBgKIgBgJIgGgLQgFgEgHgEQgHgEgKAAQgLAAgJAFg");
	this.shape_101.setTransform(63.9,-90.2);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AAMAvIAAgLIASAAIAAg1QgBgIgDgDQgDgFgGgBIgJgBQgJAAgLAFQgJAFgHAIIAAA1IASAAIAAALIgwAAIAAgLIASAAIAAhEIgSAAIAAgMIAeAAIAAANQAIgHAKgEQAKgFAMABQAHAAAFABQAFACAEADQAFAEACAGQABAGAAAHIAAA1IASAAIAAALg");
	this.shape_102.setTransform(50.8,-92.3);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgrBFIAAgLIAmAAIAAhEIggAAIAAgMIArAAIAABQIAmAAIAAALgAgIgqIAAgaIAOAAIAAAag");
	this.shape_103.setTransform(37.5,-94.5);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AALBCIAAgLIAMAAIgNgOIgMgNIgLgKIgNAJIAAAnIgeAAIAAgLIASAAIAAhtIgSAAIAAgMIAeAAIAABRIAlgcIgKAAIAAgMIAvAAIAAAMIgVAAIggAZIAPAPIANANIANAPIAVAAIAAALg");
	this.shape_104.setTransform(24.3,-94.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AglAsQgIgEgDgGQgFgHAAgHQABgGAEgIQAFgGAJgFQALgFARAAIAPABIAPACIAAgHQAAgFgBgFQgCgFgEgCQgFgDgFgBQgFgBgFAAIgPACIgMADIgKAEIgDgMIAVgGQAKgDAMAAQAMAAAIAEQAJAEADAHIADAJIABAIIAAAzIARAAIAAALIgcAAIAAgSQgKAJgKAGQgLAGgMAAQgLAAgIgFgAgSACQgJABgGAEQgDACgCAEQgCADAAAEQAAAEADAEQACAEAGADQAFACAGAAQANAAAKgGQALgHAIgKIAAgKIgOgCIgMgBIgQABg");
	this.shape_105.setTransform(11,-92.2);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgcAqQgLgHgGgLQgFgLAAgNQAAgOAHgLQAHgLAMgGQALgGAOAAQARAAALAHQALAHAFAMQAFALAAANIhYAAIAAABQAAAJAFAIQAEAHAGAEQAGAEAHABIAOABQAIAAALgDQAMgDANgHIADALQgKAGgNAEQgNAEgNAAQgSAAgMgHgAAlgJIgBgHQgCgEgEgFQgEgEgHgEQgHgDgLAAQgMAAgIAEQgIAEgFAGQgEAGgBAHIBKAAIAAAAg");
	this.shape_106.setTransform(-2.4,-92.2);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("Ag0AvIAAgLIAbAAIAAhEIgbAAIAAgMIAmAAIAAAZIAOgNQAHgGAIgEQAIgFALABQAFAAAEABQAEABACAEIADAGIACAHIgMABQgBgGgDgCQgEgCgEABQgGAAgFACQgGADgIAGIgTASIAAAqIAqAAIAAALg");
	this.shape_107.setTransform(-15.2,-92.3);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgJBAQgIgDgFgEIgFgGIAAAOIgeAAIAAgLIASAAIAAhtIgSAAIAAgMIAeAAIAAA5QACgDAFgFQAFgEAIgDQAHgEALAAQALAAALAGQALAFAHALQAGAKABAQQAAAMgGALQgGALgKAHQgLAIgOAAQgMAAgIgEgAgHgNQgIAFgGAIQgFAHAAALQAAAOAGAIQAFAIAJAEQAHAEAJAAQAJAAAIgFQAJgEAFgJQAFgIAAgLQAAgJgEgIQgEgIgIgFQgIgGgMAAQgJAAgIAEg");
	this.shape_108.setTransform(-29.1,-94.1);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgiAGIAAgLIBFAAIAAALg");
	this.shape_109.setTransform(249.5,-120.6);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AALBDIAAgMIAMAAIgNgOIgMgNIgLgKIgNAIIAAApIgeAAIAAgMIASAAIAAhtIgSAAIAAgMIAeAAIAABRIAlgcIgKAAIAAgMIAvAAIAAAMIgVAAIggAZIAPAOIANAOIANAPIAVAAIAAAMg");
	this.shape_110.setTransform(236.4,-121.9);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgXArQgLgGgHgLQgHgLgBgPQAAgIADgIQADgIAGgHQAHgIAKgEQAKgFANAAQAJAAAIADQAIACAIAFIAAgKIAMAAIAAAlIgMAAIAAgOQgHgGgJgDQgIgCgJAAQgMAAgJAFQgJAFgFAJQgFAIAAAJQAAAFACAGQACAHAFAGQAFAGAIADQAJAEALAAQAJAAAIgDQAIgDAGgEIAJgHIAFAMQgKAIgLAEQgMAFgPAAQgNAAgMgGg");
	this.shape_111.setTransform(223,-119.9);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AglAsQgIgEgEgGQgDgHAAgHQgBgGAFgIQAEgGALgFQAKgFASAAIAOABIAPACIAAgHQAAgFgCgFQgBgFgEgCQgFgDgFgBQgGgBgEAAIgOACIgOADIgJAEIgDgMIAUgGQALgDALAAQANAAAJAEQAIAEADAHIAEAJIAAAIIAAAzIASAAIAAALIgeAAIAAgSQgIAJgMAGQgKAGgMAAQgLAAgIgFgAgTACQgIABgFAEQgEACgCAEQgCADAAAEQAAAEACAEQAEAEAEADQAGACAHAAQANAAAJgGQALgHAIgKIAAgKIgNgCIgOgBIgQABg");
	this.shape_112.setTransform(209.8,-119.9);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgJBAQgIgDgFgEIgFgGIAAAOIgeAAIAAgLIASAAIAAhtIgSAAIAAgMIAeAAIAAA5QACgDAFgFQAFgEAIgDQAHgEALAAQALAAALAGQALAFAHALQAGAKABAQQAAAMgGALQgGALgKAHQgLAIgOAAQgMAAgIgEgAgHgNQgIAFgGAIQgFAHAAALQAAAOAGAIQAFAIAJAEQAHAEAJAAQAJAAAIgFQAJgEAFgJQAFgIAAgLQAAgJgEgIQgEgIgIgFQgIgGgMAAQgJAAgIAEg");
	this.shape_113.setTransform(196.2,-121.8);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AgQAuQgJgDgIgEIAAAKIgMAAIAAgkIAMAAIAAAMQAIAGAJADQAJADAJAAIAIAAIALgDQAGgBADgEQAEgDAAgGIAAgDIgBgDQgDgEgFgCQgEgBgFAAIgKgBIgPgBQgIAAgIgDQgGgCgGgEQgEgCgBgEIgBgIQAAgOAKgIQAMgIARAAQAIAAAJACQAJACAHAFIAAgJIALAAIAAAiIgLAAIAAgNQgHgEgJgDQgIgCgIAAIgIAAIgJADIgIAFQgDADgBAFQAAADACACIAEAFQAFADAIABQAHABAIAAIAQABQAIABAGACQAGABAEAFQAEAFAAAIQAAAKgGAGQgEAHgKAEQgJAEgNAAQgLAAgJgDg");
	this.shape_114.setTransform(170.1,-119.9);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgQAuQgJgDgIgEIAAAKIgMAAIAAgkIAMAAIAAAMQAIAGAJADQAJADAJAAIAJAAIAKgDQAFgBAEgEQAEgDAAgGIgBgDIgBgDQgDgEgEgCQgEgBgGAAIgKgBIgOgBQgJAAgGgDQgIgCgGgEQgCgCgCgEIgBgIQAAgOAKgIQAMgIARAAQAJAAAIACQAIACAIAFIAAgJIALAAIAAAiIgLAAIAAgNQgHgEgJgDQgIgCgIAAIgJAAIgJADIgIAFQgCADgBAFQABADABACIAFAFQAEADAIABQAHABAIAAIAQABQAHABAHACQAGABAEAFQADAFABAIQAAAKgGAGQgEAHgKAEQgKAEgMAAQgLAAgJgDg");
	this.shape_115.setTransform(156.8,-119.9);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AgcAqQgLgHgGgLQgFgLAAgNQAAgOAHgLQAHgLAMgGQALgGAOAAQARAAALAHQALAHAFAMQAFALAAANIhYAAIAAABQAAAJAFAIQAEAHAGAEQAGAEAHABIAOABQAIAAALgDQAMgDANgHIADALQgKAGgNAEQgNAEgNAAQgSAAgMgHgAAlgJIgBgHQgCgEgEgFQgEgEgHgEQgHgDgLAAQgMAAgIAEQgIAEgFAGQgEAGgBAHIBKAAIAAAAg");
	this.shape_116.setTransform(143.4,-119.9);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AgrBDIAAgMIAmAAIAAhtIglAAIAAgMIAwAAIAAB5IAmAAIAAAMg");
	this.shape_117.setTransform(130.2,-121.9);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgjA9QgLgHgFgLQgGgMAAgMQAAgOAGgKQAHgLALgGQALgHAOAAQAIAAAKADQAKAEAIAKIAAgrIgcAAIAAgMIAoAAIAAB5IASAAIAAALIgeAAIAAgQQgGAJgKAFQgKAFgKAAQgQAAgLgHgAgbgMQgIAFgFAIQgFAIAAAKQAAAJAEAJQAFAIAIAGQAIAFAMAAQAKAAAIgFQAIgFAFgIQAEgJAAgLIgBgMQgCgGgEgFQgEgFgHgEQgHgDgKAAQgLAAgIAFg");
	this.shape_118.setTransform(117.3,-121.8);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AAMAwIAAgMIASAAIAAg1QgBgHgDgFQgEgDgFgBIgJgCQgJAAgKAFQgKAFgHAIIAAA1IASAAIAAAMIgwAAIAAgMIASAAIAAhEIgSAAIAAgMIAeAAIAAANQAIgHAKgEQAKgFAMAAQAHAAAFACQAFACAEADQAFAEACAGQABAGAAAHIAAA1IASAAIAAAMg");
	this.shape_119.setTransform(103.8,-120);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AgcAqQgLgHgGgLQgFgLAAgNQAAgOAHgLQAHgLAMgGQALgGAOAAQARAAALAHQALAHAFAMQAFALAAANIhYAAIAAABQAAAJAFAIQAEAHAGAEQAGAEAHABIAOABQAIAAALgDQAMgDANgHIADALQgKAGgNAEQgNAEgNAAQgSAAgMgHgAAlgJIgBgHQgCgEgEgFQgEgEgHgEQgHgDgLAAQgMAAgIAEQgIAEgFAGQgEAGgBAHIBKAAIAAAAg");
	this.shape_120.setTransform(90.4,-119.9);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AgsBDIAAgMIAWAAIAAhEIgWAAIAAgMIAWAAIAAgLIAAgGIABgGQACgGAEgEQAFgEAFgCIAKgCIAJAAIAKABIAMABIAKABIgEAMIgNgCIgPgBQgMAAgEADQgGACAAAEQgCAEABAFIAAALIAtAAIAAAMIgtAAIAABEIAtAAIAAAMg");
	this.shape_121.setTransform(64.1,-121.9);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AgbArQgNgHgGgLQgHgLAAgOQAAgOAHgLQAIgLAMgGQAMgGAPAAQAPAAALAFQAKAFAGAIQAHAHACAJQACAIABAGQgBAOgGALQgHALgMAGQgLAHgRAAQgQAAgMgGgAgWgfQgJAFgFAJQgGAIAAAJQAAAJAGAIQAEAJAJAFQAKAGAOAAQAMAAAJgFQAKgEAFgJQAGgIAAgLIgCgJQgCgHgEgGQgFgGgJgEQgHgEgNAAQgNAAgKAFg");
	this.shape_122.setTransform(50.7,-119.9);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AgQAuQgJgDgIgEIAAAKIgMAAIAAgkIAMAAIAAAMQAIAGAJADQAJADAJAAIAIAAIALgDQAGgBADgEQAEgDAAgGIAAgDIgBgDQgDgEgFgCQgEgBgFAAIgKgBIgPgBQgIAAgIgDQgGgCgGgEQgEgCgBgEIgBgIQAAgOAKgIQAMgIARAAQAIAAAJACQAJACAHAFIAAgJIALAAIAAAiIgLAAIAAgNQgHgEgJgDQgIgCgIAAIgIAAIgJADIgIAFQgDADgBAFQAAADACACIAFAFQAEADAIABQAHABAIAAIAQABQAIABAGACQAGABAEAFQAEAFAAAIQAAAKgGAGQgEAHgKAEQgJAEgNAAQgLAAgJgDg");
	this.shape_123.setTransform(24.3,-119.9);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("Ag1AwIAAgMIAbAAIAAhEIgbAAIAAgMIAnAAIAAAZIAOgNQAHgGAIgEQAJgFAKAAQAFAAAEACQAEACADADIADAHIAAAFIgLACQgCgGgDgBQgDgCgEAAQgGAAgGADQgFACgIAHIgTARIAAAqIApAAIAAAMg");
	this.shape_124.setTransform(11.3,-120);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AgkAsQgIgEgFgGQgEgHAAgHQABgGAEgIQAEgGAKgFQALgFARAAIAPABIAPACIAAgHQABgFgDgFQgBgFgEgCQgEgDgGgBQgGgBgEAAIgOACIgOADIgJAEIgDgMIAUgGQALgDAMAAQAMAAAIAEQAJAEADAHIAEAJIAAAIIAAAzIASAAIAAALIgdAAIAAgSQgKAJgLAGQgJAGgNAAQgLAAgHgFgAgSACQgIABgHAEQgDACgCAEQgCADAAAEQAAAEADAEQACAEAGADQAEACAIAAQAMAAAKgGQALgHAIgKIAAgKIgOgCIgMgBIgQABg");
	this.shape_125.setTransform(-2.3,-119.9);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AgcAqQgLgHgGgLQgFgLAAgNQAAgOAHgLQAHgLAMgGQALgGAOAAQARAAALAHQALAHAFAMQAFALAAANIhYAAIAAABQAAAJAFAIQAEAHAGAEQAGAEAHABIAOABQAIAAALgDQAMgDANgHIADALQgKAGgNAEQgNAEgNAAQgSAAgMgHgAAlgJIgBgHQgCgEgEgFQgEgEgHgEQgHgDgLAAQgMAAgIAEQgIAEgFAGQgEAGgBAHIBKAAIAAAAg");
	this.shape_126.setTransform(-15.7,-119.9);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AgzBDIAAgMIAYAAIAVgjIgohKIgPAAIAAgMIAqAAIAAAMIgOAAIAhA/IAjg/IgMAAIAAgMIAnAAIAAAMIgOAAIg+BtIARAAIAAAMg");
	this.shape_127.setTransform(-28.8,-117.9);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("Ag0AvIAAgLIAbAAIAAhEIgbAAIAAgMIAnAAIAAAZIANgNQAHgGAIgEQAIgFALAAQAFAAAEACQAEABACAEIADAHIABAGIgLABQgBgGgDgBQgEgCgEAAQgFAAgGACQgGADgIAGIgSASIAAAqIApAAIAAALg");
	this.shape_128.setTransform(236.7,-147.8);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AgcAqQgLgHgGgLQgFgLAAgNQAAgOAHgLQAHgLAMgGQALgGAOAAQARAAALAHQALAHAFAMQAFALAAANIhYAAIAAABQAAAJAFAIQAEAHAGAEQAGAEAHABIAOABQAIAAALgDQAMgDANgHIADALQgKAGgNAEQgNAEgNAAQgSAAgMgHgAAlgJIgBgHQgCgEgEgFQgEgEgHgEQgHgDgLAAQgMAAgIAEQgIAEgFAGQgEAGgBAHIBKAAIAAAAg");
	this.shape_129.setTransform(223,-147.7);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AgHA8QgGgBgFgDQgGgDgDgFQgFgGAAgJIAAg2IgPAAIAAgMIAPAAIAAgbIAMAAIAAAbIA3AAIAAAMIg3AAIAAAxQAAAGACAEQABAFAFADIAJADIAHAAQAIAAAHgBIAPgGIANgEIABALIgWAJQgMADgMAAIgJgBg");
	this.shape_130.setTransform(209.6,-148.9);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AgtBCIAAgLIAXAAIAAhEIgXAAIAAgMIAXAAIAAgLIAAgGIABgGQACgHAEgDQAFgDAGgDIAJgCIAJAAIAKABIAMABIAKABIgEAMIgNgCIgPgBQgMAAgEADQgFACgCAEQgBAEAAAFIAAALIAuAAIAAAMIguAAIAABEIAuAAIAAALg");
	this.shape_131.setTransform(196.7,-149.7);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AAVA9IAAgMIAVAAIgKgYIg9AAIgKAYIAUAAIAAAMIguAAIAAgMIAOAAIAnhhIgeAAIAAgMIA0AAIAtBtIALAAIAAAMgAAcANIgbhBIgZBBIA0AAg");
	this.shape_132.setTransform(183.2,-149.2);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgKA6QgEgEAAgEQAAgFAEgEQAEgEAGgBQAGABAEAEQAEADABAFQAAAGgFAEQgEADgGAAQgGAAgEgEgAgEAVIgEhSIAQAAIgDBSg");
	this.shape_133.setTransform(156.9,-149);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AgzBDIAAgMIAYAAIAVgjIgohKIgPAAIAAgMIAqAAIAAAMIgOAAIAhA/IAjg/IgMAAIAAgMIAnAAIAAAMIgOAAIg+BtIARAAIAAAMg");
	this.shape_134.setTransform(143.6,-145.7);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgrBCIAAgLIAmAAIAAhtIglAAIAAgMIAwAAIAAB5IAmAAIAAALg");
	this.shape_135.setTransform(130.2,-149.7);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AgrBCIAAgLIAmAAIAAhtIglAAIAAgMIAwAAIAAB5IAmAAIAAALg");
	this.shape_136.setTransform(116.9,-149.7);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AglAsQgHgEgEgGQgFgHAAgHQAAgGAFgIQAFgGAJgFQALgFASAAIAOABIAPACIAAgHQAAgFgBgFQgCgFgEgCQgFgDgFgBQgFgBgFAAIgPACIgMADIgKAEIgDgMIAVgGQAKgDALAAQANAAAJAEQAIAEADAHIADAJIABAIIAAAzIARAAIAAALIgdAAIAAgSQgIAJgLAGQgKAGgNAAQgLAAgIgFgAgTACQgHABgGAEQgEACgCAEQgCADAAAEQAAAEADAEQADAEAFADQAFACAGAAQAOAAAJgGQALgHAIgKIAAgKIgOgCIgMgBIgRABg");
	this.shape_137.setTransform(103.8,-147.7);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AALAvIAAgLIASAAIAAg1QAAgHgDgFQgEgEgEAAIgKgCQgKAAgJAFQgKAFgHAIIAAA1IASAAIAAALIgwAAIAAgLIASAAIAAhEIgSAAIAAgMIAeAAIAAANQAIgHALgEQAJgFALAAQAIAAAGACQAEACAEADQAFAEABAGQACAGAAAHIAAA1IASAAIAAALg");
	this.shape_138.setTransform(90.5,-147.8);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AgrBFIAAgLIAmAAIAAhEIggAAIAAgMIArAAIAABQIAmAAIAAALgAgIgrIAAgZIAOAAIAAAZg");
	this.shape_139.setTransform(77.2,-150);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AgzA9IAAgMIARAAIAAhhIgRAAIAAgMIBnAAIAAApIgMAAIAAgdIg+AAIAAArIAiAAIAAgPIAMAAIAAApIgMAAIAAgPIgiAAIAAArIAbAAIAAAMg");
	this.shape_140.setTransform(64.2,-149.2);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AgKAIQgEgDAAgFQAAgFAEgDQAFgDAGgBQAGAAAEAEQAEAEAAAEQAAAFgEAEQgFADgFABQgGAAgFgFg");
	this.shape_141.setTransform(37.5,-144.1);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AgKAIQgEgDAAgFQAAgFAEgDQAFgDAFgBQAHAAAEAEQAEAEAAAEQAAAFgEAEQgFADgGABQgFAAgFgFg");
	this.shape_142.setTransform(24.2,-144.1);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AgKAIQgEgDAAgFQAAgFAEgDQAFgDAGgBQAGAAAEAEQAEAEAAAEQAAAFgEAEQgFADgFABQgGAAgFgFg");
	this.shape_143.setTransform(10.9,-144.1);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("AgQAuQgJgDgIgEIAAAKIgMAAIAAgkIAMAAIAAAMQAIAGAJADQAJADAJAAIAIAAIALgDQAGgBADgEQAEgDAAgGIAAgDIgBgDQgDgEgFgCQgEgBgFAAIgKgBIgPgBQgIAAgIgDQgGgCgGgEQgEgCgBgEIgBgIQAAgOAKgIQAMgIARAAQAIAAAJACQAJACAHAFIAAgJIALAAIAAAiIgLAAIAAgNQgHgEgJgDQgIgCgIAAIgIAAIgJADIgIAFQgDADgBAFQAAADACACIAEAFQAFADAIABQAHABAIAAIAQABQAIABAGACQAGABAEAFQADAFABAIQAAAKgGAGQgEAHgKAEQgJAEgNAAQgLAAgJgDg");
	this.shape_144.setTransform(-2.3,-147.7);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AgcAqQgLgHgGgLQgFgLAAgNQAAgOAHgLQAHgLAMgGQALgGAOAAQARAAALAHQALAHAFAMQAFALAAANIhYAAIAAABQAAAJAFAIQAEAHAGAEQAGAEAHABIAOABQAIAAALgDQAMgDANgHIADALQgKAGgNAEQgNAEgNAAQgSAAgMgHgAAlgJIgBgHQgCgEgEgFQgEgEgHgEQgHgDgLAAQgMAAgIAEQgIAEgFAGQgEAGgBAHIBKAAIAAAAg");
	this.shape_145.setTransform(-15.7,-147.7);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFFFFF").s().p("AgfA9IAAgMIAbAAIAAgjIgng+IgPAAIAAgMIAsAAIAAAMIgQAAIAfAyIAegyIgPAAIAAgMIAqAAIAAAMIgOAAIgmA+IAAAjIAbAAIAAAMg");
	this.shape_146.setTransform(-28.8,-149.2);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#CACAFF").s().p("AgQAUQgHgJAAgLQAAgLAHgHQAHgIAJAAQAKAAAHAIQAHAHAAALQAAALgHAJQgHAHgKABQgJgBgHgHg");
	this.shape_147.setTransform(-337.5,75.4,1.275,1.251);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#CACAFF").s().p("AgQAUQgHgJAAgLQAAgLAHgHQAHgIAJAAQAKAAAHAIQAHAHAAALQAAALgHAJQgHAHgKABQgJgBgHgHg");
	this.shape_148.setTransform(-337.5,58.6,1.275,1.251);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#CACAFF").s().p("AgQAUQgHgIAAgMQAAgKAHgJQAHgIAJAAQAKAAAHAIQAHAJAAAKQAAALgHAJQgHAIgKAAQgJAAgHgIg");
	this.shape_149.setTransform(-337.5,26.8,1.275,1.251);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#CACAFF").s().p("AgQAUQgHgJAAgLQAAgLAHgIQAHgIAJAAQAKAAAHAIQAHAJAAAKQAAALgHAJQgHAIgKAAQgJAAgHgIg");
	this.shape_150.setTransform(-337.5,9.9,1.275,1.251);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#CACAFF").s().p("AgQATQgHgIAAgLQAAgLAHgHQAHgJAJAAQAKAAAHAJQAHAHAAALQAAALgHAIQgHAJgKgBQgJABgHgJg");
	this.shape_151.setTransform(-337.5,-26.6,1.275,1.251);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("rgba(49,49,255,0.898)").s().p("AgxLKIAA2TIBjiGIAAafg");
	this.shape_152.setTransform(-337.5,9.9,1.275,1.251);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("rgba(49,49,255,0.898)").s().p("AgzWXMAAAgstIBnkNMAAAA1Hg");
	this.shape_153.setTransform(-324.9,-38.9,1.275,1.251);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f().s("#CCCCCC").p("EAnEAakMhPtAAAMAAAg1HMBPtAAAQAqAAAeAeQAeAeAAAqMAAAAx7QAAAqgeAeQgeAegqAAg");
	this.shape_154.setTransform(12.2,-38.9,1.275,1.251);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("rgba(14,0,63,0.867)").s().p("EgopAakMAAAg1HMBPtAAAQAqAAAeAeQAeAeAAArMAAAAx6QAAAqgeAeQgeAegqAAg");
	this.shape_155.setTransform(12.2,-38.9,1.275,1.251);

	this.evil_button = new lib.EvilButton();
	this.evil_button.name = "evil_button";
	this.evil_button.parent = this;
	this.evil_button.setTransform(2.7,225.7,1,1,0,0,0,-3.6,0);
	new cjs.ButtonHelper(this.evil_button, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.evil_button},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Evil, new cjs.Rectangle(-343.8,-252.6,688.7,505.7), null);


// stage content:
(lib.earthquakemachine = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var frame_rate = 1/24;
		var _this = this;
		
		
		var main_loop = function(){
			var x1 = _this.taipei.wall.x;
			var x2 = _this.taipei.blocks[7].x;
			_this.graph.data1.push(x1);
			_this.graph.data1.shift(x1);
			_this.graph.data2.push(x2);
			_this.graph.data2.shift(x2);
			
			_this.amp.text = parseInt(x2);
			if (parseInt((x2))>20){
				crash();}
			
		};
		
		interval = setInterval( main_loop, frame_rate * 1000);
		
		
		
		function crash() {
			createjs.Tween.get(_this.cloud1).to({alpha: 1}, 500, createjs.Ease.quadOut)
			.to({alpha: 0}, 3000, createjs.Ease.quadOut);
			createjs.Tween.get(_this.cloud1).to({x: -100}, 8000, createjs.Ease.quadOut);
			
			createjs.Tween.get(_this.cloud2).to({alpha: 1}, 500, createjs.Ease.quadOut)
			.to({alpha: 0}, 2000, createjs.Ease.quadOut);
			createjs.Tween.get(_this.cloud2).to({x: 1600}, 8000, createjs.Ease.quadOut);
			
			createjs.Tween.get(_this.cloud3).to({alpha: 1}, 500, createjs.Ease.quadOut)
			.to({alpha: 0}, 3000, createjs.Ease.quadOut);
			createjs.Tween.get(_this.cloud3).to({x: -100}, 8000, createjs.Ease.quadOut);
			
			createjs.Tween.get(_this.cloud4).to({alpha: 1}, 500, createjs.Ease.quadOut)
			.to({alpha: 0}, 2000, createjs.Ease.quadOut);
			createjs.Tween.get(_this.cloud4).to({x: 1600}, 8000, createjs.Ease.quadOut);
			
			createjs.Tween.get(_this.cloud5).to({alpha: 1}, 500, createjs.Ease.quadOut)
			.to({alpha: 0}, 2000, createjs.Ease.quadOut);
			createjs.Tween.get(_this.cloud5).to({x: 1600}, 8000, createjs.Ease.quadOut);
			
			for (i = 0; i < _this.taipei.masses.length; i = i + 1) {
				var speed = _this.taipei.blocks[i].v * 2;
				createjs.Tween.get(_this.taipei.masses[i]).to({x:100*speed}, 4000, createjs.Ease.quadOut);
				createjs.Tween.get(_this.taipei.masses[i]).to({y:800}, 4000, createjs.Ease.bounceOut);
				createjs.Tween.get(_this.taipei.masses[i]).to({rotation:800*speed}, 4000, createjs.Ease.bounceOut);
				}
			createjs.Tween.get(_this.evil).wait(300)
				.to({visible:true}, 1000, createjs.Ease.linear);
		/*	_this.amp.visible = false;
			_this.displacement_label.visible = false;*/
			clearInterval(interval);
			}
		var _this = this;
		
		this.m_up.addEventListener("click", m_up_click.bind(this));
		this.m_down.addEventListener("click", m_down_click.bind(this));
		this.f_up.addEventListener("click", f_up_click.bind(this));
		this.f_down.addEventListener("click", f_down_click.bind(this));
		
		function m_up_click() {
			if (parseFloat(_this.damper_mass.text) < 1000) {
				_this.damper_mass.text = parseFloat(_this.damper_mass.text) + 50;
				_this.taipei.blocks[7].mass = parseFloat(_this.damper_mass.text);
			}
			reset();
		}
		
		function m_down_click() {
			if (parseFloat(_this.damper_mass.text) > 0) {
				_this.damper_mass.text = parseFloat(_this.damper_mass.text) - 50;
				_this.taipei.blocks[7].mass = parseFloat(_this.damper_mass.text);
			}
			reset();
		}
		
		function f_up_click() {
			if (parseFloat(_this.frequency.text) < 10) {
				_this.frequency.text = (parseFloat(_this.frequency.text) + .1).toFixed(1);
				_this.taipei.frequency = parseFloat(_this.frequency.text).toFixed(1);
			}
			reset();
		}
		
		function f_down_click() {
			if (parseFloat(_this.frequency.text) > 0) {
				_this.frequency.text = (parseFloat(_this.frequency.text) - .1).toFixed(1);
				_this.taipei.frequency = parseFloat(_this.frequency.text).toFixed(1);
			}
			reset();
		}
		
		
		
		reset = function(){
			_this.taipei.wall.t = 0;
			for (i = 0; i < 8; i = i + 1){
				_this.taipei.blocks[i].x = 0;
				_this.taipei.blocks[i].v = 0;}
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Actions
	this.text = new cjs.Text("", "23px 'MSReferenceSansSerif'", "#00FF00");
	this.text.textAlign = "center";
	this.text.lineHeight = 29;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(-468.7,-77.1);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	// Evil
	this.evil = new lib.Evil();
	this.evil.name = "evil";
	this.evil.parent = this;
	this.evil.setTransform(673.4,432.4,1,1,0,0,0,0.3,0.5);
	this.evil.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.evil).wait(1));

	// Text
	this.displacement_label = new cjs.Text("meters displaced", "13px 'Myriad CAD'", "#FF3300");
	this.displacement_label.name = "displacement_label";
	this.displacement_label.textAlign = "center";
	this.displacement_label.lineHeight = 35;
	this.displacement_label.lineWidth = 135;
	this.displacement_label.parent = this;
	this.displacement_label.setTransform(965.5,160.5);

	this.amp = new cjs.Text("0", "38px 'Myriad CAD'", "#FF3300");
	this.amp.name = "amp";
	this.amp.textAlign = "center";
	this.amp.lineHeight = 98;
	this.amp.lineWidth = 135;
	this.amp.parent = this;
	this.amp.setTransform(965.5,203.4);

	this.frequency = new cjs.Text("0", "23px 'MS Reference Sans Serif'", "#00FF00");
	this.frequency.name = "frequency";
	this.frequency.textAlign = "center";
	this.frequency.lineHeight = 29;
	this.frequency.lineWidth = 51;
	this.frequency.parent = this;
	this.frequency.setTransform(949.2,585.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FF00").s().p("AgiAsIAAgLIAxg/IgwAAIAAgNIBDAAIAAALIgyA/IAzAAIAAANg");
	this.shape.setTransform(995.5,603.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00FF00").s().p("AAdA6IAAg5Ig5AAIAAA5IgPAAIAAhzIAPAAIAAAuIA5AAIAAguIAQAAIAABzg");
	this.shape_1.setTransform(985.3,601.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00FF00").s().p("AgPA8IgNgCIAAgPIABAAIALADQAIACAIAAQAGAAAFgCQAFgBADgEQACgDACgEIABgKIAAgIQgHAGgGACQgGADgIAAQgQAAgJgLQgJgMAAgTQAAgLADgJQADgIAFgGQAGgFAHgDQAHgDAGAAQAIAAAFABIALAFIABgEIANAAIAABMQAAAXgKAKQgKAKgUAAIgNgBgAgPgnQgHAIAAAPQAAAPAFAHQAFAHAMAAQAGAAAGgCQAGgDAGgEIAAguIgLgEIgKgBQgLAAgHAIg");
	this.shape_2.setTransform(456.3,345.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00FF00").s().p("AAlA6IAAhjIghBDIgIAAIgghDIAABjIgPAAIAAhzIAVAAIAeBAIAehAIAWAAIAABzg");
	this.shape_3.setTransform(444.9,342.8);

	this.damper_mass = new cjs.Text("0", "23px 'MS Reference Sans Serif'", "#00FF00");
	this.damper_mass.name = "damper_mass";
	this.damper_mass.textAlign = "center";
	this.damper_mass.lineHeight = 29;
	this.damper_mass.lineWidth = 51;
	this.damper_mass.parent = this;
	this.damper_mass.setTransform(399.6,328.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.damper_mass},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.frequency},{t:this.amp},{t:this.displacement_label}]}).wait(1));

	// Buttons
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#666666").s().p("AgRAnQgKgGgFgJQgFgKAAgMQAAgOAGgKQAFgKAJgGQAJgFALAAQALAAAGAEQAHAEAEAGQAEAGACAGIABALIAAADIAAADIhFAAQABAMAEAJQAFAJAIAEQAJAEAJAAIAMAAIAIgCIAGgDIACAFIgGADIgJACIgOABQgMAAgJgFgAAggGIgCgJQgBgFgDgFQgDgFgGgEQgFgDgKAAQgKAAgHAFQgHAEgDAIQgEAHgBAHIA+AAIAAAAg");
	this.shape_4.setTransform(1048.1,360.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#666666").s().p("AAdArIAAgvQAAgJgDgHQgCgHgGgFQgGgEgKAAQgGAAgGADQgFACgFAFQgEAFgCAFIgBAEIAAAEIAAAzIgIAAIAAhAIAAgJIAAgKIAHAAIAAARIABAAQADgIAJgGQAIgFAKAAIAIABQAGABAGAEQAFADAEAIQADAIABANIAAAvg");
	this.shape_5.setTransform(1037.9,360.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#666666").s().p("AgCA6IAAhUIAFAAIAABUgAgEguQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAgDABgCQABAAABgBQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAABABAAQAAABAAAAQACACAAADQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAgBAAQAAAAgBgBQAAAAgBgBg");
	this.shape_6.setTransform(1030.4,359.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#666666").s().p("AAdA/IAAgxQAAgIgDgGQgCgHgGgFQgGgFgKABQgGAAgGACQgGADgEAFQgEAFgCAEIgCAFIAAAEIAAAzIgHAAIAAh9IAHAAIAAA7QACgEAEgEQADgEAEgCIAJgEIAJgCIAJABQAFABAFAFQAGADAEAHQADAIABAMIAAAxg");
	this.shape_7.setTransform(1022.9,358.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#666666").s().p("AgOAnQgKgGgFgJQgGgKAAgNQAAgNAGgKQAHgKAKgGQALgFAMAAIAQACQAGACADACIgDAGQgEgDgFgBQgGgCgIAAQgMAAgJAFQgJAFgEAJQgEAJAAAJQAAAMAFAIQAEAJAJAFQAIAEAKAAQAJAAAGgBIAKgEIACAFIgGADIgJACIgNABQgMAAgJgFg");
	this.shape_8.setTransform(1012.6,360.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#666666").s().p("AgcApQgGgFgCgEQgDgGAAgFQAAgKAGgGQAGgGANgEQAMgDAUAAIACAAIAAgCIAAgHQgBgFgCgFQgDgEgFgEQgFgDgJAAQgGAAgHACQgHACgFAEIgDgFQAIgFAIgCIAMgCQALAAAHAFQAGADADAHQADAGABAGIABAKIAAAcQAAAJACAEQACACAEAAIACAAIADAAIAAAFIgDABIgDAAQgGAAgEgDQgDgEAAgHIgHAHQgFAEgGADQgGACgJAAQgKAAgGgDgAAAgCIgQADQgHADgFAEQgEAFAAAHQAAAGADAEQADAEAEACQAFACAFAAQAJAAAGgCQAGgEAEgEQAEgDACgFIABgCIAAgCIAAgSIgDAAIgGgBIgLABg");
	this.shape_9.setTransform(1002.5,361);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#666666").s().p("AAuA5IgDg3IgCgRIAAgSIgBgOIAAAAIgHATIgIAXIgYA+IgDAAIgWg9IgIgYIgGgTIgBAAIAAAPIgBASIgBASIgEA1IgGAAIAIhxIAHAAIAYBCIAHAUIAFARIAFgRIAHgUIAZhCIAIAAIAHBxg");
	this.shape_10.setTransform(990.2,359.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#666666").s().p("AgRAnQgKgGgFgJQgFgKAAgMQAAgOAGgKQAFgKAJgGQAJgFALAAQALAAAGAEQAHAEAEAGQAEAGACAGIABALIAAADIAAADIhFAAQABAMAEAJQAFAJAIAEQAJAEAJAAIAMAAIAIgCIAGgDIACAFIgGADIgJACIgOABQgMAAgJgFgAAggGIgCgJQgBgFgDgFQgDgFgGgEQgFgDgKAAQgKAAgHAFQgHAEgDAIQgEAHgBAHIA+AAIAAAAg");
	this.shape_11.setTransform(967.9,360.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#666666").s().p("AAaA/IgqguIgLAKIAAAkIgHAAIAAh9IAHAAIAABSIAAAAIAEgEIAHgGIAkgfIAJAAIgoAiIAuAyg");
	this.shape_12.setTransform(958.8,358.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#666666").s().p("AgcApQgGgFgCgEQgDgGAAgFQAAgKAGgGQAGgGANgEQAMgDAUAAIACAAIAAgCIAAgHQgBgFgCgFQgDgEgFgEQgFgDgJAAQgGAAgHACQgHACgFAEIgDgFQAIgFAIgCIAMgCQALAAAHAFQAGADADAHQADAGABAGIABAKIAAAcQAAAJACAEQACACAEAAIACAAIADAAIAAAFIgDABIgDAAQgGAAgEgDQgDgEAAgHIgHAHQgFAEgGADQgGACgJAAQgKAAgGgDgAAAgCIgQADQgHADgFAEQgEAFAAAHQAAAGADAEQADAEAEACQAFACAFAAQAJAAAGgCQAGgEAEgEQAEgDACgFIABgCIAAgCIAAgSIgDAAIgGgBIgLABg");
	this.shape_13.setTransform(948.5,361);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#666666").s().p("AgMAqQgFgBgFgEQgFgDgEgIQgDgIAAgOIAAguIAGAAIAAAtQAAAKADAIQACAIAGAEQAGAEAJAAQAGAAAGgCQAFgDAEgEQAFgEACgFIACgFIAAgFIAAgzIAHAAIAABAIAAAJIAAAKIgGAAIAAgRQgDAFgFAEQgEAFgGADQgHACgHAAIgJgBg");
	this.shape_14.setTransform(937.6,361);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#666666").s().p("AAhA9IAAg0QgDAFgEAEQgFAEgGADQgHADgIAAQgMAAgIgGQgJgGgFgJQgFgJAAgMQAAgMAEgJQADgJAHgFQAGgGAHgCQAIgDAGAAQAJABAGACQAHADAEAEQAEAEABAEIABAAIAAgQIAGAAIAAAKIgBALIAABigAgQgxQgIAFgEAIQgFAJAAANQAAAJAEAIQADAIAIAGQAHAFALAAQALAAAIgFQAIgGAEgKIABgDIABgEIAAgSIAAgFIgBgEQgCgGgEgEQgEgFgHgDQgGgDgIAAQgJAAgIAFg");
	this.shape_15.setTransform(926.7,362.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#666666").s().p("AAdA/IAAgxQAAgIgDgGQgCgHgGgFQgGgFgKABQgGAAgGACQgGADgEAFQgEAFgCAEIgCAFIAAAEIAAAzIgHAAIAAh9IAHAAIAAA7QACgEAEgEQADgEAEgCIAJgEIAJgCIAJABQAFABAFAFQAGADAEAHQADAIABAMIAAAxg");
	this.shape_16.setTransform(916.4,358.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#666666").s().p("AgBAyQgFgEgCgGQgCgGAAgJIAAg0IgRAAIAAgFIARAAIAAgTIAHgCIAAAVIAcAAIAAAFIgcAAIAAA2QAAAMADAEQAFAGAHgBIAHgBIAHgDIACAFIgJAEIgIABQgIAAgEgEg");
	this.shape_17.setTransform(907.3,360);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#666666").s().p("AgYArIAAg2IAAgOIAAgPIAFAAIAAAdIABAAQAEgQAKgIQAHgHANAAIAFAAIAEABIgBAGIgEgBIgFAAQgHAAgGADQgGAEgFAIQgFAIgDANIAAADIgBAGIAAAFIAAAdg");
	this.shape_18.setTransform(900.4,360.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#666666").s().p("AgcApQgGgFgCgEQgDgGAAgFQAAgKAGgGQAGgGANgEQAMgDAUAAIACAAIAAgCIAAgHQgBgFgCgFQgDgEgFgEQgFgDgJAAQgGAAgHACQgHACgFAEIgDgFQAIgFAIgCIAMgCQALAAAHAFQAGADADAHQADAGABAGIABAKIAAAcQAAAJACAEQACACAEAAIACAAIADAAIAAAFIgDABIgDAAQgGAAgEgDQgDgEAAgHIgHAHQgFAEgGADQgGACgJAAQgKAAgGgDgAAAgCIgQADQgHADgFAEQgEAFAAAHQAAAGADAEQADAEAEACQAFACAFAAQAJAAAGgCQAGgEAEgEQAEgDACgFIABgCIAAgCIAAgSIgDAAIgGgBIgLABg");
	this.shape_19.setTransform(891,361);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#666666").s().p("AgfA5IAAhxIA9AAIAAAGIg3AAIAAAtIA0AAIAAAFIg0AAIAAAzIA5AAIAAAGg");
	this.shape_20.setTransform(880.6,359.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#666666").s().p("AgQAqIgOgEIADgGIAHADIAJADIAKABQALAAAHgGQAHgFAAgHQAAgGgDgDQgDgDgFgDIgLgEIgFgBQgMgDgGgFQgGgFAAgIQAAgHAEgFQAEgFAHgEQAHgCAJAAIAIAAIAJACIAHADIgDAGIgFgCIgIgDIgLgBQgFAAgFADQgFACgDADQgDAEAAAFQAAAFADADQADADAFADIALADIAFACQALACAHAFQAGAGAAAJQAAAHgEAGQgFAFgHADQgHADgJABIgPgDg");
	this.shape_21.setTransform(470.4,167.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#666666").s().p("AgQAqIgOgEIADgGIAHADIAJADIAKABQALAAAHgGQAHgFAAgHQAAgGgDgDQgDgDgFgDIgLgEIgFgBQgMgDgGgFQgGgFAAgIQAAgHAEgFQAEgFAHgEQAHgCAJAAIAIAAIAJACIAHADIgDAGIgFgCIgIgDIgLgBQgFAAgFADQgFACgDADQgDAEAAAFQAAAFADADQADADAFADIALADIAFACQALACAHAFQAGAGAAAJQAAAHgEAGQgFAFgHADQgHADgJABIgPgDg");
	this.shape_22.setTransform(461,167.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#666666").s().p("AgcAoQgGgDgCgGQgDgFAAgFQAAgJAGgIQAGgFANgEQAMgEAUABIACAAIAAgDIAAgGQgBgEgCgFQgDgFgFgDQgFgEgJAAQgGAAgHACQgHACgFAEIgDgFQAIgFAIgCIAMgBQALAAAHADQAGAFADAFQADAGABAHIABAKIAAAcQAAAJACADQACAEAEAAIACAAIADgBIAAAFIgDABIgDAAQgGAAgEgDQgDgEAAgHIgHAHQgFAEgGACQgGADgJABQgKgBgGgEgAAAgCIgQADQgHADgFAEQgEAEAAAIQAAAGADAEQADAFAEACQAFABAFABQAJAAAGgDQAGgEAEgDQAEgEACgFIABgCIAAgDIAAgSIgDAAIgGAAIgLABg");
	this.shape_23.setTransform(451.2,167.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#666666").s().p("AAuA5IgDg3IgCgRIAAgSIgBgOIAAAAIgHATIgIAXIgYA+IgDAAIgWg9IgIgYIgGgTIgBAAIAAAPIgBASIgBASIgEA1IgGAAIAIhxIAHAAIAYBCIAHAUIAFARIAFgRIAHgUIAZhCIAIAAIAHBxg");
	this.shape_24.setTransform(438.9,165.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#666666").s().p("AgYArIAAg2IAAgOIAAgPIAGAAIAAAdIAAAAQAEgQAJgIQAJgHAMAAIAFAAIAFABIgCAGIgEgBIgFAAQgHAAgGADQgGAEgFAIQgEAIgDANIgBADIAAAGIAAAFIAAAdg");
	this.shape_25.setTransform(418.7,167);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#666666").s().p("AgRAnQgKgGgFgJQgFgKAAgMQAAgOAGgKQAFgKAJgGQAJgFALAAQALAAAGAEQAHAEAEAGQAEAGACAGIABALIAAADIAAADIhFAAQABAMAEAJQAFAJAIAEQAJAEAJAAIAMAAIAIgCIAGgDIACAFIgGADIgJACIgOABQgMAAgJgFgAAggGIgCgJQgBgFgDgFQgDgFgGgEQgFgDgKAAQgKAAgHAFQgHAEgDAIQgEAHgBAHIA+AAIAAAAg");
	this.shape_26.setTransform(409.4,167.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#666666").s().p("AgoA9IAAhcIAAgNIAAgOIAGAAIABASIAAAAQAFgJAJgFQAJgFALgBQANABAIAFQAKAGAFAKQAEAJAAAMQAAAPgFAJQgGAKgKAFQgJAGgLAAQgKAAgIgEQgJgFgGgJIAAAAIAAAzgAgMgzQgHACgFAGQgFAFgDAIIgBAEIAAADIAAAQIAAAEIABADQACAGAFAFQAEAFAGADQAIADAHAAQAKAAAJgFQAHgFAEgJQAFgIAAgMQAAgKgFgIQgDgJgIgFQgIgFgKAAQgHAAgGADg");
	this.shape_27.setTransform(399.5,168.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#666666").s().p("AA4ArIAAguQAAgRgHgIQgGgIgMAAQgHAAgFACQgFADgDAEQgEAEgCAEIgBAEIAAAFIAAA1IgGAAIAAgzQAAgIgDgHQgDgGgFgEQgGgDgHAAQgHAAgFADQgFADgEAEQgEAFgCAFIgBAEIgBAEIAAAzIgGAAIAAhAIAAgJIgBgKIAGAAIABARQAFgJAHgFQAIgFALAAQAGAAAGADQAFACAEAFQADAFABAFIAAAAIAFgHIAEgFQAEgEAFgCQAGgCAIAAIAIABQAEABAGAEQAEAEAEAIQAEAIgBANIAAAug");
	this.shape_28.setTransform(385.5,167);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#666666").s().p("AgcAoQgGgDgCgGQgDgFAAgFQAAgJAGgIQAGgFANgEQAMgEAUABIACAAIAAgDIAAgGQgBgEgCgFQgDgFgFgDQgFgEgJAAQgGAAgHACQgHACgFAEIgDgFQAIgFAIgCIAMgBQALAAAHADQAGAFADAFQADAGABAHIABAKIAAAcQAAAJACADQACAEAEAAIACAAIADgBIAAAFIgDABIgDAAQgGAAgEgDQgDgEAAgHIgHAHQgFAEgGACQgGADgJABQgKgBgGgEgAAAgCIgQADQgHADgFAEQgEAEAAAIQAAAGADAEQADAFAEACQAFABAFABQAJAAAGgDQAGgEAEgDQAEgEACgFIABgCIAAgDIAAgSIgDAAIgGAAIgLABg");
	this.shape_29.setTransform(372,167.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#666666").s().p("AggA5IgNAAIAAhvIAOgCIARgBQAPABANAEQAMAFAIAIQAGAIADAJQADAKAAAKQAAAJgDALQgDALgIAKQgIAJgNAEQgMAGgRgBIgOAAgAgdgyIgKABIAABjIAKABIALABQAUgBANgGQANgIAGgMQAGgMAAgPQAAgOgGgLQgGgLgMgGQgMgHgTAAIgOABg");
	this.shape_30.setTransform(361,165.7);

	this.m_down = new lib.mdown();
	this.m_down.name = "m_down";
	this.m_down.parent = this;
	this.m_down.setTransform(331.1,342,1,1,-90);
	new cjs.ButtonHelper(this.m_down, 0, 1, 2);

	this.m_up = new lib.mup();
	this.m_up.name = "m_up";
	this.m_up.parent = this;
	this.m_up.setTransform(509.8,372.1,1,1,90,0,0,30.1,0);
	new cjs.ButtonHelper(this.m_up, 0, 1, 2);

	this.f_down = new lib.fdown();
	this.f_down.name = "f_down";
	this.f_down.parent = this;
	this.f_down.setTransform(887.3,717.5,1,1,-90);
	new cjs.ButtonHelper(this.f_down, 0, 1, 2);

	this.f_up = new lib.fup();
	this.f_up.name = "f_up";
	this.f_up.parent = this;
	this.f_up.setTransform(1036.9,717.9,1,1,90,0,0,0,3);
	new cjs.ButtonHelper(this.f_up, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.f_up},{t:this.f_down},{t:this.m_up},{t:this.m_down},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4}]}).wait(1));

	// Wave_clip (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EBFtAppQhYhXAAh8QAAh8BYhXQBXhYB8AAQB8AABXBYQBXBXAAB8QAAB8hXBXQhXBXh8AAQh8AAhXhXg");
	mask.setTransform(497,275.2);

	// Wave
	this.graph = new lib.graph();
	this.graph.name = "graph";
	this.graph.parent = this;
	this.graph.setTransform(964.3,520.7);

	var maskedShapeInstanceList = [this.graph];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.graph).wait(1));

	// Machine
	this.instance = new lib.lights();
	this.instance.parent = this;
	this.instance.setTransform(1031.5,588.7);

	this.instance_1 = new lib.pistons();
	this.instance_1.parent = this;
	this.instance_1.setTransform(962.2,660.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FF6161").s().p("AmKDeIAAiyQAAhtBChOQBBhOBdAAIFUAAQBdAABCBOQBCBOAABtIAACyg");
	this.shape_31.setTransform(1036.5,717.8,1,1.044);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FF6161").s().p("AmKDeIAAiyQAAhtBChOQBBhOBeAAIFTAAQBdAABCBOQBCBOAABtIAACyg");
	this.shape_32.setTransform(887.5,717.8,1,1.044);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FF6161").s().p("AhbAVQgIAAgHgGQgGgGAAgJQAAgIAGgGQAHgGAIAAIC3AAQAIAAAHAGQAGAGAAAIQAAAJgGAGQgHAGgIAAg");
	this.shape_33.setTransform(1028.7,688.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FF6161").s().p("AhbAVQgIAAgHgGQgGgGAAgJQAAgIAGgGQAHgGAIAAIC3AAQAIAAAHAGQAGAGAAAIQAAAJgGAGQgHAGgIAAg");
	this.shape_34.setTransform(896.7,688.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#ACB7BC").s().p("ApTAPIAAgdISnAAIAAAdg");
	this.shape_35.setTransform(963.4,676.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#ACB7BC").s().p("ApTAPIAAgdISnAAIAAAdg");
	this.shape_36.setTransform(961.9,660.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#E8B979").ss(1,1,1).p("AJqAQIzTAAIAAgfITTAAg");
	this.shape_37.setTransform(962.8,644.2);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#ACB7BC").s().p("AppARIAAggITSAAIAAAgg");
	this.shape_38.setTransform(962.8,644.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#ACB7BC").s().p("AhbEvIAAgXQgBgWAOgTQAOgSAVgHIAZllQgZgGgRgXQgPgWAAgbQAAgiAWgYQAWgXAfAAQAgAAAWAXQAWAYABAiQAAAagQAWQgOAWgYAHIAYFnQAUAIAMARQANATAAAVIAAAXg");
	this.shape_39.setTransform(963.2,422.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("Ag9CgIAAk/IB8AAIAAE/g");
	this.shape_40.setTransform(1013.1,490.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AhBCgIAAk/ICDAAIAAE/g");
	this.shape_41.setTransform(913.6,490.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FFFFFF").ss(7).p("AFKAAQAACJhhBhQhgBgiJAAQiIAAhhhgQhhhhAAiJQAAiIBhhhQBhhhCIAAQCJAABgBhQBhBhAACIg");
	this.shape_42.setTransform(964.2,520.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#494949").s().p("AjoDqQhhhhgBiJQABiIBhhhQBghgCIgBQCJABBhBgQBhBhAACIQAACJhhBhQhhBhiJAAQiIAAhghhg");
	this.shape_43.setTransform(964.2,520.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FCCF19").s().p("AgTAQQgIgGAAgKQAAgIAIgHQAIgHALAAQALAAAJAHQAIAHAAAIQAAAKgIAGQgJAHgLAAQgLAAgIgHg");
	this.shape_44.setTransform(898.8,606.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FCCF19").s().p("AgTARQgIgHAAgKQAAgIAIgIQAIgGALgBQALABAJAGQAIAIAAAIQAAAJgIAIQgJAGgLABQgLgBgIgGg");
	this.shape_45.setTransform(898.8,598.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#C6C6C6").s().p("AgmAgQgMAAgIgJQgJgIAAgNIAAgDQAAgMAJgJQAIgJAMAAIBNAAQALAAAJAJQAJAJAAAMIAAADQAAANgJAIQgJAJgLAAg");
	this.shape_46.setTransform(899.6,624.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#C6C6C6").s().p("AgUAgQgMAAgJgJQgJgJAAgMIAAgDQAAgMAJgJQAJgJAMAAIApAAQAMAAAJAJQAJAJAAAMIAAADQAAAMgJAJQgJAJgMAAg");
	this.shape_47.setTransform(898.9,586.2);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#C6C6C6").s().p("AglAhQgMAAgKgJQgJgJAAgNIAAgDQAAgNAJgJQAKgJAMAAIBLAAQANAAAJAJQAJAJAAANIAAADQAAANgJAJQgJAJgNAAg");
	this.shape_48.setTransform(900.7,576.7);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#FFFFFF").ss(4,0,1).p("AIFDCIwJAAIAAmDIQJAAg");
	this.shape_49.setTransform(965.3,600.2);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#494949").s().p("AoEDCIAAmDIQJAAIAAGDg");
	this.shape_50.setTransform(965.3,600.2);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FF6161").s().p("ArzFXQgQAAgLgLQgLgLAAgQIAAphQAAgQALgLQALgLAQAAIXnAAQAQAAALALQALALAAAQIAAJhQAAAQgLALQgLALgQAAg");
	this.shape_51.setTransform(963.4,599.3);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#ACB7BC").ss(14,0,1).p("AAAk2IAAJt");
	this.shape_52.setTransform(1028.3,664.1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#ACB7BC").ss(14,0,1).p("AAAk6IAAJ0");
	this.shape_53.setTransform(897.1,664.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FF6161").s().p("Ap3IyQiYgBhthsQhthtAAiZIAAl9QAAiZBthtQBthtCYAAITuAAQCaAABsBtQBtBtAACZIAAF9QAACZhtBtQhsBsiaABg");
	this.shape_54.setTransform(963.2,508.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Clouds
	this.cloud5 = new lib.cloud5();
	this.cloud5.name = "cloud5";
	this.cloud5.parent = this;
	this.cloud5.setTransform(574.8,672.2);
	this.cloud5.alpha = 0;

	this.cloud4 = new lib.cloud4();
	this.cloud4.name = "cloud4";
	this.cloud4.parent = this;
	this.cloud4.setTransform(712.8,663.5);
	this.cloud4.alpha = 0;

	this.cloud3 = new lib.cloud3();
	this.cloud3.name = "cloud3";
	this.cloud3.parent = this;
	this.cloud3.setTransform(621.3,621.7);
	this.cloud3.alpha = 0;

	this.cloud2 = new lib.cloud2();
	this.cloud2.name = "cloud2";
	this.cloud2.parent = this;
	this.cloud2.setTransform(646.5,686.3);
	this.cloud2.alpha = 0;

	this.cloud1 = new lib.cloud1();
	this.cloud1.name = "cloud1";
	this.cloud1.parent = this;
	this.cloud1.setTransform(755.3,690.6);
	this.cloud1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.cloud1},{t:this.cloud2},{t:this.cloud3},{t:this.cloud4},{t:this.cloud5}]}).wait(1));

	// Taipei101
	this.taipei = new lib.taipei();
	this.taipei.name = "taipei";
	this.taipei.parent = this;
	this.taipei.setTransform(681,444.5);

	this.timeline.addTween(cjs.Tween.get(this.taipei).wait(1));

	// Damper
	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#FF931E").ss(4,0,1).p("AJoC9IzPAAIAAl5ITPAAg");
	this.shape_55.setTransform(420.3,343.5);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#494949").s().p("ApnC9IAAl5ITPAAIAAF5g");
	this.shape_56.setTransform(420.3,343.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FCCF19").s().p("AimAkQhGgPAAgVQAAgUBGgPQBGgPBgAAQBiAABFAPQBGAPAAAUQAAAVhGAPQhFAPhiAAQhhAAhFgPg");
	this.shape_57.setTransform(417.7,200.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#F7F24B").s().p("AimBRQhGgPAAgVIAAiMIHZAAIAACMQAAAVhGAPQhFAPhiAAQhgAAhGgPg");
	this.shape_58.setTransform(417.7,209.9);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FCCF19").s().p("AktBSQh8gjAAgvQAAgvB8ghQB9gjCwAAQCwAAB9AjQB9AhAAAvQAAAvh9AjQh9AhiwABQiwgBh9ghg");
	this.shape_59.setTransform(418.3,215);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#F7F24B").s().p("AksB5Qh9giAAgwIAAjBINTAAIAADBQAAAwh8AiQh9AhixAAQivAAh9ghg");
	this.shape_60.setTransform(418.3,230.2);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FCCF19").s().p("AmCB0QihgwAAhEQAAhDChgwQCggwDiAAQDjAACgAwQChAwgBBDQABBEihAwQigAwjjAAQjiAAiggwg");
	this.shape_61.setTransform(418.3,237);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#F7F24B").s().p("AmCCNQihgtAAhAIAAjZIRGAAIAADZQABBAihAtQigAtjjAAQjiAAiggtg");
	this.shape_62.setTransform(418.3,255.2);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FCCF19").s().p("AksB5Qh9giAAgwIAAjAINTAAIAADAQAAAwh8AiQh9AiixgBQivABh9gig");
	this.shape_63.setTransform(418.3,275.6);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#F9A91C").s().p("AimBRQhGgPAAgVIAAiMIHZAAIAACMQAAAVhGAPQhFAPhiAAQhhAAhFgPg");
	this.shape_64.setTransform(417.7,291.6);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#EFEFEF").s().p("AmeO2Qi/hOiTiPQiUiPhRi5QhTi/AAjSQAAjRBTi/QBRi5CUiPQCTiPC/hOQDHhRDXAAQDZAADFBRQDABOCTCPQCTCPBRC5QBUC/AADRQAADShUC/QhRC5iTCPQiTCPjABOQjFBRjZAAQjYAAjGhRg");
	this.shape_65.setTransform(416.5,231.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55}]}).wait(1));

	// BG Buildings
	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#3D3D3D").s().p("EhqjAH5IAAvxMDVHAAAIAAPxg");
	this.shape_66.setTransform(684,755,1.015,1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#C5EDFF").s().p("Am9HcIAAjmIA6AAIAAAnICIAAIAAhQIicAAIAAgHIABAAIAugGIBtgTIAAixIicAAIAAgHIABAAIAugHIBtgTIAAiyIjyAAIAAgUIAAAAIDEhNQDShcBChHIApAAQA9BHDVBcQBqAuBeAfIAAAUIj8AAIAACxQBYAQBNALIAAAHIilAAIAACvQBYARBNAKIAAAHIilAAIAABQIAeAAIAAC/g");
	this.shape_67.setTransform(999.5,663.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#C5EDFF").s().p("AB/EtIAAlsQhCg3hTAAQhUAAhDA4IgFAAIAAiPIExAAIAAgfIgHAAIAAgYIAIAAIADgQIgLAAIAAgIIAHAAIAAgQIAuAAIAAAQIAHAAIAAAIIgMAAIAEAQIAIAAIAAAYIgHAAIAAIZg");
	this.shape_68.setTransform(770.2,673.7);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#C5EDFF").s().p("AISF4IAAltQhDg1hTAAQg+AAg2AfIAAFbIg1AAIAAmEQhNg7hhAAQhSAAhFAsIAAF/Ig9AAIAAmiQhYhAhuAAQhvAAhZBAIgIAAIAAikIGWAAIAAgkIgIAAIAAgbIAKAAIAEgTIgOAAIAAgJIAIAAIAAgSIA9AAIAAASIAJAAIAAAJIgPAAIAEATIALAAIAAAbIgJAAIAABjIFFAAIAAgiIgIAAIAAgZIAKAAIADgRIgNAAIAAgJIAIAAIAAgRIA1AAIAAARIAIAAIAAAJIgNAAIADARIAKAAIAAAZIgIAAIAABrIEKAAIAAgfIgHAAIAAgYIAIAAIADgQIgLAAIAAgIIAHAAIAAgPIAtAAIAAAPIAHAAIAAAIIgLAAIADAQIAIAAIAAAYIgHAAIAAIZg");
	this.shape_69.setTransform(870.5,677.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#C5EDFF").s().p("AlXKvIAAo8IATAAIAAg8IAUAAIAAqoIAdAAIAAg9ID8AAIAAA9IDLAAIAAEYICkAAIAAQIg");
	this.shape_70.setTransform(800.2,635.1);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#C5EDFF").s().p("AjeIiIAAwHIAwAAIAAg8IFdAAIAAA8IAwAAIAAQHg");
	this.shape_71.setTransform(734.8,651.2);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#C5EDFF").s().p("Ao7IOIDAqyIglAAIAAgeIAnAAIAAgyIgnAAIAAgeIB1AAIA+gfIhSAAIAAgyIhEAAIAAgKIAKAAICdgtQCmg1AogjQgGgDgEgFQgEgEAAgEQAAgEAHgEQAHgDAKAAQAJAAAIADQAGAEABAEQAAAEgEAEQgEAFgGADQAoAjClA1QBTAaBKATIALAAIAAAKIg7AAIAAAyIhUAAIA9AfIBvAAIAAAeIgdAAIAAAyIAdAAIAAAeIgbAAIC/Kyg");
	this.shape_72.setTransform(648.5,663.2);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#C5EDFF").s().p("Ai8MTIAA2EIAdAAIAAgfIAdAAIAAgeIAnAAIAAg8IBJAAIASgoIATAoIBJAAIAAA8IAnAAIAAAeIAdAAIAAAfIAdAAIAAWEg");
	this.shape_73.setTransform(572.4,641.2);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#C5EDFF").s().p("AkPIEIAAwHIIfAAIAAQHg");
	this.shape_74.setTransform(511.8,658.2);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#C5EDFF").s().p("AjGIEIAAgoIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgLIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgTIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgLIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIgKAAIAAgKIAKAAIAAgUIAnAAIAAgeIE/AAIAAAeIAmAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAALIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAATIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAALIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAUIAKAAIAAAKIgKAAIAAAog");
	this.shape_75.setTransform(457,669.2);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#C5EDFF").s().p("AkPJeIAAx1IDzhGIAABcIEsgqIAASJg");
	this.shape_76.setTransform(402.2,653.2);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#C5EDFF").s().p("AiuEwIAAkqIjBATIDBjHIAAhaIFugnIAACtICwBUIiwARIAAFNg");
	this.shape_77.setTransform(347.7,683.4);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#C5EDFF").s().p("AjYGjIAAqlIAmAAIAAhQIAnAAIAAgzIAnAAIAAgdIBpAAIAAAdIAmAAIAAAzIB+AAIAABQIAwAAIAAKlg");
	this.shape_78.setTransform(296.9,668.9);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#E9FFD4").s().p("AkPHxIAAvhIIfAAIAAPhg");
	this.shape_79.setTransform(97.8,680.8);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#E9FFD4").s().p("AjUJdIAAxbIAhAAIAAgXIAhAAIAAgYIArAAIAAgvIDPAAIAAAvIAsAAIAAAYIAhAAIAAAXIAgAAIAARbg");
	this.shape_80.setTransform(1292.2,692.2);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#E9FFD4").s().p("AjZGVIAAqPIAnAAIAAhNIAnAAIAAgxIAmAAIAAgcIBqAAIAAAcIAnAAIAAAxIB+AAIAABNIAwAAIAAKPg");
	this.shape_81.setTransform(57.5,681.3);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#E9FFD4").s().p("AlmttIGMBCIAAiSIFABuIACcMIrNABg");
	this.shape_82.setTransform(768.7,607.7);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#E9FFD4").s().p("AkOOoIAA9PIIdAAIAAdPg");
	this.shape_83.setTransform(409,614.7);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#E9FFD4").s().p("Ak/lCIFhAYIAAg2IEeApIAAKWIp/ACg");
	this.shape_84.setTransform(1214.7,686.6);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#E9FFD4").s().p("AjoKHIAAwWIA0AAIAAh8ICHAAIAAhNIApAAIAAguIBxAAIAAAuIApAAIAABNIApAAIAAB8IAqAAIAAQWg");
	this.shape_85.setTransform(1173,650.4);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#E9FFD4").s().p("AjVS9MAAAgi7IAiAAIAAgwIAhAAIAAgwIArAAIAAheIDPAAIAABeIArAAIAAAwIAiAAIAAAwIAhAAMAAAAi7g");
	this.shape_86.setTransform(873.4,631.4);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#E9FFD4").s().p("AlmpHIGMAsIAAhhIFABJIABSvIrMACg");
	this.shape_87.setTransform(973.3,651.4);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#E9FFD4").s().p("AlmpHIGMAsIAAhhIFABJIABSwIrMAAg");
	this.shape_88.setTransform(347.9,647.5);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#E9FFD4").s().p("AjZKMIAAweIAnAAIAAh8IAnAAIAAhOIAmAAIAAgvIBqAAIAAAvIAnAAIAABOIB+AAIAAB8IAwAAIAAQeg");
	this.shape_89.setTransform(1082.3,660.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#E9FFD4").s().p("AjGKtIAAg1IgJAAIAAgNIAJAAIAAgbIgJAAIAAgNIAJAAIAAgbIgJAAIAAgNIAJAAIAAgbIgJAAIAAgNIAJAAIAAgaIgJAAIAAgOIAJAAIAAgbIgJAAIAAgNIAJAAIAAgaIgJAAIAAgOIAJAAIAAgbIgJAAIAAgMIAJAAIAAgcIgJAAIAAgMIAJAAIAAgbIgJAAIAAgOIAJAAIAAgaIgJAAIAAgNIAJAAIAAgbIgJAAIAAgOIAJAAIAAgaIgJAAIAAgNIAJAAIAAgbIgJAAIAAgNIAJAAIAAgbIgJAAIAAgNIAJAAIAAgbIgJAAIAAgNIAJAAIAAgZIgJAAIAAgOIAJAAIAAgbIgJAAIAAgNIAJAAIAAgaIgJAAIAAgOIAJAAIAAgbIgJAAIAAgNIAJAAIAAgaIgJAAIAAgOIAJAAIAAgbIgJAAIAAgMIAJAAIAAgbIgJAAIAAgOIAJAAIAAgaIgJAAIAAgOIAJAAIAAgaIgJAAIAAgNIAJAAIAAgbIgJAAIAAgOIAJAAIAAgaIgJAAIAAgNIAJAAIAAgbIgJAAIAAgNIAJAAIAAgbIgJAAIAAgNIAJAAIAAgaIgJAAIAAgOIAJAAIAAgbIgJAAIAAgNIAJAAIAAgaIgJAAIAAgOIAJAAIAAgaIAnAAIAAgpIE/AAIAAApIAnAAIAAAaIAKAAIAAAOIgKAAIAAAaIAKAAIAAANIgKAAIAAAbIAKAAIAAAOIgKAAIAAAaIAKAAIAAANIgKAAIAAAbIAKAAIAAANIgKAAIAAAbIAKAAIAAANIgKAAIAAAaIAKAAIAAAOIgKAAIAAAbIAKAAIAAANIgKAAIAAAaIAKAAIAAAOIgKAAIAAAaIAKAAIAAAOIgKAAIAAAbIAKAAIAAAMIgKAAIAAAbIAKAAIAAAOIgKAAIAAAaIAKAAIAAANIgKAAIAAAbIAKAAIAAAOIgKAAIAAAaIAKAAIAAANIgKAAIAAAbIAKAAIAAAOIgKAAIAAAZIAKAAIAAANIgKAAIAAAbIAKAAIAAANIgKAAIAAAbIAKAAIAAANIgKAAIAAAbIAKAAIAAANIgKAAIAAAaIAKAAIAAAOIgKAAIAAAbIAKAAIAAANIgKAAIAAAaIAKAAIAAAOIgKAAIAAAbIAKAAIAAAMIgKAAIAAAcIAKAAIAAAMIgKAAIAAAbIAKAAIAAAOIgKAAIAAAaIAKAAIAAANIgKAAIAAAbIAKAAIAAAOIgKAAIAAAaIAKAAIAAANIgKAAIAAAbIAKAAIAAANIgKAAIAAAbIAKAAIAAANIgKAAIAAAbIAKAAIAAANIgKAAIAAA1g");
	this.shape_90.setTransform(236.9,645.6);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#E9FFD4").s().p("AkOHxIAAvhIIeAAIAAPhg");
	this.shape_91.setTransform(908.3,658.6);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFF0F1").s().p("Ak/lCIFhAYIAAg2IEeApIABKXIqAABg");
	this.shape_92.setTransform(1334,695.3);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFF0F1").s().p("AjZGWIAAqQIAmAAIAAhOIAoAAIAAgwIAmAAIAAgdIBqAAIAAAdIAmAAIAAAwIB+AAIAABOIAxAAIAAKQg");
	this.shape_93.setTransform(601.5,681.6);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFF0F1").s().p("AkPLrIAA3VIIfAAIAAXVg");
	this.shape_94.setTransform(547.7,715.6);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFF0F1").s().p("AjGQGIAAhQIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgnIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIgKAAIAAgUIAKAAIAAgoIAnAAIAAg8IE/AAIAAA8IAmAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAnIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAAAoIAKAAIAAAUIgKAAIAABQg");
	this.shape_95.setTransform(814.8,607.6);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFF0F1").s().p("AjZLaIAAydIAnAAIAAiMIAmAAIAAhWIAnAAIAAg0IBqAAIAAA0IAnAAIAABWIB+AAIAACMIAwAAIAASdg");
	this.shape_96.setTransform(836.1,648.8);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFF0F1").s().p("AjZJhIAAvZIAnAAIAAh0IAmAAIAAhJIAnAAIAAgrIBqAAIAAArIAnAAIAABJIB+AAIAAB0IAwAAIAAPZg");
	this.shape_97.setTransform(635.4,661.3);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFF0F1").s().p("AjGM+IAAhBIgJAAIAAgPIAJAAIAAghIgJAAIAAgQIAJAAIAAggIgJAAIAAgQIAJAAIAAghIgJAAIAAgPIAJAAIAAggIgJAAIAAgRIAJAAIAAggIgJAAIAAgQIAJAAIAAghIgJAAIAAgQIAJAAIAAggIgJAAIAAgQIAJAAIAAggIgJAAIAAgQIAJAAIAAghIgJAAIAAgQIAJAAIAAggIgJAAIAAgQIAJAAIAAggIgJAAIAAgQIAJAAIAAghIgJAAIAAgQIAJAAIAAggIgJAAIAAgQIAJAAIAAghIgJAAIAAgQIAJAAIAAgfIgJAAIAAgRIAJAAIAAgfIgJAAIAAgQIAJAAIAAghIgJAAIAAgQIAJAAIAAgfIgJAAIAAgRIAJAAIAAggIgJAAIAAgQIAJAAIAAghIgJAAIAAgQIAJAAIAAggIgJAAIAAgQIAJAAIAAggIgJAAIAAgRIAJAAIAAgfIgJAAIAAgRIAJAAIAAggIgJAAIAAgQIAJAAIAAggIgJAAIAAgRIAJAAIAAgfIgJAAIAAgQIAJAAIAAghIgJAAIAAgQIAJAAIAAghIgJAAIAAgQIAJAAIAAgfIgJAAIAAgRIAJAAIAAggIgJAAIAAgQIAJAAIAAggIgJAAIAAgRIAJAAIAAgfIAnAAIAAgxIE/AAIAAAxIAnAAIAAAfIAJAAIAAARIgJAAIAAAgIAJAAIAAAQIgJAAIAAAgIAJAAIAAARIgJAAIAAAfIAJAAIAAAQIgJAAIAAAhIAJAAIAAAQIgJAAIAAAhIAJAAIAAAQIgJAAIAAAfIAJAAIAAARIgJAAIAAAgIAJAAIAAAQIgJAAIAAAgIAJAAIAAARIgJAAIAAAfIAJAAIAAARIgJAAIAAAgIAJAAIAAAQIgJAAIAAAgIAJAAIAAAQIgJAAIAAAhIAJAAIAAAQIgJAAIAAAgIAJAAIAAARIgJAAIAAAfIAJAAIAAAQIgJAAIAAAhIAJAAIAAAQIgJAAIAAAfIAJAAIAAARIgJAAIAAAfIAJAAIAAAQIgJAAIAAAhIAJAAIAAAQIgJAAIAAAgIAJAAIAAAQIgJAAIAAAhIAJAAIAAAQIgJAAIAAAgIAJAAIAAAQIgJAAIAAAgIAJAAIAAAQIgJAAIAAAhIAJAAIAAAQIgJAAIAAAgIAJAAIAAAQIgJAAIAAAgIAJAAIAAAQIgJAAIAAAhIAJAAIAAAQIgJAAIAAAgIAJAAIAAARIgJAAIAAAgIAJAAIAAAPIgJAAIAAAhIAJAAIAAAQIgJAAIAAAgIAJAAIAAAQIgJAAIAAAhIAJAAIAAAPIgJAAIAABBg");
	this.shape_98.setTransform(445.4,627.2);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFF0F1").s().p("AkZOCIAAhGIgOAAIAAgRIAOAAIAAgjIgOAAIAAgSIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgSIAOAAIAAgiIgOAAIAAgSIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgSIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgSIAOAAIAAgiIgOAAIAAgSIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgSIAOAAIAAgiIgOAAIAAgSIAOAAIAAgiIgOAAIAAgRIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgSIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgSIAOAAIAAgiIgOAAIAAgSIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgSIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgSIAOAAIAAgiIgOAAIAAgSIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIgOAAIAAgRIAOAAIAAgjIA3AAIAAg1IHFAAIAAA1IA3AAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAASIgOAAIAAAiIAOAAIAAASIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAASIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAASIgOAAIAAAiIAOAAIAAASIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAASIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAARIgOAAIAAAiIAOAAIAAASIgOAAIAAAiIAOAAIAAASIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAASIgOAAIAAAiIAOAAIAAASIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAASIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAASIgOAAIAAAiIAOAAIAAASIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAARIgOAAIAAAjIAOAAIAAASIgOAAIAAAjIAOAAIAAARIgOAAIAABGg");
	this.shape_99.setTransform(1034.8,632);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFF0F1").s().p("AljRIIAAhWIgRAAIAAgVIARAAIAAgqIgRAAIAAgWIARAAIAAgqIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgqIgRAAIAAgWIARAAIAAgqIgRAAIAAgWIARAAIAAgqIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgqIgRAAIAAgWIARAAIAAgqIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgqIgRAAIAAgVIARAAIAAgqIgRAAIAAgWIARAAIAAgqIgRAAIAAgWIARAAIAAgqIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgqIgRAAIAAgWIARAAIAAgqIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgqIgRAAIAAgWIARAAIAAgqIgRAAIAAgVIARAAIAAgrIgRAAIAAgVIARAAIAAgrIBGAAIAAhAII8AAIAABAIBFAAIAAArIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAAqIARAAIAAAWIgRAAIAAAqIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAAqIARAAIAAAWIgRAAIAAAqIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAAqIARAAIAAAWIgRAAIAAAqIARAAIAAAWIgRAAIAAAqIARAAIAAAVIgRAAIAAAqIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAAqIARAAIAAAWIgRAAIAAAqIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAAqIARAAIAAAWIgRAAIAAAqIARAAIAAAWIgRAAIAAAqIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAArIARAAIAAAVIgRAAIAAAqIARAAIAAAWIgRAAIAAAqIARAAIAAAVIgRAAIAABWg");
	this.shape_100.setTransform(501.6,614.2);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFF0F1").s().p("AkOHxIAAvhIIdAAIAAPhg");
	this.shape_101.setTransform(1122.6,673.1);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFF0F1").s().p("AjZEOIAAm0IAnAAIAAg0IAmAAIAAggIAnAAIAAgTIBqAAIAAATIAnAAIAAAgIB+AAIAAA0IAwAAIAAG0g");
	this.shape_102.setTransform(23.6,694.8);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFF0F1").s().p("AjeHxIAAvhIG9AAIAAPhg");
	this.shape_103.setTransform(1257.4,669.2);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFF0F1").s().p("AjRHQIAAnHIjnAdIDnkvIAAiJIG3g8IAAEIIDTB/IjTAaIAAH9g");
	this.shape_104.setTransform(141.9,684.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFF0F1").s().p("AjZGWIAAqQIAnAAIAAhNIAmAAIAAgwIAnAAIAAgdIBqAAIAAAdIAnAAIAAAwIB+AAIAABNIAwAAIAAKQg");
	this.shape_105.setTransform(258.2,664.9);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFF0F1").s().p("AiMM5IAA3JIAWAAIAAggIAWAAIAAgfIAcAAIAAg/IA3AAIANgqIAOAqIA2AAIAAA/IAdAAIAAAfIAWAAIAAAgIAWAAIAAXJg");
	this.shape_106.setTransform(290.2,652.8);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFF0F1").s().p("AlnpHIGNAsIgBhhIFBBJIACSvIrNABg");
	this.shape_107.setTransform(190.9,645.6);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#DDDDDD").s().p("AkOLrIAA3VIIdAAIAAXVg");
	this.shape_108.setTransform(675.6,660.6);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#DDDDDD").s().p("AjRK4IAAqqIjnArIDnnIIAAjNIG3hcIAAGNIDTDAIjTAnIAAL8g");
	this.shape_109.setTransform(719.7,665.7);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#DDDDDD").s().p("AjZEOIAAm0IAmAAIAAg0IAoAAIAAggIAmAAIAAgUIBqAAIAAAUIAmAAIAAAgIB+AAIAAA0IAxAAIAAG0g");
	this.shape_110.setTransform(1048.4,677.4);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#DDDDDD").s().p("AkOHxIAAvhIIdAAIAAPhg");
	this.shape_111.setTransform(477.9,662.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(162.3,304.9,1896.8,884.6);
// library properties:
lib.properties = {
	id: '42AB58DC12B7DE49B9AFBCA2D9ABBE27',
	width: 1366,
	height: 768,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['42AB58DC12B7DE49B9AFBCA2D9ABBE27'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;