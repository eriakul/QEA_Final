(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



// stage content:
(lib.dampahead = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Mouth
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(40).p("AMvikQAAA5g+BJQhABJhtBBQkFCek/AAQk9AAkGioQhshEhBhOQg+hLAAg5QAAg0BBgRQA2gNB6AHQBLAEC9ARQC4APCLAAQDmAAFXgaQB0gDA0AQQA8AUAAA0g");
	this.shape.setTransform(614.5,245.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(360));

	// Eyes
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AlCKbIAA01IKFAAIAAU1g");
	this.shape_1.setTransform(835.3,141.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AlBKbIAA01IKDAAIAAU1g");
	this.shape_2.setTransform(391.1,141.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleY:1,y:141.8}},{t:this.shape_1,p:{scaleY:1,y:141.8}}]}).to({state:[{t:this.shape_2,p:{scaleY:0.253,y:186}},{t:this.shape_1,p:{scaleY:0.253,y:186}}]},71).to({state:[{t:this.shape_2,p:{scaleY:1,y:141.8}},{t:this.shape_1,p:{scaleY:1,y:141.8}}]},1).to({state:[{t:this.shape_2,p:{scaleY:0.238,y:187}},{t:this.shape_1,p:{scaleY:0.238,y:187}}]},71).to({state:[{t:this.shape_2,p:{scaleY:1,y:141.8}},{t:this.shape_1,p:{scaleY:1,y:141.8}}]},1).to({state:[{t:this.shape_2,p:{scaleY:0.238,y:187}},{t:this.shape_1,p:{scaleY:0.238,y:187}}]},71).to({state:[{t:this.shape_2,p:{scaleY:1,y:141.8}},{t:this.shape_1,p:{scaleY:1,y:141.8}}]},1).to({state:[{t:this.shape_2,p:{scaleY:0.222,y:187.9}},{t:this.shape_1,p:{scaleY:0.222,y:187.9}}]},71).to({state:[{t:this.shape_2,p:{scaleY:1,y:141.8}},{t:this.shape_1,p:{scaleY:1,y:141.8}}]},1).to({state:[{t:this.shape_2,p:{scaleY:0.254,y:186}},{t:this.shape_1,p:{scaleY:0.254,y:186}}]},71).wait(1));

	// Face Light
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.247)").s().p("EglFAKRQvdkQAAmBQAAkNHmjWIAOgHQDLhXEehPQPdkQV3AAQV3AAPdEQQEeBPDLBXIAOAHQDVBeB4BoQiXAKhxAxQiNA9AABXQAABWCNA9QCNA9DIAAIAvgBQiNEvszDhQvdEQ13AAQ13AAvdkQg");
	this.shape_3.setTransform(616.5,41.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.4)").s().p("AlTCUQiNg9AAhXQAAhWCNg9QBxgxCXgKQAlgCAmAAQDHAACNA9QCNA9AABWQAABXiNA9Qh8A2ioAGIgwABQjGAAiNg9g");
	this.shape_4.setTransform(948.1,33.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3}]}).wait(360));

	// Face
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF3B3B").s().p("EhfqAfRMAAAg+hMC/VAAAMAAAA+hg");
	this.shape_5.setTransform(612.3,200.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FCCF19").s().p("EhfqAfRMAAAg+hMC/VAAAMAAAA+hg");
	this.shape_6.setTransform(612.3,200.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4CD957").s().p("EhfqAfRMAAAg+hMC/VAAAMAAAA+hg");
	this.shape_7.setTransform(612.3,200.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#999999").s().p("EhfqAfRMAAAg+hMC/VAAAMAAAA+hg");
	this.shape_8.setTransform(612.3,200.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("EhfqAfRMAAAg+hMC/VAAAMAAAA+hg");
	this.shape_9.setTransform(612.3,200.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5}]}).to({state:[{t:this.shape_6}]},71).to({state:[{t:this.shape_7}]},72).to({state:[{t:this.shape_8}]},72).to({state:[{t:this.shape_9}]},72).to({state:[{t:this.shape_5}]},72).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(612,128.2,1224.6,452.1);
// library properties:
lib.properties = {
	id: '5322D849F879F749A0B7F4E116F92F95',
	width: 1224,
	height: 360,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['5322D849F879F749A0B7F4E116F92F95'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;