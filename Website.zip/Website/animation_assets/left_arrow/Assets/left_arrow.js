(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.button = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BDCCD4").ss(14,1,1).p("AjlFPIHLlPInLlO");
	this.shape.setTransform(-5.1,2.6,1,1,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E3E3E3").s().p("AkxBCQh+gbAAgnQAAglB+gcQB/gbCyAAQCzAAB+AbQB/AcAAAlQAAAnh/AbQh+AbizAAQiyAAh/gbg");
	this.shape_1.setTransform(-1.1,-87.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AkxCUQh+gcAAgmIAAkAINfAAIAAEAQAAAmh/AcQh+AbizAAQiyAAh/gbg");
	this.shape_2.setTransform(-1.1,-69.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E3E3E3").s().p("AomCVQjkg+AAhXQAAhWDkg+QDkg+FCAAQFCAADlA+QDkA+AABWQAABXjkA+QjkA+lDAAQlCAAjkg+g");
	this.shape_3.setTransform(0,-60.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AolDcQjlg9AAhYIABgDIgBAAIAAldIYVAAIAAFdIgBAAIABADQAABYjkA9QjlA+lCAAQlBAAjkg+g");
	this.shape_4.setTransform(0,-32.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E3E3E3").s().p("ArCDUQklhYAAh8QAAh8ElhXQEkhYGeAAQGeAAElBYQElBXAAB8QAAB8klBYQklBYmeAAQmdAAklhYg");
	this.shape_5.setTransform(0,-20.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ArCEBQklhRAAh0IAAmOIfPAAIAAGOQAAB0klBRQklBSmeAAQmeAAkkhSg");
	this.shape_6.setTransform(0,12.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E3E3E3").s().p("AolDdQjlg+AAhXIABgEIgBAAIAAldIYVAAIAAFdIgBAAIABAEQAABXjkA+QjlA9lCAAQlBAAjkg9g");
	this.shape_7.setTransform(0,50);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#BDBDBD").s().p("AkxCUQh+gbAAgmIAAkBINfAAIAAEBQAAAmh/AbQh+AbizAAQiyAAh/gbg");
	this.shape_8.setTransform(-1.1,79.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").ss(14,1,1).p("AjlFPIHLlPInLlO");
	this.shape_9.setTransform(-5.1,2.6,1,1,180);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AkxCUQh+gcAAgmIAAkAINfAAIAAEAQAAAmh/AcQh+AbizAAQiyAAh/gbg");
	this.shape_10.setTransform(-1.1,-69.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AolDcQjlg9AAhYIABgDIgBAAIAAldIYVAAIAAFdIgBAAIABADQAABYjkA9QjlA+lCAAQlBAAjkg+g");
	this.shape_11.setTransform(0,-32.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("ArCEBQklhRAAh0IAAmOIfPAAIAAGOQAAB0klBRQklBSmeAAQmeAAkkhSg");
	this.shape_12.setTransform(0,12.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AolDdQjlg+AAhXIABgEIgBAAIAAldIYVAAIAAFdIgBAAIABAEQAABXjkA+QjlA9lCAAQlBAAjkg9g");
	this.shape_13.setTransform(0,50);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AkxCUQh+gbAAgmIAAkBINfAAIAAEBQAAAmh/AbQh+AbizAAQiyAAh/gbg");
	this.shape_14.setTransform(-1.1,79.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_5},{t:this.shape_11},{t:this.shape_3},{t:this.shape_10},{t:this.shape_1},{t:this.shape_9}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-100,-96.7,200,193.6);


// stage content:
(lib.page_arrows = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.button_1.addEventListener("click", fl_ClickToGoToWebPage);
		
		function fl_ClickToGoToWebPage() {
			window.open("http://www.adobe.com", "_blank");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// left_arrow
	this.button_1 = new lib.button();
	this.button_1.name = "button_1";
	this.button_1.parent = this;
	this.button_1.setTransform(25,25,0.25,0.25);
	new cjs.ButtonHelper(this.button_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.button_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(25,25.8,50,48.4);
// library properties:
lib.properties = {
	id: '62470E7EEE12B64FB4FD4FDA72C3E9B1',
	width: 50,
	height: 50,
	fps: 24,
	color: "#FFFFFF",
	opacity: 0.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['62470E7EEE12B64FB4FD4FDA72C3E9B1'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;